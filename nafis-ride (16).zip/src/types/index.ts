export type VehicleType = 'bike' | 'auto' | 'eriksha';

export type RideStatus =
  | 'idle'
  | 'searching'
  | 'captain_assigned'
  | 'arrived'
  | 'in_trip'
  | 'completed'
  | 'cancelled';

export interface OperationalCity {
  id: string;
  name: string;
  hindiName: string;
  kannadaName?: string;
  state: 'Rajasthan' | 'Karnataka' | 'Delhi' | 'Haryana' | string;
  stateHindi: string;
  stateKannada?: string;
  center: { lat: number; lng: number };
  zoom: number;
  radiusKm: number;
  tagline: string;
  isPopular?: boolean;
}

export interface LocationPoint {
  id: string;
  name: string;
  hindiName: string;
  kannadaName?: string;
  lat: number;
  lng: number;
  landmark?: string;
  isOfficialZone: boolean;
  cityId?: string;
  state?: 'Rajasthan' | 'Karnataka' | 'Delhi' | 'Haryana' | string;
}

export interface VehicleOption {
  type: VehicleType;
  name: string;
  hindiName: string;
  tagline: string;
  icon: string;
  capacity: number;
  baseFare: number;
  perKmRate: number;
  minFare: number;
  speedKmH: number;
}

export interface CaptainKycDoc {
  aadhaarNumber: string;
  aadhaarPhotoUrl: string;
  aadhaarBackPhotoUrl?: string;
  drivingLicenseNumber: string;
  dlPhotoUrl: string;
  dlExpiryDate?: string;
  dlClass?: string;
  rcNumber?: string;
  rcPhotoUrl?: string;
  insuranceNumber?: string;
  insurancePhotoUrl?: string;
  pucCertificateNumber?: string;
  profilePhotoUrl: string;
  vehicleRegistration: string;
  submittedAt: string;
  verificationNotes?: string;
}

export interface Captain {
  id: string;
  name: string;
  phone: string;
  email: string;
  vehicleType: VehicleType;
  vehicleModel: string;
  vehiclePlate: string;
  photoUrl: string;
  rating: number;
  totalTrips: number;
  isOnline: boolean;
  kycStatus: 'pending' | 'approved' | 'rejected';
  kycDocs?: CaptainKycDoc;
  walletBalance: number;
  todayEarnings: number;
  upiId: string;
  bloodGroup?: string;
  emergencyContact?: string;
  idCardIssuedDate?: string;
  idCardExpiryDate?: string;
  lat: number;
  lng: number;
  cityId?: string;
  currentRideId?: string | null;
  joinedDate: string;
}

export interface PaymentDetails {
  method: 'upi_intent' | 'upi_qr' | 'cashless_wallet' | 'cash';
  utrNumber: string;
  paidAt: string;
  amount: number;
  captainCredit?: number; // 88%
  platformCommission?: number; // 12%
  appName?: string;
  payerName?: string;
  receiptId: string;
  webhookVerified?: boolean;
  transactionId?: string;
}

export interface Ride {
  id: string;
  riderId: string;
  riderName: string;
  riderPhone: string;
  captainId?: string;
  captainName?: string;
  captainPhone?: string;
  captainPhoto?: string;
  vehicleType: VehicleType;
  vehiclePlate?: string;
  vehicleModel?: string;
  pickupLocation: LocationPoint;
  dropLocation: LocationPoint;
  distanceKm: number;
  fare: number;
  estimatedMinutes: number;
  otp: string;
  status: RideStatus;
  paymentMethod: 'cash' | 'upi_qr' | 'upi_intent' | 'cashless_wallet';
  paymentStatus: 'pending' | 'paid';
  paymentDetails?: PaymentDetails;
  rating?: number;
  createdAt: string;
  arrivedAt?: string;
  startedAt?: string;
  completedAt?: string;
}

export interface UserProfile {
  id: string;
  name: string;
  phone: string;
  email: string;
  role: 'rider' | 'passenger' | 'captain' | 'admin';
  token: string;
  walletBalance?: number;
  isVerified?: boolean;
  savedPlaces?: { name: string; location: LocationPoint }[];
}

export interface SosAlert {
  id: string;
  rideId?: string;
  senderName: string;
  senderPhone: string;
  userName?: string;
  userPhone?: string;
  userRole?: 'passenger' | 'captain';
  locationAddress?: string;
  role: 'passenger' | 'captain';
  coordinates: {
    lat: number;
    lng: number;
    address: string;
  };
  timestamp: string;
  status: 'active' | 'resolved';
  resolvedBy?: string;
  resolvedAt?: string;
  notes?: string;
  locationLink?: string;
  smsReceipt?: {
    messageId: string;
    recipient: string;
    status: string;
    deliveredAt: string;
    alertType: string;
  };
}

export interface AppSettings {
  baseFare: number;
  perKmRate: number;
  commissionPercentage: number;
  surgeMultiplier: number;
  maxRideLimitKm: number;
}

export interface FareSettings {
  bike: { baseFare: number; perKm: number; minFare: number };
  auto: { baseFare: number; perKm: number; minFare: number };
  eriksha: { baseFare: number; perKm: number; minFare: number };
  maxRideLimitKm: number;
  commissionPercentage: number;
  founderName: string;
  supportEmail: string;
  sosHelpline: string;
}

export interface RideTier {
  id: string;
  name: string;
  category: string;
  etaMinutes: number;
  basePrice: number;
  capacity: number;
  iconName: string;
  badge?: string;
}

export interface RideBooking {
  id: string;
  pickup: string;
  dropoff: string;
  tier: string;
  price: number;
  status: 'searching' | 'driver_assigned' | 'in_transit' | 'completed' | 'cancelled';
  timestamp: string;
  driverName?: string;
  driverVehicle?: string;
  licensePlate?: string;
  rating?: number;
}

export interface DiagnosticCheck {
  id: string;
  title: string;
  description: string;
  status: 'passed' | 'warning' | 'info';
  detectedValue: string;
  recommendation: string;
}

export interface CeoPerformanceMetric {
  id: string;
  title: string;
  description: string;
  category: string;
  targetDate: string;
  completionPercentage: number;
  status: 'completed' | 'in_progress' | 'planned';
  targetBenchmark?: string;
}

export interface ExecutiveMember {
  id: string;
  name: string;
  role?: string;
  hindiRole?: string;
  employeeCode?: string;
  hindiName?: string;
  designation?: string;
  hindiDesignation?: string;
  roleCategory?: 'ceo' | 'md' | 'gm' | 'manager' | 'safety' | string;
  department?: string;
  phone: string;
  email: string;
  location?: string;
  bloodGroup?: string;
  joiningDate?: string;
  joinedDate?: string;
  validUpto?: string;
  badgeLevel?: 'Executive Platinum' | 'Director Gold' | 'Operations Silver' | 'Field Command' | string;
  authorityLevel?: string;
  isCeo?: boolean;
  avatarUrl?: string;
  emergencyContact?: string;
  idNumber?: string;
  status?: 'active' | 'on_leave';
  keyResponsibilities?: string[];
}
