import React from 'react';
import {
  Car,
  MapPin,
  Clock,
  CheckCircle,
  Star,
  Phone,
} from 'lucide-react';
import { RideBooking } from '../types';

interface RidesViewProps {
  rides: RideBooking[];
  onCancelRide?: (id: string) => void;
}

export const RidesView: React.FC<RidesViewProps> = ({ rides }) => {
  return (
    <div id="rides-history-view" className="space-y-4 pb-20">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-base font-bold text-slate-900">Your Activity</h2>
          <p className="text-xs text-slate-500">Active dispatches and completed journeys</p>
        </div>
        <span className="text-xs bg-slate-100 font-semibold px-2.5 py-1 rounded-full text-slate-700">
          {rides.length} Total
        </span>
      </div>

      {rides.length === 0 ? (
        <div id="empty-rides-card" className="p-8 text-center bg-white rounded-2xl border border-slate-200 shadow-sm">
          <Car className="w-10 h-10 text-slate-300 mx-auto mb-2" />
          <p className="text-xs font-semibold text-slate-700">No rides booked yet</p>
          <p className="text-[11px] text-slate-400 mt-0.5">Your trip history will appear here relative to your mobile device cache.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {rides.map((ride) => (
            <div
              key={ride.id}
              id={`ride-card-${ride.id}`}
              className="p-4 bg-white rounded-2xl border border-slate-200/90 shadow-sm space-y-3"
            >
              <div className="flex justify-between items-start">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
                    <Car className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-xs font-bold text-slate-900">{ride.tier}</h3>
                    <span className="text-[10px] text-slate-400">{ride.timestamp}</span>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-sm font-mono font-bold text-slate-900">${ride.price.toFixed(2)}</span>
                  <span className={`block text-[10px] font-semibold uppercase ${
                    ride.status === 'driver_assigned' ? 'text-blue-600' :
                    ride.status === 'completed' ? 'text-emerald-600' : 'text-slate-500'
                  }`}>
                    {ride.status.replace('_', ' ')}
                  </span>
                </div>
              </div>

              {ride.driverName && (
                <div className="p-2.5 bg-slate-50 rounded-xl flex items-center justify-between text-xs border border-slate-100">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-full bg-slate-200 flex items-center justify-center font-bold text-slate-700 text-xs">
                      {ride.driverName[0]}
                    </div>
                    <div>
                      <div className="font-semibold text-slate-800 flex items-center gap-1">
                        {ride.driverName}
                        {ride.rating && (
                          <span className="flex items-center text-[10px] text-amber-600 font-medium">
                            <Star className="w-3 h-3 fill-amber-500 text-amber-500" />
                            {ride.rating}
                          </span>
                        )}
                      </div>
                      <div className="text-[10px] text-slate-500">{ride.driverVehicle} ({ride.licensePlate})</div>
                    </div>
                  </div>
                  <button
                    type="button"
                    className="p-2 rounded-lg bg-white border border-slate-200 text-slate-700 hover:text-emerald-600 shadow-2xs"
                    title="Contact driver"
                  >
                    <Phone className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}

              <div className="space-y-1.5 text-xs text-slate-600 pt-1 border-t border-slate-100">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-blue-500"></span>
                  <span className="truncate">{ride.pickup}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                  <span className="truncate">{ride.dropoff}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
