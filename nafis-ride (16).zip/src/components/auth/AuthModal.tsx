import React, { useState, useEffect } from 'react';
import {
  X,
  Phone,
  KeyRound,
  ShieldCheck,
  ArrowRight,
  RefreshCw,
  MessageCircle,
  AlertCircle,
  CheckCircle2,
  Loader2,
} from 'lucide-react';
import { rideStore } from '../../services/store';
import { otpService } from '../../services/otpService';
import { audioService } from '../../services/audioService';
import { FOUNDER_NAME } from '../../data/constants';

interface AuthModalProps {
  isOpen: boolean;
  onClose?: () => void;
  initialPhone?: string;
  defaultRole?: 'passenger' | 'captain';
  onLoginSuccess?: (role: 'passenger' | 'captain') => void;
  isCompulsory?: boolean;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  initialPhone = '',
  defaultRole = 'passenger',
  onLoginSuccess,
  isCompulsory = false,
}) => {
  const [step, setStep] = useState<'phone' | 'otp'>('phone');
  const [phone, setPhone] = useState(initialPhone);
  const [role, setRole] = useState<'passenger' | 'captain'>(defaultRole);
  const [userName, setUserName] = useState('');
  const [otp, setOtp] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [countdown, setCountdown] = useState(45);
  const [canResend, setCanResend] = useState(false);
  const [otpInfo, setOtpInfo] = useState<string | null>(null);

  useEffect(() => {
    if (initialPhone) {
      setPhone(initialPhone);
    }
  }, [initialPhone]);

  useEffect(() => {
    let timer: number;
    if (step === 'otp' && countdown > 0) {
      timer = window.setInterval(() => {
        setCountdown((c) => {
          if (c <= 1) {
            setCanResend(true);
            return 0;
          }
          return c - 1;
        });
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [step, countdown]);

  if (!isOpen) return null;

  const handleSendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanPhone = phone.replace(/\D/g, '').slice(-10);
    if (cleanPhone.length !== 10) {
      setError('कृपया वैध 10-अंकीय मोबाइल नंबर दर्ज करें।');
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      const res = await otpService.sendFast2SmsOtp(cleanPhone);
      setIsLoading(false);
      if (res.success) {
        setStep('otp');
        setCountdown(45);
        setCanResend(false);
        setOtpInfo(`OTP आपके नंबर +91 ${cleanPhone} पर प्रेषित कर दिया गया है।`);
        audioService.playChime('booked');
      } else {
        setError(res.error || 'OTP भेजने में विफल। कृपया पुनः प्रयास करें।');
      }
    } catch (err: any) {
      setIsLoading(false);
      setError(err?.message || 'नेटवर्क त्रुटि। कृपया पुनः प्रयास करें।');
    }
  };

  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanOtp = otp.trim();
    if (cleanOtp.length !== 4) {
      setError('कृपया 4-अंकीय OTP दर्ज करें।');
      return;
    }

    setIsLoading(true);
    setError(null);

    const cleanPhone = phone.replace(/\D/g, '').slice(-10);
    const verification = await otpService.verifyOtp(cleanPhone, cleanOtp);

    setIsLoading(false);
    if (verification.success) {
      audioService.playChime('completed');

      if (role === 'passenger') {
        rideStore.updateUserProfile({
          name: userName.trim() || `रफ़्तार राइडर ${cleanPhone.slice(-4)}`,
          phone: `+91 ${cleanPhone}`,
          isVerified: true,
          token: verification.token || `jwt_raftar_${Date.now()}_${cleanPhone}`,
        });
      } else {
        const captain = rideStore.getCaptainProfile();
        if (captain) {
          rideStore.updateCaptainProfile({
            ...captain,
            phone: `+91 ${cleanPhone}`,
            name: userName.trim() || captain.name,
          });
        }
      }

      if (onLoginSuccess) {
        onLoginSuccess(role);
      }
      if (onClose) {
        onClose();
      }
    } else {
      setError(verification.message || 'अमान्य OTP कोड। कृपया पुनः प्रयास करें।');
      audioService.playChime('sos');
    }
  };

  const handleResendOtp = async () => {
    if (!canResend) return;
    const cleanPhone = phone.replace(/\D/g, '').slice(-10);
    setIsLoading(true);
    setError(null);
    const res = await otpService.sendFast2SmsOtp(cleanPhone);
    setIsLoading(false);
    if (res.success) {
      setCountdown(45);
      setCanResend(false);
      setOtpInfo(`पुनः नया OTP +91 ${cleanPhone} पर भेजा गया।`);
      audioService.playChime('booked');
    } else {
      setError(res.error || 'पुनः प्रयास विफल।');
    }
  };

  const handleOpenWhatsAppBackup = () => {
    const cleanPhone = phone.replace(/\D/g, '').slice(-10);
    const waUrl = otpService.getWhatsAppFallbackUrl(cleanPhone);
    window.open(waUrl, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-amber-500/50 rounded-3xl max-w-md w-full p-6 text-white shadow-2xl relative my-auto animate-in fade-in zoom-in duration-200">
        {!isCompulsory && onClose && (
          <button
            onClick={onClose}
            id="btn-close-auth"
            className="absolute top-4 right-4 p-2 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-400"
          >
            <X className="w-5 h-5" />
          </button>
        )}

        {/* Modal Header */}
        <div className="flex items-center gap-3 mb-5">
          <div className="w-11 h-11 rounded-2xl bg-amber-500/20 border border-amber-500/50 flex items-center justify-center text-amber-400">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-base font-black text-amber-400 tracking-wide">
              RAFTAR MOBILITY SECURE LOGIN
            </h2>
            <p className="text-xs text-slate-400">
              Fast2SMS DLT & WhatsApp Verified Access
            </p>
          </div>
        </div>

        {error && (
          <div className="mb-4 p-3 bg-red-950/80 border border-red-500 rounded-2xl text-xs text-red-200 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {step === 'phone' ? (
          <form onSubmit={handleSendOtp} className="space-y-4 text-xs">
            {/* Role Switcher */}
            <div>
              <label className="block text-slate-300 font-bold mb-1.5">
                उपयोगकर्ता प्रकार (User Role):
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setRole('passenger')}
                  className={`py-2.5 rounded-xl font-bold transition-all ${
                    role === 'passenger'
                      ? 'bg-amber-500 text-slate-950 shadow'
                      : 'bg-slate-950 border border-slate-800 text-slate-400'
                  }`}
                >
                  सवारी (Rider)
                </button>
                <button
                  type="button"
                  onClick={() => setRole('captain')}
                  className={`py-2.5 rounded-xl font-bold transition-all ${
                    role === 'captain'
                      ? 'bg-amber-500 text-slate-950 shadow'
                      : 'bg-slate-950 border border-slate-800 text-slate-400'
                  }`}
                >
                  चालक (Captain)
                </button>
              </div>
            </div>

            {/* Name input */}
            <div>
              <label className="block text-slate-300 font-bold mb-1.5">
                आपका नाम (Full Name - Optional):
              </label>
              <input
                type="text"
                value={userName}
                onChange={(e) => setUserName(e.target.value)}
                placeholder="उदा. राहुल यादव"
                className="w-full bg-slate-950 border border-slate-700 rounded-2xl px-4 py-3 text-white text-xs focus:outline-none focus:border-amber-400"
              />
            </div>

            {/* Mobile number input */}
            <div>
              <label className="block text-slate-300 font-bold mb-1.5">
                मोबाइल नंबर (10-Digit Mobile):
              </label>
              <div className="relative">
                <div className="absolute left-3.5 top-1/2 -translate-y-1/2 flex items-center gap-1.5 text-xs font-bold text-slate-400 border-r border-slate-700 pr-2 pointer-events-none">
                  <span>🇮🇳</span>
                  <span>+91</span>
                </div>
                <input
                  type="tel"
                  maxLength={10}
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value.replace(/\D/g, ''))}
                  placeholder="98295 12044"
                  className="w-full bg-slate-950 border border-slate-700 rounded-2xl pl-20 pr-4 py-3.5 text-white font-mono font-bold text-sm tracking-wider focus:outline-none focus:border-amber-400"
                  autoFocus
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading || phone.length !== 10}
              id="btn-request-otp"
              className="w-full py-3.5 bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 text-slate-950 font-black text-sm rounded-2xl shadow-lg flex items-center justify-center gap-2 active:scale-95 transition-all disabled:opacity-50"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>प्रक्रियाधीन...</span>
                </>
              ) : (
                <>
                  <span>OTP प्राप्त करें (Get OTP)</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>
        ) : (
          /* OTP STEP */
          <form onSubmit={handleVerifyOtp} className="space-y-4 text-xs">
            <div className="text-center space-y-1">
              <span className="text-slate-400">सत्यापन कोड दर्ज करें:</span>
              <div className="text-sm font-mono font-bold text-amber-400">
                +91 {phone.replace(/\D/g, '').slice(-10)}
              </div>
            </div>

            {otpInfo && (
              <div className="p-2.5 bg-slate-950 rounded-xl border border-slate-800 text-[11px] text-slate-300 text-center">
                {otpInfo}
              </div>
            )}

            <div>
              <input
                type="text"
                maxLength={4}
                value={otp}
                onChange={(e) => setOtp(e.target.value.replace(/\D/g, ''))}
                placeholder="••••"
                className="w-full bg-slate-950 border border-amber-500 rounded-2xl px-4 py-3.5 text-center text-white font-mono font-black text-2xl tracking-widest focus:outline-none"
                autoFocus
              />
            </div>

            <button
              type="submit"
              disabled={isLoading || otp.length !== 4}
              id="btn-verify-otp"
              className="w-full py-3.5 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 text-slate-950 font-black text-sm rounded-2xl shadow-lg flex items-center justify-center gap-2 active:scale-95 transition-all disabled:opacity-50"
            >
              {isLoading ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <>
                  <span>सत्यापित करें एवं प्रवेश करें</span>
                  <CheckCircle2 className="w-4 h-4" />
                </>
              )}
            </button>

            {/* Countdown / Resend / WhatsApp fallback */}
            <div className="space-y-2 pt-1 border-t border-slate-800 text-center">
              <div className="flex items-center justify-between text-[11px] text-slate-400">
                <span>
                  {countdown > 0 ? (
                    `पुनः प्रयास: ${countdown}s`
                  ) : (
                    <button
                      type="button"
                      onClick={handleResendOtp}
                      className="text-amber-400 font-bold hover:underline"
                    >
                      पुनः OTP भेजें (Resend Fast2SMS)
                    </button>
                  )}
                </span>
                <button
                  type="button"
                  onClick={() => setStep('phone')}
                  className="text-slate-400 hover:text-white"
                >
                  नंबर बदलें
                </button>
              </div>

              <button
                type="button"
                onClick={handleOpenWhatsAppBackup}
                id="btn-whatsapp-fallback"
                className="w-full py-2 bg-emerald-950/60 hover:bg-emerald-900/60 border border-emerald-500/40 text-emerald-300 font-bold rounded-xl text-xs flex items-center justify-center gap-2 transition"
              >
                <MessageCircle className="w-4 h-4 text-emerald-400" />
                <span>WhatsApp पर OTP प्राप्त करें (Instant wa.me)</span>
              </button>
            </div>
          </form>
        )}

        <div className="mt-4 pt-3 border-t border-slate-800 text-center text-[10px] text-slate-500">
          Nafis Ride Unified Authentication • Founder: {FOUNDER_NAME}
        </div>
      </div>
    </div>
  );
};
