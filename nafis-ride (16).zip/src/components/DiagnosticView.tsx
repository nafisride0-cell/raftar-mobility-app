import React, { useState, useEffect } from 'react';
import {
  CheckCircle2,
  AlertTriangle,
  Smartphone,
  Terminal,
  Copy,
  Check,
  FileCode,
  RefreshCw,
  Info,
} from 'lucide-react';
import { DiagnosticCheck } from '../types';

export const DiagnosticView: React.FC = () => {
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [currentProtocol, setCurrentProtocol] = useState('');
  const [currentHash, setCurrentHash] = useState('');

  useEffect(() => {
    if (typeof window !== 'undefined') {
      setCurrentProtocol(window.location.protocol);
      setCurrentHash(window.location.hash || '#/');
    }
  }, []);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const checks: DiagnosticCheck[] = [
    {
      id: 'vite-base',
      title: "Vite Base Path (base: './')",
      description: 'Controls whether compiled HTML script tags use absolute (/assets/...) or relative (./assets/...) paths.',
      status: 'passed',
      detectedValue: "base: './' injected in vite.config.ts",
      recommendation: 'Always maintain relative base for Cordova & Capacitor so assets resolve inside file:///android_asset/.',
    },
    {
      id: 'react-router',
      title: 'Client-Side Router (HashRouter)',
      description: 'BrowserRouter relies on HTML5 pushState. Under Android WebView file:/// protocol, pushState reloads fail.',
      status: 'passed',
      detectedValue: `Active Router: HashRouter (Hash: "${currentHash}")`,
      recommendation: "HashRouter keeps navigation after '#' so the base index.html is never replaced on Android file protocol.",
    },
    {
      id: 'output-dir',
      title: 'Build Directory Alignment (dist)',
      description: 'Capacitor expects webDir to match the Vite build output directory.',
      status: 'passed',
      detectedValue: "build.outDir: 'dist' (Aligned with Capacitor webDir)",
      recommendation: "Ensure capacitor.config.ts has webDir: 'dist' and run 'npx cap copy android' after 'npm run build'.",
    },
    {
      id: 'protocol-check',
      title: 'Active Protocol Environment',
      description: 'Detects whether the app is running over HTTP, HTTPS (Capacitor custom scheme), or file:///.',
      status: currentProtocol === 'file:' ? 'warning' : 'info',
      detectedValue: `Protocol: ${currentProtocol || 'detecting...'}`,
      recommendation:
        currentProtocol === 'file:'
          ? 'Running under native file: protocol. HashRouter and relative paths are mandatory here.'
          : "Under Capacitor 8, server.androidScheme can also be 'https' for modern origin support.",
    },
  ];

  const viteConfigSnippet = `import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'path';

export default defineConfig({
  base: './',
  build: {
    outDir: 'dist',
    assetsDir: 'assets',
    emptyOutDir: true,
  },
  plugins: [react()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
});`;

  const mainTsxSnippet = `import React from 'react';
import ReactDOM from 'react-dom/client';
import { HashRouter } from 'react-router-dom';
import App from './App';
import './index.css';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <HashRouter>
      <App />
    </HashRouter>
  </React.StrictMode>
);`;

  const capacitorConfigSnippet = `import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.nafisride.app',
  appName: 'Nafis Ride',
  webDir: 'dist',
  server: {
    androidScheme: 'https',
    cleartext: true,
  },
};

export default config;`;

  return (
    <div id="diagnostic-view-container" className="space-y-6 pb-20">
      <div id="diagnostic-header-card" className="bg-slate-900 text-white p-5 rounded-2xl shadow-sm border border-slate-800">
        <div className="flex items-center gap-3 mb-2">
          <div className="p-2 bg-emerald-500/20 text-emerald-400 rounded-lg">
            <Smartphone className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg font-bold">Android & Capacitor 8 Environment Inspector</h2>
            <p className="text-xs text-slate-400">White Screen Mitigation & Relative Path Validation</p>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4 pt-3 border-t border-slate-800 text-xs">
          <div className="bg-slate-800/60 p-2.5 rounded-xl">
            <span className="text-slate-400 block text-[10px] uppercase font-semibold">Vite Base</span>
            <span className="text-emerald-400 font-mono font-bold">./ (Relative)</span>
          </div>
          <div className="bg-slate-800/60 p-2.5 rounded-xl">
            <span className="text-slate-400 block text-[10px] uppercase font-semibold">Router</span>
            <span className="text-emerald-400 font-mono font-bold">HashRouter (#/)</span>
          </div>
          <div className="bg-slate-800/60 p-2.5 rounded-xl">
            <span className="text-slate-400 block text-[10px] uppercase font-semibold">Build Output</span>
            <span className="text-emerald-400 font-mono font-bold">dist/</span>
          </div>
          <div className="bg-slate-800/60 p-2.5 rounded-xl">
            <span className="text-slate-400 block text-[10px] uppercase font-semibold">Runtime Origin</span>
            <span className="text-cyan-400 font-mono font-bold truncate block">{currentProtocol || 'browser'}</span>
          </div>
        </div>
      </div>

      <div id="diagnostic-checks-grid" className="space-y-3">
        <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wide flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          Production Readiness Checklist
        </h3>

        {checks.map((check) => (
          <div
            key={check.id}
            id={`check-item-${check.id}`}
            className="p-4 bg-white rounded-xl border border-slate-200/90 shadow-sm transition hover:border-slate-300"
          >
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-start gap-3">
                <div className={`mt-0.5 p-1 rounded-full ${
                  check.status === 'passed' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'
                }`}>
                  {check.status === 'passed' ? <CheckCircle2 className="w-4 h-4" /> : <AlertTriangle className="w-4 h-4" />}
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-slate-900">{check.title}</h4>
                  <p className="text-xs text-slate-600 mt-0.5">{check.description}</p>
                  <div className="mt-2 text-xs font-mono bg-slate-50 px-2.5 py-1 rounded text-slate-700 inline-block border border-slate-200">
                    {check.detectedValue}
                  </div>
                </div>
              </div>
            </div>
            <div className="mt-2.5 pt-2 border-t border-slate-100 flex items-center gap-1.5 text-[11px] text-slate-500">
              <Info className="w-3.5 h-3.5 text-blue-500 flex-shrink-0" />
              <span>{check.recommendation}</span>
            </div>
          </div>
        ))}
      </div>

      <div id="diagnostic-code-sections" className="space-y-4">
        <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wide flex items-center gap-2">
          <Terminal className="w-4 h-4 text-indigo-600" />
          Production Configuration Files
        </h3>

        <div className="bg-slate-900 rounded-xl overflow-hidden border border-slate-800 text-slate-300 text-xs">
          <div className="bg-slate-950 px-4 py-2.5 flex justify-between items-center border-b border-slate-800">
            <span className="font-mono font-medium text-slate-200 flex items-center gap-2">
              <FileCode className="w-4 h-4 text-amber-400" />
              vite.config.ts
            </span>
            <button
              id="copy-vite-config-btn"
              onClick={() => copyToClipboard(viteConfigSnippet, 'vite')}
              className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded flex items-center gap-1.5 transition text-[11px]"
            >
              {copiedId === 'vite' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              {copiedId === 'vite' ? 'Copied' : 'Copy'}
            </button>
          </div>
          <pre className="p-4 overflow-x-auto font-mono text-[11px] leading-relaxed text-emerald-300/90">
            {viteConfigSnippet}
          </pre>
        </div>

        <div className="bg-slate-900 rounded-xl overflow-hidden border border-slate-800 text-slate-300 text-xs">
          <div className="bg-slate-950 px-4 py-2.5 flex justify-between items-center border-b border-slate-800">
            <span className="font-mono font-medium text-slate-200 flex items-center gap-2">
              <FileCode className="w-4 h-4 text-sky-400" />
              src/main.tsx
            </span>
            <button
              id="copy-main-tsx-btn"
              onClick={() => copyToClipboard(mainTsxSnippet, 'main')}
              className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded flex items-center gap-1.5 transition text-[11px]"
            >
              {copiedId === 'main' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              {copiedId === 'main' ? 'Copied' : 'Copy'}
            </button>
          </div>
          <pre className="p-4 overflow-x-auto font-mono text-[11px] leading-relaxed text-sky-300/90">
            {mainTsxSnippet}
          </pre>
        </div>

        <div className="bg-slate-900 rounded-xl overflow-hidden border border-slate-800 text-slate-300 text-xs">
          <div className="bg-slate-950 px-4 py-2.5 flex justify-between items-center border-b border-slate-800">
            <span className="font-mono font-medium text-slate-200 flex items-center gap-2">
              <FileCode className="w-4 h-4 text-indigo-400" />
              capacitor.config.ts
            </span>
            <button
              id="copy-capacitor-config-btn"
              onClick={() => copyToClipboard(capacitorConfigSnippet, 'capacitor')}
              className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded flex items-center gap-1.5 transition text-[11px]"
            >
              {copiedId === 'capacitor' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              {copiedId === 'capacitor' ? 'Copied' : 'Copy'}
            </button>
          </div>
          <pre className="p-4 overflow-x-auto font-mono text-[11px] leading-relaxed text-indigo-300/90">
            {capacitorConfigSnippet}
          </pre>
        </div>
      </div>

      <div id="gradle-sync-instructions" className="bg-slate-100 p-4 rounded-xl border border-slate-200 text-xs text-slate-700">
        <h4 className="font-bold text-slate-900 text-sm mb-1.5 flex items-center gap-1.5">
          <RefreshCw className="w-4 h-4 text-emerald-700" />
          Terminal Commands to Apply Fix to Android Device
        </h4>
        <ol className="list-decimal list-inside space-y-1 text-slate-600 font-mono text-[11px] mt-2">
          <li>npm run build</li>
          <li>npx cap sync android</li>
          <li>cd android && ./gradlew assembleDebug</li>
          <li>npx cap run android</li>
        </ol>
      </div>
    </div>
  );
};
