import React, { useState, useEffect } from 'react';
import {
  MapPin,
  Compass,
  QrCode,
  ShieldAlert,
  Phone,
  User,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  Bike,
} from 'lucide-react';
import { LocationPoint, VehicleType, Ride, Captain, UserProfile, OperationalCity } from '../../types';
import { OPERATIONAL_ZONES, OPERATIONAL_CITIES, VEHICLES_INFO, FOUNDER_SOS_HOTLINE } from '../../data/constants';
import { rideStore, calculateDistanceKm, calculateFare, estimateDurationMinutes } from '../../services/store';
import { AlwarMap } from '../map/AlwarMap';
import { CashlessPaymentModal } from '../payment/CashlessPaymentModal';
import { MyTrips } from './MyTrips';
import { audioService } from '../../services/audioService';

interface PassengerHomeProps {
  onOpenSos: () => void;
  onOpenAuth: () => void;
}

export const PassengerHome: React.FC<PassengerHomeProps> = ({ onOpenSos, onOpenAuth }) => {
  const [activeTab, setActiveTab] = useState<'book' | 'my_trips'>('book');
  const [selectedCity, setSelectedCity] = useState<OperationalCity>(rideStore.getSelectedCity());
  const [pickup, setPickup] = useState<LocationPoint>(OPERATIONAL_ZONES[0]);
  const [drop, setDrop] = useState<LocationPoint>(OPERATIONAL_ZONES[5]);
  const [vehicleType, setVehicleType] = useState<VehicleType>('bike');
  const [selectionMode, setSelectionMode] = useState<'pickup' | 'drop' | null>(null);
  const [activeRide, setActiveRide] = useState<Ride | null>(rideStore.getActiveRide());
  const [captains, setCaptains] = useState<Captain[]>(rideStore.getCaptains());
  const [user, setUser] = useState<UserProfile | null>(rideStore.getUserProfile());
  const [history, setHistory] = useState<Ride[]>(rideStore.getRideHistory());
  const [showPaymentModal, setShowPaymentModal] = useState<boolean>(false);
  const [bookingError, setBookingError] = useState<string | null>(null);

  useEffect(() => {
    const unsub = rideStore.subscribe(() => {
      setActiveRide(rideStore.getActiveRide());
      setCaptains(rideStore.getCaptains());
      setUser(rideStore.getUserProfile());
      setHistory(rideStore.getRideHistory());
      setSelectedCity(rideStore.getSelectedCity());
    });
    return unsub;
  }, []);

  const handleCityChange = (cityId: string) => {
    rideStore.setSelectedCity(cityId);
    const newCity = rideStore.getSelectedCity();
    setSelectedCity(newCity);
    const cityZones = OPERATIONAL_ZONES.filter(
      (z) => z.cityId === cityId || (!z.cityId && cityId === 'alwar')
    );
    if (cityZones.length >= 2) {
      setPickup(cityZones[0]);
      setDrop(cityZones[1]);
    } else if (cityZones.length === 1) {
      setPickup(cityZones[0]);
    }
    setBookingError(null);
  };

  const distanceKm = calculateDistanceKm(pickup.lat, pickup.lng, drop.lat, drop.lng);
  const fareSettings = rideStore.getSettings();
  const currentFare = calculateFare(distanceKm, vehicleType, fareSettings);
  const estimatedMin = estimateDurationMinutes(distanceKm, vehicleType);

  const handleSelectLocation = (loc: LocationPoint, type: 'pickup' | 'drop') => {
    if (type === 'pickup') {
      setPickup(loc);
    } else {
      setDrop(loc);
    }
    setSelectionMode(null);
  };

  const handleBookRide = () => {
    setBookingError(null);
    const result = rideStore.createRideRequest(pickup, drop, vehicleType);
    if (!result.success) {
      setBookingError(result.error || 'सवारी बुक करने में असमर्थ');
      audioService.playChime('sos');
    } else {
      audioService.playChime('booked');
    }
  };

  const handleCancelRide = () => {
    rideStore.cancelRide();
    audioService.playChime('sos');
  };

  const handleCompleteAndPay = () => {
    if (activeRide) {
      if (activeRide.status !== 'completed') {
        rideStore.completeTrip();
      }
      setShowPaymentModal(true);
    }
  };

  return (
    <div className="space-y-4">
      {/* Top Passenger Bar */}
      <div className="flex items-center justify-between bg-slate-900 border border-slate-800 p-3 rounded-2xl">
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-400 flex items-center justify-center font-bold">
            <User className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs font-bold text-white flex items-center gap-1.5">
              <span>{user?.name || 'सवारी (Rider)'}</span>
              <span className="text-[10px] bg-emerald-500/20 text-emerald-400 px-1.5 py-0.2 rounded font-mono">
                VERIFIED
              </span>
            </div>
            <div className="text-[10px] text-slate-400 font-mono">
              वॉलेट बैलेंस: <strong className="text-amber-400">₹{user?.walletBalance ?? 750}</strong>
            </div>
          </div>
        </div>

        {/* View Switcher: Book / History */}
        <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
          <button
            onClick={() => setActiveTab('book')}
            id="tab-book-ride"
            className={`px-3 py-1.5 rounded-lg font-bold transition-colors ${
              activeTab === 'book' ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-white'
            }`}
          >
            बुक करें (Book)
          </button>
          <button
            onClick={() => setActiveTab('my_trips')}
            id="tab-my-trips"
            className={`px-3 py-1.5 rounded-lg font-bold transition-colors ${
              activeTab === 'my_trips' ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-white'
            }`}
          >
            यात्राएं ({history.length})
          </button>
        </div>
      </div>

      {activeTab === 'my_trips' ? (
        <MyTrips rides={history} onBookNewRide={() => setActiveTab('book')} />
      ) : (
        /* BOOKING WORKFLOW */
        <div className="space-y-4">
          {/* ACTIVE TRIP CARD (IF RIDE IN PROGRESS) */}
          {activeRide && (
            <div className="bg-gradient-to-br from-slate-900 via-slate-900 to-amber-950/30 border-2 border-amber-500 rounded-3xl p-5 shadow-2xl space-y-4 animate-in fade-in duration-300">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
                  <h3 className="font-extrabold text-amber-400 text-sm">
                    {activeRide.status === 'searching'
                      ? 'चालक खोजा जा रहा है... (Searching Captain)'
                      : activeRide.status === 'captain_assigned'
                      ? 'चालक रास्ते में है (Captain on the way)'
                      : activeRide.status === 'arrived'
                      ? 'चालक पहुंच गया है! (Captain Arrived)'
                      : activeRide.status === 'in_trip'
                      ? 'यात्रा जारी है (On the way to destination)'
                      : 'यात्रा समाप्त हुई! (Trip Completed)'}
                  </h3>
                </div>
                <span className="font-mono text-xs font-black text-slate-300 bg-slate-950 px-2.5 py-1 rounded-lg border border-slate-800">
                  {activeRide.id}
                </span>
              </div>

              {/* Ride Details / OTP Display */}
              <div className="grid grid-cols-2 gap-3 bg-slate-950 p-3.5 rounded-2xl border border-slate-800 text-xs">
                <div>
                  <span className="text-slate-400 text-[10px] block">सुरक्षा OTP:</span>
                  <span className="text-xl font-mono font-black text-amber-400 tracking-wider">
                    {activeRide.otp}
                  </span>
                  <span className="text-[10px] text-slate-500 block">चालक को बताएं</span>
                </div>
                <div className="text-right">
                  <span className="text-slate-400 text-[10px] block">किराया:</span>
                  <span className="text-xl font-mono font-black text-emerald-400">
                    ₹{activeRide.fare}
                  </span>
                  <span className="text-[10px] text-slate-400 block">{activeRide.distanceKm} KM</span>
                </div>
              </div>

              {/* Captain Profile Card */}
              {activeRide.captainName && (
                <div className="flex items-center justify-between bg-slate-950/80 p-3 rounded-2xl border border-slate-800 text-xs">
                  <div className="flex items-center gap-3">
                    <img
                      src={activeRide.captainPhoto || 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=100'}
                      alt={activeRide.captainName}
                      className="w-11 h-11 rounded-2xl object-cover border-2 border-amber-500"
                    />
                    <div>
                      <div className="font-bold text-white text-sm">{activeRide.captainName}</div>
                      <div className="text-slate-400 text-[11px] font-mono">
                        {activeRide.vehicleModel} • <strong className="text-amber-300">{activeRide.vehiclePlate}</strong>
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <a
                      href={`tel:${activeRide.captainPhone || FOUNDER_SOS_HOTLINE}`}
                      className="w-9 h-9 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-400 flex items-center justify-center hover:bg-amber-500/30"
                      title="Call Captain"
                    >
                      <Phone className="w-4 h-4" />
                    </a>
                  </div>
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex gap-2 pt-1">
                {activeRide.status !== 'completed' ? (
                  <>
                    <button
                      onClick={handleCompleteAndPay}
                      id="btn-simulate-complete-trip"
                      className="flex-1 py-3 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 text-slate-950 font-black rounded-xl text-xs shadow-lg flex items-center justify-center gap-1.5 active:scale-95"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span>भुगतान करें (Pay ₹{activeRide.fare})</span>
                    </button>
                    <button
                      onClick={handleCancelRide}
                      id="btn-cancel-ride"
                      className="px-4 py-3 bg-slate-800 hover:bg-slate-700 text-rose-400 font-bold rounded-xl text-xs border border-slate-700 active:scale-95"
                    >
                      रद्द करें
                    </button>
                  </>
                ) : (
                  <div className="w-full flex gap-2">
                    <button
                      onClick={() => setShowPaymentModal(true)}
                      id="btn-pay-now-active-ride"
                      className="flex-1 py-3 bg-gradient-to-r from-amber-500 to-amber-400 text-slate-950 font-black rounded-xl text-xs shadow-lg flex items-center justify-center gap-1.5"
                    >
                      <QrCode className="w-4 h-4" />
                      <span>{activeRide.paymentStatus === 'paid' ? 'रसीद देखें (View Receipt)' : `UPI / नकद भुगतान (₹${activeRide.fare})`}</span>
                    </button>
                    <button
                      onClick={() => rideStore.dismissCompletedRide()}
                      className="px-4 py-3 bg-slate-800 text-slate-300 font-bold rounded-xl text-xs"
                    >
                      नयी सवारी (New)
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Multi-State & City Hub Selector */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-3.5 space-y-2.5 shadow-xl">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5 text-xs font-bold text-amber-400">
                <Compass className="w-4 h-4" />
                <span>सक्रिय शहर चुनें (Select Active City)</span>
              </div>
              <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 px-2 py-0.5 rounded-full">
                {selectedCity.state}: {selectedCity.name}
              </span>
            </div>

            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
              {OPERATIONAL_CITIES.map((city) => {
                const isSelected = selectedCity.id === city.id;
                const isKarnataka = city.state === 'Karnataka';
                return (
                  <button
                    key={city.id}
                    type="button"
                    onClick={() => handleCityChange(city.id)}
                    className={`whitespace-nowrap px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 border ${
                      isSelected
                        ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-md scale-105'
                        : 'bg-slate-950/80 text-slate-300 border-slate-800 hover:border-slate-700 hover:text-white'
                    }`}
                  >
                    <span>{city.id === 'alwar' ? '🏰' : city.id === 'jodhpur' ? '☀️' : isKarnataka ? '🏛️' : '📍'}</span>
                    <span>{city.hindiName.split(' (')[0]}</span>
                    <span className={`text-[9px] px-1 py-0.2 rounded font-mono ${
                      isSelected
                        ? 'bg-slate-950/20 text-slate-950 font-black'
                        : isKarnataka
                        ? 'bg-purple-500/20 text-purple-300'
                        : 'bg-amber-500/20 text-amber-300'
                    }`}>
                      {city.state.substring(0, 3).toUpperCase()}
                    </span>
                  </button>
                );
              })}
            </div>
            <div className="text-[10px] text-slate-400 flex items-center justify-between pt-1 border-t border-slate-800/80">
              <span>{selectedCity.tagline}</span>
              <span className="text-amber-400 font-medium">त्रिज्या: {selectedCity.radiusKm} KM</span>
            </div>
          </div>

          {/* Interactive Multi-City Map */}
          <div className="h-64 sm:h-72 w-full">
            <AlwarMap
              pickupLocation={pickup}
              dropLocation={drop}
              captains={captains}
              selectedCity={selectedCity}
              selectionMode={selectionMode}
              onSelectLocation={handleSelectLocation}
            />
          </div>

          {/* Location Selector Inputs */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 space-y-3 text-xs shadow-xl">
            {/* Pickup Selector */}
            <div>
              <div className="flex items-center justify-between text-slate-400 mb-1">
                <span className="flex items-center gap-1.5 font-bold text-slate-300">
                  <div className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
                  <span>प्रारंभिक स्थान (Pickup Location)</span>
                </span>
                <button
                  type="button"
                  onClick={() => setSelectionMode(selectionMode === 'pickup' ? null : 'pickup')}
                  className={`text-[10px] font-bold px-2 py-0.5 rounded transition-colors ${
                    selectionMode === 'pickup'
                      ? 'bg-amber-500 text-slate-950'
                      : 'text-amber-400 hover:underline'
                  }`}
                >
                  {selectionMode === 'pickup' ? 'मानचित्र सक्रिय (Active)' : 'नक्शे पर चुनें'}
                </button>
              </div>
              <select
                value={pickup.id}
                onChange={(e) => {
                  const found = OPERATIONAL_ZONES.find((z) => z.id === e.target.value);
                  if (found) setPickup(found);
                }}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-white font-medium focus:outline-none focus:border-amber-400 text-xs"
              >
                <optgroup label={`सक्रिय शहर: ${selectedCity.name} (${selectedCity.state})`}>
                  {OPERATIONAL_ZONES.filter(
                    (z) => z.cityId === selectedCity.id || (!z.cityId && selectedCity.id === 'alwar')
                  ).map((zone) => (
                    <option key={zone.id} value={zone.id}>
                      {zone.name}
                    </option>
                  ))}
                </optgroup>
                <optgroup label="अन्य शहर (Inter-Zone / Outstation)">
                  {OPERATIONAL_ZONES.filter(
                    (z) => z.cityId !== selectedCity.id && !(z.cityId === undefined && selectedCity.id === 'alwar')
                  ).map((zone) => (
                    <option key={zone.id} value={zone.id}>
                      [{zone.state || 'RJ'}] {zone.name}
                    </option>
                  ))}
                </optgroup>
              </select>
            </div>

            {/* Drop Selector */}
            <div>
              <div className="flex items-center justify-between text-slate-400 mb-1">
                <span className="flex items-center gap-1.5 font-bold text-slate-300">
                  <div className="w-2.5 h-2.5 rounded-full bg-red-400" />
                  <span>गंतव्य स्थान (Drop Location)</span>
                </span>
                <button
                  type="button"
                  onClick={() => setSelectionMode(selectionMode === 'drop' ? null : 'drop')}
                  className={`text-[10px] font-bold px-2 py-0.5 rounded transition-colors ${
                    selectionMode === 'drop'
                      ? 'bg-amber-500 text-slate-950'
                      : 'text-amber-400 hover:underline'
                  }`}
                >
                  {selectionMode === 'drop' ? 'मानचित्र सक्रिय (Active)' : 'नक्शे पर चुनें'}
                </button>
              </div>
              <select
                value={drop.id}
                onChange={(e) => {
                  const found = OPERATIONAL_ZONES.find((z) => z.id === e.target.value);
                  if (found) setDrop(found);
                }}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-white font-medium focus:outline-none focus:border-amber-400 text-xs"
              >
                <optgroup label={`सक्रिय शहर: ${selectedCity.name} (${selectedCity.state})`}>
                  {OPERATIONAL_ZONES.filter(
                    (z) => z.cityId === selectedCity.id || (!z.cityId && selectedCity.id === 'alwar')
                  ).map((zone) => (
                    <option key={zone.id} value={zone.id}>
                      {zone.name}
                    </option>
                  ))}
                </optgroup>
                <optgroup label="अन्य शहर (Inter-Zone / Outstation)">
                  {OPERATIONAL_ZONES.filter(
                    (z) => z.cityId !== selectedCity.id && !(z.cityId === undefined && selectedCity.id === 'alwar')
                  ).map((zone) => (
                    <option key={zone.id} value={zone.id}>
                      [{zone.state || 'RJ'}] {zone.name}
                    </option>
                  ))}
                </optgroup>
              </select>
            </div>

            {/* Distance & Geofence Notice */}
            <div className="flex items-center justify-between pt-2 border-t border-slate-800 text-[11px]">
              <span className="text-slate-400">
                दूरी: <strong className="text-white font-mono">{distanceKm} KM</strong> •{' '}
                <span className="text-slate-400 font-mono">~{estimatedMin} मिनट</span>
              </span>
              <span
                className={`font-bold ${
                  distanceKm <= Math.max(fareSettings.maxRideLimitKm, 75) ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                {distanceKm <= Math.max(fareSettings.maxRideLimitKm, 75)
                  ? `सक्रिय क्षेत्र: ${selectedCity.name}`
                  : 'सीमा से बाहर!'}
              </span>
            </div>
          </div>

          {/* Vehicle Type Selection Cards */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-300 block">
              सवारी का प्रकार चुनें (Select Ride Type)
            </label>
            <div className="grid grid-cols-3 gap-2">
              {VEHICLES_INFO.map((v) => {
                const isSelected = vehicleType === v.type;
                const fare = calculateFare(distanceKm, v.type, fareSettings);
                return (
                  <button
                    key={v.type}
                    type="button"
                    onClick={() => setVehicleType(v.type)}
                    className={`p-3 rounded-2xl border transition-all text-left flex flex-col justify-between ${
                      isSelected
                        ? 'bg-amber-500/10 border-amber-500 text-white shadow-lg'
                        : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xl">{v.icon}</span>
                      <span className="text-[10px] font-mono text-slate-400">~{Math.max(2, Math.round(distanceKm * 2))} min</span>
                    </div>
                    <div>
                      <div className="text-xs font-black text-white">{v.hindiName}</div>
                      <div className="text-[10px] text-slate-400">{v.name}</div>
                    </div>
                    <div className="mt-2 text-base font-black text-amber-400 font-mono">
                      ₹{fare}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {bookingError && (
            <div className="p-3 bg-red-950/80 border border-red-500/80 rounded-2xl text-xs text-red-200 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0" />
              <span>{bookingError}</span>
            </div>
          )}

          {/* Book Ride CTA Button */}
          {!activeRide && (
            <button
              onClick={handleBookRide}
              id="btn-confirm-book-ride"
              className="w-full py-4 bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 text-slate-950 font-black text-sm rounded-2xl shadow-xl shadow-amber-500/20 flex items-center justify-center gap-2 active:scale-[0.99] transition-all"
            >
              <span>{VEHICLES_INFO.find((v) => v.type === vehicleType)?.hindiName} बुक करें — ₹{currentFare}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          )}

          {/* SOS & Helpline Bar */}
          <div className="grid grid-cols-2 gap-2 pt-2">
            <button
              onClick={onOpenSos}
              id="btn-passenger-sos"
              className="py-3 bg-red-950/60 hover:bg-red-900/60 border border-red-500/50 text-red-300 font-black rounded-xl text-xs flex items-center justify-center gap-1.5 shadow"
            >
              <ShieldAlert className="w-4 h-4 text-red-400" />
              <span>FOUNDER SOS (आपातकाल)</span>
            </button>
            <a
              href={`tel:${FOUNDER_SOS_HOTLINE}`}
              className="py-3 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 font-bold rounded-xl text-xs flex items-center justify-center gap-1.5"
            >
              <Phone className="w-4 h-4 text-amber-400" />
              <span>हेल्पलाइन</span>
            </a>
          </div>
        </div>
      )}

      {showPaymentModal && activeRide && (
        <CashlessPaymentModal
          isOpen={showPaymentModal}
          onClose={() => setShowPaymentModal(false)}
          ride={activeRide}
        />
      )}
    </div>
  );
};
