import React, { useState } from 'react';
import {
  Clock,
  CheckCircle2,
  Receipt,
  AlertCircle,
  QrCode,
  User,
} from 'lucide-react';
import { Ride } from '../../types';
import { CashlessPaymentModal } from '../payment/CashlessPaymentModal';

interface MyTripsProps {
  rides: Ride[];
  onBookNewRide?: () => void;
}

export const MyTrips: React.FC<MyTripsProps> = ({ rides, onBookNewRide }) => {
  const [selectedRideForPayment, setSelectedRideForPayment] = useState<Ride | null>(null);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-black text-amber-400">
            मेरी यात्राएं (Ride History)
          </h2>
          <p className="text-xs text-slate-400">
            आपकी पूर्व सवारी एवं भुगतान रसीद लेजर
          </p>
        </div>
        <span className="text-xs font-mono font-bold bg-slate-900 border border-slate-800 text-slate-300 px-3 py-1 rounded-full">
          {rides.length} Rides Total
        </span>
      </div>

      {rides.length === 0 ? (
        <div className="bg-slate-900/60 border border-slate-800 rounded-3xl p-8 text-center space-y-3">
          <div className="w-12 h-12 rounded-full bg-slate-800 text-slate-500 mx-auto flex items-center justify-center">
            <Clock className="w-6 h-6" />
          </div>
          <h3 className="text-sm font-bold text-slate-300">
            कोई पूर्व यात्रा नहीं मिली (No Rides Yet)
          </h3>
          <p className="text-xs text-slate-500 max-w-xs mx-auto">
            आपकी यात्रा का इतिहास यहां सुरक्षित रूप से रिकॉर्ड होगा।
          </p>
          {onBookNewRide && (
            <button
              onClick={onBookNewRide}
              className="px-5 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs rounded-xl shadow-lg transition-transform active:scale-95"
            >
              सवारी बुक करें (Book Now)
            </button>
          )}
        </div>
      ) : (
        <div className="space-y-3">
          {rides.map((ride) => {
            const isPaid = ride.paymentStatus === 'paid';
            return (
              <div
                key={ride.id}
                className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-3xl p-4 transition-all shadow-lg text-white space-y-3"
              >
                {/* Header */}
                <div className="flex items-center justify-between border-b border-slate-800 pb-2.5 text-xs">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-black text-amber-400 text-sm">{ride.id}</span>
                    <span className="text-[10px] bg-slate-800 border border-slate-700 px-2 py-0.5 rounded uppercase font-bold text-slate-300">
                      {ride.vehicleType}
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1 ${
                        isPaid
                          ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                          : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                      }`}
                    >
                      {isPaid ? <CheckCircle2 className="w-3 h-3" /> : <AlertCircle className="w-3 h-3" />}
                      <span>{isPaid ? 'भुगतान पूर्ण (PAID)' : 'भुगतान शेष (PENDING)'}</span>
                    </span>
                  </div>
                </div>

                {/* Route Information */}
                <div className="space-y-1.5 text-xs">
                  <div className="flex items-start gap-2">
                    <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 mt-1 flex-shrink-0" />
                    <div>
                      <span className="text-slate-400 text-[10px] block">स्थान (Pickup):</span>
                      <span className="font-semibold text-slate-200">{ride.pickupLocation.name}</span>
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="w-2.5 h-2.5 rounded-full bg-red-400 mt-1 flex-shrink-0" />
                    <div>
                      <span className="text-slate-400 text-[10px] block">गंतव्य (Drop):</span>
                      <span className="font-semibold text-slate-200">{ride.dropLocation.name}</span>
                    </div>
                  </div>
                </div>

                {/* Details Footer */}
                <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs">
                  <div className="space-y-0.5">
                    <div className="text-slate-400 text-[11px]">
                      {ride.distanceKm} KM • {ride.createdAt}
                    </div>
                    {ride.captainName && (
                      <div className="text-[11px] text-slate-300 font-medium flex items-center gap-1">
                        <User className="w-3 h-3 text-amber-400" />
                        <span>चालक: {ride.captainName} ({ride.vehiclePlate})</span>
                      </div>
                    )}
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-black text-amber-400">₹{ride.fare}</div>
                    {!isPaid ? (
                      <button
                        onClick={() => setSelectedRideForPayment(ride)}
                        className="mt-1 px-3 py-1 bg-gradient-to-r from-amber-500 to-amber-400 text-slate-950 font-black text-[11px] rounded-lg shadow active:scale-95 transition-all flex items-center gap-1"
                      >
                        <QrCode className="w-3 h-3" />
                        <span>UPI भुगतान</span>
                      </button>
                    ) : (
                      <button
                        onClick={() => setSelectedRideForPayment(ride)}
                        className="mt-1 text-[11px] text-emerald-400 hover:underline flex items-center gap-1 font-semibold justify-end"
                      >
                        <Receipt className="w-3 h-3" />
                        <span>रसीद देखें (View Receipt)</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {selectedRideForPayment && (
        <CashlessPaymentModal
          isOpen={true}
          onClose={() => setSelectedRideForPayment(null)}
          ride={selectedRideForPayment}
        />
      )}
    </div>
  );
};
