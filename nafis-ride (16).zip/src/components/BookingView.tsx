import React, { useState } from 'react';
import {
  MapPin,
  Navigation,
  Car,
  Zap,
  Clock,
  ArrowRight,
  CheckCircle,
} from 'lucide-react';
import { RideTier, RideBooking } from '../types';

interface BookingViewProps {
  onBookRide: (booking: Omit<RideBooking, 'id' | 'timestamp'>) => void;
}

export const BookingView: React.FC<BookingViewProps> = ({ onBookRide }) => {
  const [pickup, setPickup] = useState('Central Metro Station, Gate 2');
  const [dropoff, setDropoff] = useState('Tech Hub Park, Tower B');
  const [selectedTier, setSelectedTier] = useState<string>('comfort');
  const [isBooking, setIsBooking] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  const tiers: RideTier[] = [
    {
      id: 'moto',
      name: 'Nafis Moto',
      category: 'Fastest in Traffic',
      etaMinutes: 2,
      basePrice: 4.5,
      capacity: 1,
      iconName: 'bike',
      badge: 'Best Value',
    },
    {
      id: 'standard',
      name: 'Nafis Mini',
      category: 'Affordable Everyday',
      etaMinutes: 4,
      basePrice: 8.2,
      capacity: 4,
      iconName: 'car',
    },
    {
      id: 'comfort',
      name: 'Nafis Comfort',
      category: 'Spacious & Air Conditioned',
      etaMinutes: 3,
      basePrice: 12.8,
      capacity: 4,
      iconName: 'car',
      badge: 'Most Popular',
    },
    {
      id: 'exec',
      name: 'Nafis Premier',
      category: 'Top Rated Drivers & Premium Fleet',
      etaMinutes: 6,
      basePrice: 22.0,
      capacity: 4,
      iconName: 'car',
    },
  ];

  const handleConfirm = () => {
    const tier = tiers.find((t) => t.id === selectedTier) || tiers[1];
    setIsBooking(true);
    setTimeout(() => {
      setIsBooking(false);
      setShowSuccess(true);
      onBookRide({
        pickup,
        dropoff,
        tier: tier.name,
        price: tier.basePrice,
        status: 'driver_assigned',
        driverName: 'Zubair Al-Mansoor',
        driverVehicle: 'Silver Hyundai Elantra',
        licensePlate: 'ND-8492',
        rating: 4.95,
      });
      setTimeout(() => setShowSuccess(false), 3500);
    }, 1200);
  };

  const selectedTierData = tiers.find((t) => t.id === selectedTier) || tiers[1];

  return (
    <div id="booking-view-container" className="space-y-5 pb-20">
      <div id="simulated-map-canvas" className="relative h-44 bg-slate-800 rounded-2xl overflow-hidden border border-slate-700/60 shadow-inner flex flex-col justify-between p-4">
        <div className="absolute inset-0 opacity-15 bg-[radial-gradient(#38bdf8_1px,transparent_1px)] [background-size:16px_16px]"></div>
        <div className="relative z-10 flex justify-between items-start">
          <div className="bg-slate-900/90 backdrop-blur-sm px-2.5 py-1 rounded-full text-[11px] font-medium text-emerald-400 border border-slate-700 flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
            Capacitor GPS Ready
          </div>
          <div className="bg-slate-900/90 backdrop-blur-sm px-2.5 py-1 rounded-full text-[11px] text-slate-300 border border-slate-700">
            ETA: {selectedTierData.etaMinutes} mins
          </div>
        </div>
        <div className="relative z-10 bg-slate-900/90 backdrop-blur-md px-3 py-2 rounded-xl border border-slate-700/80 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2 text-slate-200">
            <Navigation className="w-4 h-4 text-emerald-400" />
            <span className="font-semibold">{selectedTierData.name}</span>
          </div>
          <span className="text-emerald-400 font-mono font-bold text-sm">
            ${selectedTierData.basePrice.toFixed(2)}
          </span>
        </div>
      </div>

      <div id="location-input-card" className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-sm space-y-3">
        <div className="space-y-2.5">
          <div className="flex items-center gap-3">
            <div className="w-7 h-7 rounded-full bg-blue-50 flex items-center justify-center text-blue-600 flex-shrink-0">
              <div className="w-2.5 h-2.5 rounded-full bg-blue-600"></div>
            </div>
            <div className="flex-1">
              <label htmlFor="pickup-input" className="block text-[10px] uppercase font-bold text-slate-400">Pickup Location</label>
              <input
                id="pickup-input"
                type="text"
                value={pickup}
                onChange={(e) => setPickup(e.target.value)}
                className="w-full text-xs font-medium text-slate-800 focus:outline-none focus:text-slate-950 py-0.5 bg-transparent"
                placeholder="Enter pickup point"
              />
            </div>
          </div>
          <div className="h-px bg-slate-100 ml-10"></div>
          <div className="flex items-center gap-3">
            <div className="w-7 h-7 rounded-full bg-emerald-50 flex items-center justify-center text-emerald-600 flex-shrink-0">
              <MapPin className="w-4 h-4 text-emerald-600" />
            </div>
            <div className="flex-1">
              <label htmlFor="dropoff-input" className="block text-[10px] uppercase font-bold text-slate-400">Destination</label>
              <input
                id="dropoff-input"
                type="text"
                value={dropoff}
                onChange={(e) => setDropoff(e.target.value)}
                className="w-full text-xs font-medium text-slate-800 focus:outline-none focus:text-slate-950 py-0.5 bg-transparent"
                placeholder="Where to?"
              />
            </div>
          </div>
        </div>
      </div>

      <div id="ride-tiers-list" className="space-y-2">
        <div className="flex justify-between items-center px-1">
          <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wide">Available Ride Tiers</h3>
          <span className="text-[11px] text-emerald-600 font-medium">Near You</span>
        </div>
        <div className="grid grid-cols-1 gap-2">
          {tiers.map((t) => {
            const isSelected = selectedTier === t.id;
            return (
              <button
                key={t.id}
                id={`tier-select-${t.id}`}
                type="button"
                onClick={() => setSelectedTier(t.id)}
                className={`w-full text-left p-3.5 rounded-xl border transition flex items-center justify-between ${
                  isSelected
                    ? 'border-emerald-500 bg-emerald-50/50 shadow-sm ring-1 ring-emerald-500/20'
                    : 'border-slate-200 bg-white hover:border-slate-300'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                    isSelected ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-600'
                  }`}>
                    {t.id === 'moto' ? <Zap className="w-5 h-5" /> : <Car className="w-5 h-5" />}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="text-xs font-bold text-slate-900">{t.name}</h4>
                      {t.badge && (
                        <span className="text-[9px] font-semibold bg-amber-100 text-amber-800 px-1.5 py-0.5 rounded-full">
                          {t.badge}
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-slate-500">{t.category}</p>
                    <div className="flex items-center gap-2 mt-0.5 text-[10px] text-slate-400">
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" /> {t.etaMinutes} min away
                      </span>
                      <span>•</span>
                      <span>Seats {t.capacity}</span>
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-mono font-bold text-sm text-slate-900">${t.basePrice.toFixed(2)}</div>
                  <span className="text-[10px] text-slate-400 block">estimated</span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      <div id="booking-actions-card" className="pt-2">
        {showSuccess ? (
          <div className="p-3.5 bg-emerald-600 text-white rounded-xl flex items-center justify-center gap-2 text-xs font-semibold shadow-md animate-pulse">
            <CheckCircle className="w-4 h-4" />
            Ride Requested! Driver Zubair assigned.
          </div>
        ) : (
          <button
            id="confirm-ride-btn"
            type="button"
            disabled={isBooking}
            onClick={handleConfirm}
            className="w-full py-3.5 bg-slate-900 hover:bg-slate-800 active:bg-slate-950 text-white font-semibold text-xs rounded-xl shadow-md flex items-center justify-center gap-2 transition disabled:opacity-60"
          >
            {isBooking ? (
              <>
                <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
                Matching Nearby Driver...
              </>
            ) : (
              <>
                Request {selectedTierData.name} (${selectedTierData.basePrice.toFixed(2)})
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        )}
      </div>
    </div>
  );
};
