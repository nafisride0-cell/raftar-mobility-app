import React, { useState, useEffect } from 'react';
import {
  X,
  CreditCard,
  QrCode,
  Wallet,
  Smartphone,
  CheckCircle2,
  Receipt,
  Download,
  ShieldCheck,
  PlusCircle,
  ExternalLink,
  Copy,
  Check,
  Send,
  Loader2,
} from 'lucide-react';
import { Ride, UserProfile, PaymentDetails } from '../../types';
import { rideStore } from '../../services/store';
import { audioService } from '../../services/audioService';
import { FOUNDER_NAME } from '../../data/constants';

interface CashlessPaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  ride: Ride;
}

export const CashlessPaymentModal: React.FC<CashlessPaymentModalProps> = ({
  isOpen,
  onClose,
  ride,
}) => {
  const [user, setUser] = useState<UserProfile | null>(rideStore.getUserProfile());
  const [selectedMethod, setSelectedMethod] = useState<'wallet' | 'upi_apps' | 'upi_qr' | 'webhook_verify'>('upi_apps');
  const [topUpAmount, setTopUpAmount] = useState<number>(200);
  const [showTopUp, setShowTopUp] = useState<boolean>(false);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [copiedUpi, setCopiedUpi] = useState<boolean>(false);
  const [receipt, setReceipt] = useState<PaymentDetails | null>(ride.paymentDetails || null);
  const [customUtr, setCustomUtr] = useState<string>('');
  const [webhookStatus, setWebhookStatus] = useState<string | null>(null);

  useEffect(() => {
    const unsub = rideStore.subscribe(() => {
      setUser(rideStore.getUserProfile());
      const active = rideStore.getActiveRide();
      if (active?.id === ride.id && active.paymentDetails) {
        setReceipt(active.paymentDetails);
      }
    });
    return unsub;
  }, [ride.id]);

  if (!isOpen) return null;

  const captainUpi = ride.captainId
    ? (rideStore.getCaptains().find((c) => c.id === ride.captainId)?.upiId || 'aakash.nafis@upi')
    : 'aakash.nafis@upi';
  const captainName = ride.captainName || 'Nafis Ride Captain';
  const fare = ride.fare;
  const walletBal = user?.walletBalance ?? 750;

  // Strict 12% Platform Commission, 88% Captain Payout
  const settings = rideStore.getSettings();
  const commissionPercentage = settings.commissionPercentage || 12;
  const captainPercentage = 100 - commissionPercentage; // 88%
  const captainCut = Math.round(fare * (captainPercentage / 100));
  const platformFee = Math.round(fare * (commissionPercentage / 100));

  const transactionNote = `NafisRide_Trip_${ride.id}`;
  const merchantOrderId = `NR-ORD-${Date.now().toString().slice(-6)}`;

  const upiIntentUri = `upi://pay?pa=${encodeURIComponent(captainUpi)}&pn=${encodeURIComponent(
    captainName
  )}&mc=4121&tid=${merchantOrderId}&tr=${merchantOrderId}&tn=${encodeURIComponent(
    transactionNote
  )}&am=${fare.toFixed(2)}&cu=INR`;

  const handleCopyUpi = () => {
    navigator.clipboard.writeText(captainUpi);
    setCopiedUpi(true);
    setTimeout(() => setCopiedUpi(false), 2000);
  };

  const handleTopUp = () => {
    rideStore.topUpUserWallet(topUpAmount);
    audioService.playChime('booked');
    setShowTopUp(false);
  };

  const handlePayViaWallet = () => {
    if (walletBal < fare) {
      setShowTopUp(true);
      return;
    }
    setIsProcessing(true);
    setTimeout(() => {
      const res = rideStore.payCashlessRide(ride.id, 'cashless_wallet');
      setIsProcessing(false);
      if (res.success && res.paymentDetails) {
        setReceipt(res.paymentDetails);
        audioService.playChime('completed');
      }
    }, 500);
  };

  const handlePayViaUpiApp = async (appName: string) => {
    setIsProcessing(true);
    setWebhookStatus(`Connecting to ${appName} via upi://pay intent...`);

    if (typeof window !== 'undefined') {
      try {
        window.location.href = upiIntentUri;
      } catch {}
    }

    setTimeout(() => {
      const res = rideStore.payCashlessRide(ride.id, 'upi_intent', { appName });
      setIsProcessing(false);
      setWebhookStatus(null);
      if (res.success && res.paymentDetails) {
        setReceipt(res.paymentDetails);
        audioService.playChime('completed');
      }
    }, 1000);
  };

  const handleTriggerWebhookVerification = async () => {
    setIsProcessing(true);
    setWebhookStatus('Executing PhonePe/UPI Merchant Webhook Callback (/api/payments/verify-webhook)...');
    const generatedUtr = customUtr.trim() || `UPI/${Date.now().toString().slice(-8)}/NR`;

    setTimeout(() => {
      const result = rideStore.payCashlessRide(ride.id, 'upi_qr', {
        appName: 'PhonePe/UPI Webhook Callback',
        customUtr: generatedUtr,
      });
      setIsProcessing(false);
      setWebhookStatus(null);
      if (result.success && result.paymentDetails) {
        setReceipt(result.paymentDetails);
        audioService.playChime('completed');
      }
    }, 800);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-amber-500/50 rounded-3xl max-w-lg w-full p-5 text-white shadow-2xl relative my-auto">
        <button
          onClick={onClose}
          id="btn-close-payment-modal"
          className="absolute top-4 right-4 p-2 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-400"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-2.5 mb-4">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-amber-600 text-slate-950 font-black flex items-center justify-center text-lg shadow-md">
            ₹
          </div>
          <div>
            <h2 className="text-base font-extrabold text-amber-400">
              NAFIS RIDE CASHLESS & UPI PAYMENTS
            </h2>
            <p className="text-xs text-slate-400">
              Production Indian UPI & Webhook Engine
            </p>
          </div>
        </div>

        {/* Commission Transparency Card */}
        <div className="bg-slate-950 border border-amber-500/30 rounded-2xl p-3 mb-4 text-xs space-y-1.5">
          <div className="flex items-center justify-between font-semibold text-slate-300">
            <span>पारदर्शी कमीशन विभाजन (Commission Split):</span>
            <span className="text-emerald-400 font-bold">{captainPercentage}% चालक / {commissionPercentage}% मंच</span>
          </div>
          <div className="grid grid-cols-2 gap-2 text-[11px] pt-1 border-t border-slate-800">
            <div className="bg-slate-900 p-2 rounded-lg">
              <span className="text-slate-400 block text-[10px]">चालक भुगतान ({captainPercentage}%):</span>
              <strong className="text-emerald-400 text-sm font-mono font-black">₹{captainCut}</strong>
            </div>
            <div className="bg-slate-900 p-2 rounded-lg">
              <span className="text-slate-400 block text-[10px]">मंच सेवा शुल्क ({commissionPercentage}%):</span>
              <strong className="text-amber-400 text-sm font-mono font-black">₹{platformFee}</strong>
            </div>
          </div>
        </div>

        {receipt ? (
          <div className="space-y-4">
            <div className="bg-emerald-950/70 border-2 border-emerald-500/60 rounded-3xl p-5 text-center space-y-3 shadow-xl">
              <div className="w-14 h-14 mx-auto rounded-full bg-emerald-500/20 border-2 border-emerald-400 flex items-center justify-center text-emerald-300">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <h3 className="text-lg font-black text-emerald-400">
                भुगतान सफल! (Payment Verified)
              </h3>
              <p className="text-xs text-slate-300">
                चालक <strong className="text-white">{captainName}</strong> को ₹{captainCut} ({captainPercentage}%) तुरंत स्थानांतरित किया गया।
              </p>
            </div>

            <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 text-xs space-y-2.5 font-mono">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="text-slate-400">Receipt No:</span>
                <span className="text-amber-400 font-bold">{receipt.receiptId}</span>
              </div>
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="text-slate-400">UTR / Ref No:</span>
                <span className="text-slate-200 font-bold">{receipt.utrNumber}</span>
              </div>
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="text-slate-400">Payment Mode:</span>
                <span className="text-emerald-400 font-bold">{receipt.appName || receipt.method}</span>
              </div>
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="text-slate-400">Captain UPI:</span>
                <span className="text-slate-200 font-bold">{captainUpi}</span>
              </div>
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="text-slate-400">Captain Credit ({captainPercentage}%):</span>
                <span className="text-emerald-400 font-bold">₹{captainCut}</span>
              </div>
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="text-slate-400">Platform Commission ({commissionPercentage}%):</span>
                <span className="text-amber-400 font-bold">₹{platformFee}</span>
              </div>
              <div className="flex items-center justify-between text-sm pt-1">
                <span className="text-slate-300 font-bold font-sans">कुल भुगतान (Total Paid):</span>
                <span className="text-xl font-black text-amber-400">₹{fare}</span>
              </div>
            </div>

            <div className="flex gap-2">
              <button
                onClick={() => window.print()}
                id="btn-print-receipt"
                className="flex-1 py-3 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 border border-slate-700"
              >
                <Download className="w-4 h-4 text-amber-400" />
                <span>रसीद प्रिंट करें (Print Tax Receipt)</span>
              </button>
              <button
                onClick={onClose}
                id="btn-done-payment"
                className="flex-1 py-3 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black rounded-xl text-xs flex items-center justify-center shadow-lg"
              >
                <span>पूर्ण (Done)</span>
              </button>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="bg-slate-950 border border-amber-500/40 rounded-2xl p-4 flex items-center justify-between">
              <div>
                <span className="text-xs text-slate-400 block">कुल किराया (Payable Fare)</span>
                <div className="text-2xl font-black text-amber-400">₹{fare}</div>
                <span className="text-[10px] text-slate-400">
                  {ride.distanceKm} KM • {ride.vehicleType.toUpperCase()} ({captainName})
                </span>
              </div>
              <div className="text-right">
                <span className="text-[10px] bg-amber-500/20 text-amber-300 border border-amber-500/30 px-2 py-0.5 rounded-full font-bold">
                  Verified UPI Deep Link
                </span>
              </div>
            </div>

            {/* Payment Method Switcher Tabs */}
            <div className="grid grid-cols-4 gap-1 p-1 bg-slate-950 rounded-2xl border border-slate-800 text-xs">
              <button
                type="button"
                onClick={() => setSelectedMethod('upi_apps')}
                className={`py-2 px-1 rounded-xl font-bold transition-all flex flex-col items-center gap-1 ${
                  selectedMethod === 'upi_apps'
                    ? 'bg-amber-500 text-slate-950 shadow'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Smartphone className="w-4 h-4" />
                <span className="text-[10px] leading-tight">UPI Apps</span>
              </button>
              <button
                type="button"
                onClick={() => setSelectedMethod('upi_qr')}
                className={`py-2 px-1 rounded-xl font-bold transition-all flex flex-col items-center gap-1 ${
                  selectedMethod === 'upi_qr'
                    ? 'bg-amber-500 text-slate-950 shadow'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <QrCode className="w-4 h-4" />
                <span className="text-[10px] leading-tight">क्यूआर QR</span>
              </button>
              <button
                type="button"
                onClick={() => setSelectedMethod('wallet')}
                className={`py-2 px-1 rounded-xl font-bold transition-all flex flex-col items-center gap-1 ${
                  selectedMethod === 'wallet'
                    ? 'bg-amber-500 text-slate-950 shadow'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Wallet className="w-4 h-4" />
                <span className="text-[10px] leading-tight">वॉलेट</span>
              </button>
              <button
                type="button"
                onClick={() => setSelectedMethod('webhook_verify')}
                className={`py-2 px-1 rounded-xl font-bold transition-all flex flex-col items-center gap-1 ${
                  selectedMethod === 'webhook_verify'
                    ? 'bg-amber-500 text-slate-950 shadow'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Send className="w-4 h-4" />
                <span className="text-[10px] leading-tight">Webhook</span>
              </button>
            </div>

            {selectedMethod === 'upi_apps' && (
              <div className="space-y-3">
                <div className="text-xs text-slate-300 font-semibold">
                  सीधे UPI ऐप से भुगतान करें (UPI Deep Linking Intent):
                </div>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { name: 'PhonePe', color: 'from-purple-600 to-indigo-600' },
                    { name: 'Google Pay', color: 'from-blue-600 to-blue-500' },
                    { name: 'Paytm UPI', color: 'from-sky-600 to-cyan-500' },
                    { name: 'BHIM UPI', color: 'from-emerald-600 to-teal-600' },
                  ].map((app) => (
                    <button
                      key={app.name}
                      type="button"
                      onClick={() => handlePayViaUpiApp(app.name)}
                      disabled={isProcessing}
                      className="p-3 bg-slate-950 border border-slate-800 hover:border-amber-400 rounded-2xl text-left flex items-center justify-between transition-all active:scale-95 group disabled:opacity-50"
                    >
                      <div>
                        <div className="font-extrabold text-xs text-white group-hover:text-amber-400">
                          {app.name}
                        </div>
                        <div className="text-[10px] text-slate-400 font-mono">₹{fare}</div>
                      </div>
                      <span className="text-[11px] font-black px-2 py-1 rounded bg-slate-900 border border-slate-700 text-amber-300">
                        PAY
                      </span>
                    </button>
                  ))}
                </div>

                <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800 text-xs space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Captain UPI:</span>
                    <button
                      type="button"
                      onClick={handleCopyUpi}
                      className="text-amber-400 font-mono font-bold flex items-center gap-1 hover:underline text-[11px]"
                    >
                      {copiedUpi ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                      <span>{captainUpi}</span>
                    </button>
                  </div>
                  <div className="text-[10px] font-mono text-slate-400 break-all bg-slate-900 p-2 rounded-lg border border-slate-800">
                    {upiIntentUri}
                  </div>
                  <a
                    href={upiIntentUri}
                    className="block w-full py-2.5 text-center bg-gradient-to-r from-amber-500 to-amber-400 text-slate-950 font-black rounded-xl text-xs shadow flex items-center justify-center gap-1.5 active:scale-98"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>Launch UPI App Intent (upi://pay)</span>
                  </a>
                </div>
              </div>
            )}

            {selectedMethod === 'upi_qr' && (
              <div className="space-y-3 text-center">
                <p className="text-xs text-slate-300">
                  ₹{fare} का भुगतान करने हेतु QR स्कैन करें:
                </p>
                <div className="inline-block p-3 bg-white rounded-3xl shadow-xl border-4 border-amber-500">
                  <img
                    src={`https://api.qrserver.com/v1/create-qr-code/?size=170x170&data=${encodeURIComponent(
                      upiIntentUri
                    )}`}
                    alt="Captain Ride QR Code"
                    className="w-40 h-40 mx-auto"
                  />
                  <div className="mt-1 text-[10px] font-mono font-bold text-slate-800">
                    SCAN TO PAY ₹{fare} • {captainUpi}
                  </div>
                </div>

                <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800 text-xs space-y-2 text-left">
                  <label className="text-slate-400 text-[11px] block">
                    भुगतान के बाद 12-अंकीय UPI UTR संदर्भ दर्ज करें:
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      maxLength={16}
                      value={customUtr}
                      onChange={(e) => setCustomUtr(e.target.value)}
                      placeholder="उदा. 428190281902"
                      className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-amber-400"
                    />
                    <button
                      type="button"
                      onClick={handleTriggerWebhookVerification}
                      disabled={isProcessing}
                      id="btn-confirm-qr-paid"
                      className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black rounded-xl text-xs shadow active:scale-95 disabled:opacity-50"
                    >
                      पुष्टि करें (Confirm)
                    </button>
                  </div>
                </div>
              </div>
            )}

            {selectedMethod === 'wallet' && (
              <div className="space-y-3">
                <div className="bg-gradient-to-br from-slate-950 to-amber-950/40 border border-amber-500/30 rounded-2xl p-4">
                  <div className="flex items-center justify-between text-xs mb-1">
                    <span className="text-slate-400">उपलब्ध वॉलेट बैलेंस:</span>
                    <span className="text-[10px] text-amber-400 font-bold font-mono">1-TAP PAY</span>
                  </div>
                  <div className="text-2xl font-black text-white mb-2">
                    ₹{walletBal}
                  </div>
                  {walletBal >= fare ? (
                    <div className="text-xs text-emerald-400 flex items-center gap-1.5 font-medium">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>सवारी भुगतान हेतु पर्याप्त बैलेंस उपलब्ध</span>
                    </div>
                  ) : (
                    <div className="text-xs text-rose-400 flex items-center gap-1.5 font-medium">
                      <span>कम बैलेंस (किराया: ₹{fare})</span>
                    </div>
                  )}
                  <div className="mt-3 pt-3 border-t border-slate-800 flex items-center justify-between">
                    <button
                      type="button"
                      onClick={() => setShowTopUp(!showTopUp)}
                      className="text-xs font-bold text-amber-400 flex items-center gap-1 hover:underline"
                    >
                      <PlusCircle className="w-3.5 h-3.5" />
                      <span>{showTopUp ? 'छुपाएं' : 'राशि जोड़ें (Add Money)'}</span>
                    </button>
                  </div>
                </div>

                {showTopUp && (
                  <div className="p-3 bg-slate-950 border border-slate-800 rounded-2xl space-y-2">
                    <div className="text-xs text-slate-300 font-bold">त्वरित रीचार्ज राशि:</div>
                    <div className="grid grid-cols-4 gap-1.5">
                      {[100, 200, 500, 1000].map((amt) => (
                        <button
                          key={amt}
                          type="button"
                          onClick={() => setTopUpAmount(amt)}
                          className={`py-1.5 rounded-lg text-xs font-bold font-mono transition-colors ${
                            topUpAmount === amt
                              ? 'bg-amber-500 text-slate-950'
                              : 'bg-slate-900 text-slate-300 border border-slate-700'
                          }`}
                        >
                          +₹{amt}
                        </button>
                      ))}
                    </div>
                    <button
                      type="button"
                      onClick={handleTopUp}
                      className="w-full py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black rounded-xl text-xs shadow mt-1"
                    >
                      ₹{topUpAmount} तुरंत रीचार्ज करें (Instant Top-Up)
                    </button>
                  </div>
                )}

                <button
                  type="button"
                  disabled={isProcessing || walletBal < fare}
                  onClick={handlePayViaWallet}
                  id="btn-pay-via-wallet"
                  className="w-full py-3.5 bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 text-slate-950 font-black rounded-xl text-xs shadow-lg shadow-amber-500/20 active:scale-98 disabled:opacity-50 transition-all flex items-center justify-center gap-2"
                >
                  <Wallet className="w-4 h-4" />
                  <span>{isProcessing ? 'प्रक्रियाधीन...' : `₹${fare} वॉलेट से भुगतान करें (Instant Pay)`}</span>
                </button>
              </div>
            )}

            {selectedMethod === 'webhook_verify' && (
              <div className="space-y-3">
                <div className="bg-slate-950 border border-amber-500/40 rounded-2xl p-4 text-xs space-y-2.5">
                  <div className="flex items-center gap-2 text-amber-400 font-bold">
                    <Send className="w-4 h-4" />
                    <span>PhonePe Customer-To-Merchant Webhook Callback</span>
                  </div>
                  <p className="text-slate-300 text-[11px] leading-relaxed">
                    यह एंडपॉइंट <code>/api/payments/verify-webhook</code> पर सीधे सर्वर वित्तीय लेजर में <strong>88% (₹{captainCut})</strong> चालक के खाते में तथा 12% (₹{platformFee}) मंच खाते में विभाजित करता है।
                  </p>
                  <div className="bg-slate-900 p-2.5 rounded-xl border border-slate-800 font-mono text-[10px] text-slate-300 space-y-1">
                    <div>Endpoint: <span className="text-emerald-400">POST /api/payments/verify-webhook</span></div>
                    <div>Captain ID: <span className="text-white">{ride.captainId || 'cpt_01'}</span></div>
                    <div>Ride Fare: <span className="text-amber-400">₹{fare}</span></div>
                    <div>Captain Credit (88%): <span className="text-emerald-400 font-bold">₹{captainCut}</span></div>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleTriggerWebhookVerification}
                  disabled={isProcessing}
                  id="btn-execute-webhook-callback"
                  className="w-full py-3.5 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 text-slate-950 font-black rounded-xl text-xs shadow-lg flex items-center justify-center gap-2 active:scale-98 disabled:opacity-50 transition-all"
                >
                  {isProcessing ? <Loader2 className="w-4 h-4 animate-spin" /> : <ShieldCheck className="w-4 h-4" />}
                  <span>वेबहुक सत्यापन निष्पादित करें (Trigger Webhook Verification)</span>
                </button>
              </div>
            )}

            {isProcessing && webhookStatus && (
              <div className="p-3 bg-slate-950 border border-amber-500/40 rounded-xl flex items-center gap-2 text-xs text-amber-300">
                <Loader2 className="w-4 h-4 animate-spin text-amber-400" />
                <span>{webhookStatus}</span>
              </div>
            )}
          </div>
        )}

        <div className="mt-4 pt-3 border-t border-slate-800 text-center text-[10px] text-slate-500 flex items-center justify-center gap-1">
          <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
          <span>Nafis Ride Cashless Security   Founder: {FOUNDER_NAME}</span>
        </div>
      </div>
    </div>
  );
};
