import React, { useState, useEffect } from 'react';
import {
  Power,
  TrendingUp,
  MapPin,
  CheckCircle2,
  Phone,
  ShieldCheck,
  CreditCard,
  QrCode,
  AlertTriangle,
  User,
  Radio,
  FileCheck,
  ChevronRight,
  ShieldAlert,
  Volume2,
} from 'lucide-react';
import { Captain, Ride, VehicleType } from '../../types';
import { rideStore } from '../../services/store';
import { audioService } from '../../services/audioService';
import { AlwarMap } from '../map/AlwarMap';
import { CashlessPaymentModal } from '../payment/CashlessPaymentModal';
import { OPERATIONAL_CITIES } from '../../data/constants';

interface CaptainHomeProps {
  onOpenSos: () => void;
  onOpenAuth: () => void;
}

export const CaptainHome: React.FC<CaptainHomeProps> = ({ onOpenSos, onOpenAuth }) => {
  const [captain, setCaptain] = useState<Captain | null>(rideStore.getCaptainProfile());
  const [activeRide, setActiveRide] = useState<Ride | null>(rideStore.getActiveRide());
  const [inputOtp, setInputOtp] = useState<string>('');
  const [otpError, setOtpError] = useState<string | null>(null);
  const [showIdCard, setShowIdCard] = useState<boolean>(false);
  const [showKycForm, setShowKycForm] = useState<boolean>(false);
  const [showPaymentModal, setShowPaymentModal] = useState<boolean>(false);
  const [shayariPlaying, setShayariPlaying] = useState<boolean>(false);
  const [selectedCityId, setSelectedCityId] = useState<string>(captain?.cityId || 'alwar');

  // KYC Form State
  const [aadhaarNumber, setAadhaarNumber] = useState(captain?.kycDocs?.aadhaarNumber || '5829 1902 4819');
  const [dlNumber, setDlNumber] = useState(captain?.kycDocs?.drivingLicenseNumber || 'RJ-02-2021-009182');
  const [rcNumber, setRcNumber] = useState(captain?.kycDocs?.rcNumber || 'RJ-02-SA-4821');
  const [vehiclePlate, setVehiclePlate] = useState(captain?.vehiclePlate || 'RJ-02-SA-4821');
  const [vehicleModel, setVehicleModel] = useState(captain?.vehicleModel || 'Hero Splendor Plus');
  const [vehicleType, setVehicleType] = useState<VehicleType>(captain?.vehicleType || 'bike');
  const [bloodGroup, setBloodGroup] = useState(captain?.bloodGroup || 'B+');
  const [kycCityId, setKycCityId] = useState<string>(captain?.cityId || 'alwar');

  useEffect(() => {
    const unsub = rideStore.subscribe(() => {
      setCaptain(rideStore.getCaptainProfile());
      setActiveRide(rideStore.getActiveRide());
    });
    return unsub;
  }, []);

  if (!captain) {
    return (
      <div className="p-8 text-center text-white space-y-3 bg-slate-900 rounded-3xl border border-slate-800">
        <User className="w-12 h-12 mx-auto text-slate-500" />
        <h3 className="text-base font-bold">चालक प्रोफ़ाइल उपलब्ध नहीं</h3>
        <p className="text-xs text-slate-400">कृपया चालक के रूप में लॉगिन करें।</p>
        <button
          onClick={onOpenAuth}
          className="px-5 py-2.5 bg-amber-500 text-slate-950 font-black rounded-xl text-xs"
        >
          चालक लॉगिन (Captain Login)
        </button>
      </div>
    );
  }

  const isOnline = captain.isOnline;
  const isKycApproved = captain.kycStatus === 'approved';

  const handleToggleDuty = () => {
    const newState = rideStore.toggleCaptainDuty(captain.id);
    if (newState) {
      audioService.playChime('booked');
    } else {
      audioService.playChime('sos');
    }
  };

  const handleStartTrip = (e: React.FormEvent) => {
    e.preventDefault();
    setOtpError(null);
    const res = rideStore.startTrip(inputOtp.trim());
    if (!res.success) {
      setOtpError(res.error || 'गलत OTP दर्ज किया गया');
      audioService.playChime('sos');
    } else {
      audioService.playChime('booked');
      setInputOtp('');
    }
  };

  const handleCompleteTrip = () => {
    rideStore.completeTrip();
    audioService.playChime('completed');
    setShowPaymentModal(true);
  };

  const handlePlayMotivationalVoice = () => {
    setShayariPlaying(true);
    audioService.playHindiMotivationalShayari(() => {
      setShayariPlaying(false);
    });
  };

  const handleSubmitKyc = (e: React.FormEvent) => {
    e.preventDefault();
    rideStore.submitCaptainKyc(
      {
        ...captain,
        cityId: kycCityId,
      },
      {
        aadhaarNumber,
        drivingLicenseNumber: dlNumber,
        rcNumber,
        vehiclePlate,
        vehicleModel,
        vehicleType,
        bloodGroup,
      }
    );
    setSelectedCityId(kycCityId);
    setShowKycForm(false);
    audioService.playChime('completed');
  };

  return (
    <div className="space-y-4">
      {/* Top Captain Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 flex items-center justify-between shadow-xl">
        <div className="flex items-center gap-3">
          <div className="relative">
            <img
              src={captain.photoUrl}
              alt={captain.name}
              className="w-12 h-12 rounded-2xl object-cover border-2 border-amber-500 shadow-md"
            />
            <span
              className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-slate-900 ${
                isOnline ? 'bg-emerald-400 animate-pulse' : 'bg-slate-500'
              }`}
            />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h2 className="text-sm font-black text-white">{captain.name}</h2>
              <span
                className={`text-[9px] px-1.5 py-0.5 rounded font-bold uppercase ${
                  captain.kycStatus === 'approved'
                    ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                    : captain.kycStatus === 'rejected'
                    ? 'bg-rose-500/20 text-rose-400 border border-rose-500/40'
                    : 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
                }`}
              >
                {captain.kycStatus === 'approved' ? 'KYC VERIFIED' : 'KYC PENDING'}
              </span>
            </div>
            <div className="text-[11px] text-slate-400 font-mono">
              {captain.vehicleModel} • <strong className="text-amber-300">{captain.vehiclePlate}</strong>
            </div>
          </div>
        </div>

        {/* Duty Toggle Button */}
        <button
          onClick={handleToggleDuty}
          id="btn-toggle-captain-duty"
          className={`px-4 py-2.5 rounded-2xl font-black text-xs flex items-center gap-2 transition-all active:scale-95 shadow-lg ${
            isOnline
              ? 'bg-emerald-500 text-slate-950 ring-4 ring-emerald-500/20'
              : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700'
          }`}
        >
          <Power className={`w-4 h-4 ${isOnline ? 'animate-spin' : ''}`} />
          <span>{isOnline ? 'ड्यूटी चालू (ONLINE)' : 'ड्यूटी बंद (OFFLINE)'}</span>
        </button>
      </div>

      {/* Daily Earnings & Metrics Banner */}
      <div className="grid grid-cols-3 gap-2 text-center text-xs">
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3">
          <div className="text-[10px] text-slate-400 font-medium">कमाई (Today)</div>
          <div className="text-lg font-black text-emerald-400 font-mono mt-0.5">
            ₹{captain.todayEarnings}
          </div>
          <div className="text-[9px] text-slate-500">88% चालक हिस्सा</div>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3">
          <div className="text-[10px] text-slate-400 font-medium">वॉलेट (Wallet)</div>
          <div className="text-lg font-black text-amber-400 font-mono mt-0.5">
            ₹{captain.walletBalance}
          </div>
          <div className="text-[9px] text-slate-500">त्वरित UPI निकासी</div>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3">
          <div className="text-[10px] text-slate-400 font-medium">सवारियां (Trips)</div>
          <div className="text-lg font-black text-cyan-400 font-mono mt-0.5">
            {captain.totalTrips}
          </div>
          <div className="text-[9px] text-slate-500">⭐ {captain.rating}</div>
        </div>
      </div>

      {/* Motivational Voice & Id Card Strip */}
      <div className="grid grid-cols-2 gap-2">
        <button
          onClick={handlePlayMotivationalVoice}
          id="btn-play-voice-cheer"
          disabled={shayariPlaying}
          className="p-3 bg-gradient-to-r from-amber-500/10 to-amber-600/20 border border-amber-500/40 rounded-2xl text-left flex items-center justify-between text-xs text-amber-300 font-bold active:scale-98 transition-all"
        >
          <div className="flex items-center gap-2">
            <Volume2 className="w-4 h-4 text-amber-400 animate-bounce" />
            <div>
              <div className="text-white text-xs">प्रेरणादायक शायरी</div>
              <div className="text-[10px] text-amber-400 font-normal">Hindi Voice Audio</div>
            </div>
          </div>
          <span className="text-[10px] bg-amber-500 text-slate-950 px-2 py-0.5 rounded font-black">
            PLAY
          </span>
        </button>

        <button
          onClick={() => setShowIdCard(!showIdCard)}
          id="btn-view-captain-id-card"
          className="p-3 bg-slate-900 border border-slate-800 rounded-2xl text-left flex items-center justify-between text-xs text-slate-200 font-bold active:scale-98 hover:border-slate-700 transition-all"
        >
          <div className="flex items-center gap-2">
            <FileCheck className="w-4 h-4 text-emerald-400" />
            <div>
              <div className="text-white text-xs">चालक पहचान पत्र</div>
              <div className="text-[10px] text-slate-400 font-normal">Official Driver ID</div>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-400" />
        </button>
      </div>

      {/* OFFICIAL NAFIS RIDE CAPTAIN ID CARD */}
      {showIdCard && (
        <div className="bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950/40 border-2 border-amber-500 rounded-3xl p-5 shadow-2xl space-y-4 text-white">
          <div className="flex items-center justify-between border-b border-amber-500/30 pb-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-amber-500 text-slate-950 font-black flex items-center justify-center text-xs">
                NR
              </div>
              <div>
                <h4 className="text-xs font-black text-amber-400 tracking-wider">
                  NAFIS RIDE AUTHORIZED CAPTAIN
                </h4>
                <p className="text-[9px] text-slate-400">Government Compliant Mobility Permit</p>
              </div>
            </div>
            <span className="text-[9px] bg-emerald-500 text-slate-950 px-2 py-0.5 rounded font-black">
              ACTIVE
            </span>
          </div>

          <div className="flex gap-4">
            <img
              src={captain.photoUrl}
              alt={captain.name}
              className="w-20 h-24 rounded-2xl object-cover border-2 border-amber-400 shadow-md"
            />
            <div className="space-y-1 text-xs">
              <div className="font-black text-sm text-white">{captain.name}</div>
              <div className="text-slate-400 text-[11px]">
                DL No: <strong className="text-slate-200 font-mono">{captain.kycDocs?.drivingLicenseNumber || 'RJ-02-2021-009182'}</strong>
              </div>
              <div className="text-slate-400 text-[11px]">
                Aadhaar: <strong className="text-slate-200 font-mono">{captain.kycDocs?.aadhaarNumber || '5829 1902 4819'}</strong>
              </div>
              <div className="text-slate-400 text-[11px]">
                वाहन नंबर: <strong className="text-amber-400 font-mono">{captain.vehiclePlate}</strong>
              </div>
              <div className="text-slate-400 text-[11px]">
                रक्त समूह: <strong className="text-red-400 font-bold">{captain.bloodGroup || 'B+'}</strong>
              </div>
            </div>
          </div>

          <div className="pt-2 border-t border-slate-800 text-[10px] text-slate-400 flex items-center justify-between">
            <span>Verified by: Founder Nafis Khan</span>
            <span>Validity: 2026-2029</span>
          </div>
        </div>
      )}

      {/* ACTIVE RIDE ASSIGNMENT CARD FOR CAPTAIN */}
      {activeRide && (activeRide.captainId === captain.id || activeRide.status === 'searching') ? (
        <div className="bg-gradient-to-br from-slate-900 to-amber-950/30 border-2 border-amber-500 rounded-3xl p-5 shadow-2xl space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
              <h3 className="font-black text-amber-400 text-sm">
                {activeRide.status === 'searching'
                  ? 'नयी सवारी उपलब्ध! (Accept Ride Request)'
                  : activeRide.status === 'captain_assigned'
                  ? 'सवारी की ओर रवाना हों'
                  : activeRide.status === 'arrived'
                  ? 'सवारी से OTP लें एवं शुरू करें'
                  : activeRide.status === 'in_trip'
                  ? 'यात्रा जारी है'
                  : 'सवारी पूर्ण हुई! (Trip Completed)'}
              </h3>
            </div>
            <span className="font-mono text-xs font-bold text-slate-300 bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
              {activeRide.id}
            </span>
          </div>

          {/* Passenger Info */}
          <div className="flex items-center justify-between bg-slate-950 p-3 rounded-2xl border border-slate-800 text-xs">
            <div className="space-y-0.5">
              <div className="font-bold text-white text-sm">{activeRide.riderName}</div>
              <div className="text-slate-400 text-[11px] font-mono">{activeRide.riderPhone}</div>
            </div>
            <div className="text-right">
              <div className="text-lg font-black text-emerald-400 font-mono">
                ₹{activeRide.fare}
              </div>
              <div className="text-[10px] text-slate-400">{activeRide.distanceKm} KM</div>
            </div>
          </div>

          {/* Locations */}
          <div className="space-y-1.5 text-xs">
            <div className="flex items-start gap-2">
              <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 mt-1 flex-shrink-0" />
              <div>
                <span className="text-slate-400 text-[10px] block">पिकअप:</span>
                <span className="font-semibold text-slate-200">{activeRide.pickupLocation.name}</span>
              </div>
            </div>
            <div className="flex items-start gap-2">
              <div className="w-2.5 h-2.5 rounded-full bg-red-400 mt-1 flex-shrink-0" />
              <div>
                <span className="text-slate-400 text-[10px] block">ड्रॉप:</span>
                <span className="font-semibold text-slate-200">{activeRide.dropLocation.name}</span>
              </div>
            </div>
          </div>

          {/* Captain Action Triggers based on status */}
          {activeRide.status === 'searching' && (
            <button
              onClick={() => {
                rideStore.manualOverrideDispatch(captain.id, activeRide.id);
                audioService.playChime('booked');
              }}
              className="w-full py-3.5 bg-gradient-to-r from-emerald-500 to-emerald-400 hover:from-emerald-400 text-slate-950 font-black rounded-xl text-xs shadow-lg flex items-center justify-center gap-1.5 active:scale-95"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>सवारी स्वीकार करें (Accept Ride - ₹{activeRide.fare})</span>
            </button>
          )}

          {activeRide.status === 'captain_assigned' && (
            <button
              onClick={() => {
                activeRide.status = 'arrived';
                rideStore.manualOverrideDispatch(captain.id, activeRide.id);
              }}
              className="w-full py-3.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-xl text-xs shadow-lg"
            >
              <span>पिकअप पर पहुंच गए (I Have Arrived)</span>
            </button>
          )}

          {activeRide.status === 'arrived' && (
            <form onSubmit={handleStartTrip} className="space-y-2">
              <label className="text-xs text-slate-300 font-bold block">
                सवारी सुरक्षा OTP दर्ज करें (Enter Ride OTP):
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  maxLength={4}
                  value={inputOtp}
                  onChange={(e) => setInputOtp(e.target.value.replace(/\D/g, ''))}
                  placeholder="उदा. 4819"
                  className="flex-1 bg-slate-950 border border-amber-500 rounded-xl px-4 py-2.5 text-center text-white font-mono font-black text-lg tracking-widest focus:outline-none"
                />
                <button
                  type="submit"
                  id="btn-captain-verify-otp"
                  className="px-5 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black rounded-xl text-xs shadow"
                >
                  सवारी शुरू करें
                </button>
              </div>
              {otpError && <div className="text-xs text-rose-400 font-semibold">{otpError}</div>}
            </form>
          )}

          {activeRide.status === 'in_trip' && (
            <button
              onClick={handleCompleteTrip}
              id="btn-captain-complete-trip"
              className="w-full py-4 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 text-slate-950 font-black rounded-xl text-xs shadow-xl flex items-center justify-center gap-2 active:scale-95"
            >
              <CheckCircle2 className="w-5 h-5" />
              <span>यात्रा समाप्त करें (Complete Trip - Collect ₹{activeRide.fare})</span>
            </button>
          )}

          {activeRide.status === 'completed' && (
            <div className="space-y-2">
              <button
                onClick={() => setShowPaymentModal(true)}
                className="w-full py-3 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-xl text-xs shadow-lg flex items-center justify-center gap-1.5"
              >
                <QrCode className="w-4 h-4" />
                <span>डिजिटल UPI QR प्राप्त करें (Receive Payment)</span>
              </button>
              <button
                onClick={() => rideStore.dismissCompletedRide()}
                className="w-full py-2 bg-slate-800 text-slate-300 font-bold rounded-xl text-xs"
              >
                पूर्ण (Done)
              </button>
            </div>
          )}
        </div>
      ) : (
        /* Standby GPS Map View */
        <div className="space-y-3">
          {/* Captain Operating City Hub Selector */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 flex items-center justify-between text-xs">
            <span className="text-slate-400 font-medium flex items-center gap-1.5">
              <span>सक्रिय परिचालन क्षेत्र:</span>
            </span>
            <select
              value={selectedCityId}
              onChange={(e) => {
                const newCityId = e.target.value;
                setSelectedCityId(newCityId);
                const cityObj = OPERATIONAL_CITIES.find((c) => c.id === newCityId);
                if (cityObj && captain) {
                  rideStore.updateCaptainCurrentLocation(cityObj.center.lat, cityObj.center.lng, newCityId);
                }
              }}
              className="bg-slate-950 border border-slate-700 rounded-xl px-2.5 py-1 text-amber-400 font-bold text-xs focus:outline-none"
            >
              {OPERATIONAL_CITIES.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.state}: {c.hindiName.split(' (')[0]}
                </option>
              ))}
            </select>
          </div>

          <div className="h-64 w-full">
            <AlwarMap
              pickupLocation={null}
              dropLocation={null}
              captains={[captain]}
              selectedCity={OPERATIONAL_CITIES.find((c) => c.id === selectedCityId) || OPERATIONAL_CITIES[0]}
              interactive={false}
            />
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 text-xs text-center space-y-2">
            <div className="flex items-center justify-center gap-2 text-amber-400 font-bold">
              <Radio className={`w-4 h-4 ${isOnline ? 'animate-ping' : ''}`} />
              <span>
                {isOnline
                  ? `${OPERATIONAL_CITIES.find((c) => c.id === selectedCityId)?.name || 'अलवर'} में नयी सवारियों की प्रतीक्षा...`
                  : 'ड्यूटी शुरू करने के लिए ऊपर बटन दबाएं'}
              </span>
            </div>
            <p className="text-slate-400 text-[11px]">
              पृष्ठभूमि जीपीएस एवं पुश नोटिफिकेशन सक्रिय हैं।
            </p>
          </div>
        </div>
      )}

      {/* KYC Update Trigger */}
      {!isKycApproved && (
        <div className="p-4 bg-amber-950/40 border border-amber-500/40 rounded-3xl flex items-center justify-between text-xs text-white">
          <div className="flex items-center gap-2.5">
            <AlertTriangle className="w-5 h-5 text-amber-400 flex-shrink-0" />
            <div>
              <div className="font-bold text-amber-300">KYC सत्यापन बाकी है</div>
              <div className="text-[10px] text-slate-400">सत्यापन के बिना बुकिंग नहीं मिलेगी</div>
            </div>
          </div>
          <button
            onClick={() => setShowKycForm(!showKycForm)}
            className="px-3 py-1.5 bg-amber-500 text-slate-950 font-black rounded-xl text-xs shadow"
          >
            KYC भरें
          </button>
        </div>
      )}

      {/* KYC Form Modal / Drawer */}
      {showKycForm && (
        <form
          onSubmit={handleSubmitKyc}
          className="bg-slate-900 border border-slate-800 rounded-3xl p-5 text-xs text-white space-y-3 shadow-2xl"
        >
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <h3 className="font-extrabold text-amber-400 text-sm">
              चालक KYC सत्यापन (Driver Onboarding)
            </h3>
            <button
              type="button"
              onClick={() => setShowKycForm(false)}
              className="text-slate-400 hover:text-white"
            >
              बंद करें
            </button>
          </div>

          <div>
            <label className="block text-[11px] text-slate-400 mb-1">आधार नंबर (Aadhaar No):</label>
            <input
              type="text"
              value={aadhaarNumber}
              onChange={(e) => setAadhaarNumber(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono"
            />
          </div>

          <div>
            <label className="block text-[11px] text-slate-400 mb-1">ड्राइविंग लाइसेंस (DL No):</label>
            <input
              type="text"
              value={dlNumber}
              onChange={(e) => setDlNumber(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono"
            />
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-[11px] text-slate-400 mb-1">गाड़ी नंबर (Vehicle Plate):</label>
              <input
                type="text"
                value={vehiclePlate}
                onChange={(e) => setVehiclePlate(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono"
              />
            </div>
            <div>
              <label className="block text-[11px] text-slate-400 mb-1">रक्त समूह (Blood Group):</label>
              <input
                type="text"
                value={bloodGroup}
                onChange={(e) => setBloodGroup(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono"
              />
            </div>
          </div>

          <div>
            <label className="block text-[11px] text-slate-400 mb-1">परिचालन शहर (Operating City Hub):</label>
            <select
              value={kycCityId}
              onChange={(e) => setKycCityId(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-amber-300 font-bold text-xs"
            >
              {OPERATIONAL_CITIES.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.state}: {c.hindiName} ({c.name})
                </option>
              ))}
            </select>
          </div>

          <button
            type="submit"
            className="w-full py-3 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black rounded-xl text-xs shadow-lg mt-2"
          >
            दस्तावेज़ जमा करें (Submit KYC)
          </button>
        </form>
      )}

      {/* SOS Button */}
      <div className="pt-2">
        <button
          onClick={onOpenSos}
          id="btn-captain-sos"
          className="w-full py-3 bg-red-950/70 hover:bg-red-900/70 border border-red-500/50 text-red-300 font-black rounded-2xl text-xs flex items-center justify-center gap-2 shadow-lg"
        >
          <ShieldAlert className="w-4 h-4 text-red-400" />
          <span>चालक आपातकालीन बीकन (Captain SOS Beacon)</span>
        </button>
      </div>

      {showPaymentModal && activeRide && (
        <CashlessPaymentModal
          isOpen={showPaymentModal}
          onClose={() => setShowPaymentModal(false)}
          ride={activeRide}
        />
      )}
    </div>
  );
};
