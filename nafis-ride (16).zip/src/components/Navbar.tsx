import React from 'react';
import { NavLink } from 'react-router-dom';
import {
  Compass,
  Bike,
  ShieldCheck,
  ShieldAlert,
  Terminal,
  Zap,
} from 'lucide-react';
import { FOUNDER_NAME, BRAND_NAME_HINDI } from '../data/constants';

interface NavbarProps {
  onOpenSos: () => void;
  onOpenAuth: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenSos }) => {
  return (
    <>
      {/* Top Mobile/Desktop Header - High-Octane Sporty Black & Neon Yellow */}
      <header
        id="app-top-header"
        className="sticky top-0 z-40 bg-slate-950/95 backdrop-blur-md text-white border-b border-yellow-400/20 px-4 py-2.5 shadow-lg shadow-black/60"
      >
        <div className="max-w-2xl mx-auto flex items-center justify-between">
          <NavLink to="/" className="flex items-center gap-2.5 group">
            {/* Sporty High-Octane Badge */}
            <div className="w-9 h-9 rounded-2xl shadow-md shadow-yellow-400/40 bg-gradient-to-r from-yellow-400 to-amber-400 text-slate-950 font-black font-sans flex items-center justify-center text-base group-hover:scale-105 transition-transform">
              RF
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-base font-black tracking-wider text-yellow-400 font-sans leading-tight">
                  RAFTAR
                </span>
                <span className="text-xs bg-yellow-400/10 border border-yellow-400/30 text-yellow-300 px-1.5 py-0.5 rounded-full font-bold font-hindi">
                  {BRAND_NAME_HINDI}
                </span>
              </div>
              <span className="text-[10px] text-slate-400 block font-medium">
                Founder: {FOUNDER_NAME}   Delhi NCR   RJ   KA
              </span>
            </div>
          </NavLink>

          <div className="flex items-center gap-2">
            {/* SOS Emergency Hotline Button */}
            <button
              onClick={onOpenSos}
              id="header-btn-sos"
              className="px-3 py-1.5 rounded-full bg-red-600 hover:bg-red-500 text-white font-black text-xs flex items-center gap-1.5 shadow-md shadow-red-600/40 active:scale-95 transition-all border border-red-500/40"
            >
              <ShieldAlert className="w-3.5 h-3.5 animate-pulse text-white" />
              <span>SOS आपातकाल</span>
            </button>

            {/* Diagnostic / Android Status Badge */}
            <NavLink
              to="/status"
              id="header-btn-status"
              className={({ isActive }) =>
                `px-2.5 py-1.5 rounded-xl text-[10px] font-bold border transition flex items-center gap-1 ${
                  isActive
                    ? 'bg-yellow-400/20 text-yellow-300 border-yellow-400/60 shadow-sm shadow-yellow-400/20'
                    : 'bg-slate-900 text-slate-300 border-slate-800 hover:border-yellow-400/30'
                }`
              }
              title="Capacitor 8 Android Fix & System Status"
            >
              <span className="w-2 h-2 rounded-full bg-yellow-400 animate-ping" />
              <Zap className="w-3 h-3 text-yellow-400" />
              <span className="hidden sm:inline">GPS</span>
            </NavLink>
          </div>
        </div>
      </header>

      {/* Bottom Sticky Mobile Navigation Bar */}
      <nav
        id="app-bottom-nav"
        className="fixed bottom-0 left-0 right-0 z-40 bg-slate-950/95 backdrop-blur-md border-t border-yellow-400/20 px-2 py-1.5 shadow-2xl"
      >
        <div className="max-w-md mx-auto grid grid-cols-4 gap-1">
          <NavLink
            to="/"
            end
            id="nav-link-passenger"
            className={({ isActive }) =>
              `flex flex-col items-center justify-center py-1.5 rounded-2xl transition text-[10px] font-bold ${
                isActive
                  ? 'text-slate-950 bg-gradient-to-r from-yellow-400 to-amber-400 shadow-md shadow-yellow-400/30 font-black'
                  : 'text-slate-400 hover:text-slate-200'
              }`
            }
          >
            <Compass className="w-4 h-4 mb-0.5" />
            <span>सवारी (Rider)</span>
          </NavLink>

          <NavLink
            to="/captain"
            id="nav-link-captain"
            className={({ isActive }) =>
              `flex flex-col items-center justify-center py-1.5 rounded-2xl transition text-[10px] font-bold ${
                isActive
                  ? 'text-slate-950 bg-gradient-to-r from-yellow-400 to-amber-400 shadow-md shadow-yellow-400/30 font-black'
                  : 'text-slate-400 hover:text-slate-200'
              }`
            }
          >
            <Bike className="w-4 h-4 mb-0.5" />
            <span>चालक (Captain)</span>
          </NavLink>

          <NavLink
            to="/admin"
            id="nav-link-admin"
            className={({ isActive }) =>
              `flex flex-col items-center justify-center py-1.5 rounded-2xl transition text-[10px] font-bold ${
                isActive
                  ? 'text-slate-950 bg-gradient-to-r from-yellow-400 to-amber-400 shadow-md shadow-yellow-400/30 font-black'
                  : 'text-slate-400 hover:text-slate-200'
              }`
            }
          >
            <ShieldCheck className="w-4 h-4 mb-0.5" />
            <span>नियंत्रण (Admin)</span>
          </NavLink>

          <NavLink
            to="/status"
            id="nav-link-status"
            className={({ isActive }) =>
              `flex flex-col items-center justify-center py-1.5 rounded-2xl transition text-[10px] font-bold ${
                isActive
                  ? 'text-slate-950 bg-gradient-to-r from-yellow-400 to-amber-400 shadow-md shadow-yellow-400/30 font-black'
                  : 'text-slate-400 hover:text-slate-200'
              }`
            }
          >
            <Terminal className="w-4 h-4 mb-0.5" />
            <span>जांच</span>
          </NavLink>
        </div>
      </nav>
    </>
  );
};
