import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertTriangle, RefreshCw } from 'lucide-react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
  errorInfo: ErrorInfo | null;
}

export class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null,
    errorInfo: null,
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error, errorInfo: null };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Nafis Ride Uncaught Error:', error, errorInfo);
    this.setState({ errorInfo });
  }

  public handleReload = () => {
    window.location.reload();
  };

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-slate-950 text-white flex flex-col items-center justify-center p-6 text-center">
          <div className="w-16 h-16 rounded-3xl bg-amber-500/20 border-2 border-amber-500 flex items-center justify-center text-amber-400 mb-4 shadow-xl">
            <AlertTriangle className="w-8 h-8" />
          </div>
          <h1 className="text-xl font-black text-amber-400 mb-2">
            एप्लिकेशन लोड करने में समस्या हुई
          </h1>
          <p className="text-xs text-slate-300 max-w-sm mb-4">
            मोबाइल नेटवर्क ड्रॉप अथवा कैशे त्रुटि के कारण रीलोड की आवश्यकता है।
          </p>
          {this.state.error && (
            <div className="bg-slate-900 border border-slate-800 p-3 rounded-2xl text-[11px] font-mono text-rose-300 max-w-sm w-full mb-5 text-left overflow-x-auto">
              {this.state.error.toString()}
            </div>
          )}
          <button
            onClick={this.handleReload}
            className="px-6 py-3 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-2xl text-xs flex items-center gap-2 shadow-lg active:scale-95"
          >
            <RefreshCw className="w-4 h-4" />
            <span>पुनः लोड करें (Reload App)</span>
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}
