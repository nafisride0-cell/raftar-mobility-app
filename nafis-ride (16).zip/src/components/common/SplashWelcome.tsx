import React, { useState } from 'react';
import { ShieldCheck, ArrowRight, Zap, CheckCircle2, Phone } from 'lucide-react';
import { audioService } from '../../services/audioService';
import {
  FOUNDER_NAME,
  FOUNDER_TAGLINE,
  SUPPORT_EMAIL,
  FOUNDER_SOS_HOTLINE,
} from '../../data/constants';

interface SplashWelcomeProps {
  isOpen?: boolean;
  onDismiss?: () => void;
  onStart?: () => void;
  onOpenAuth?: (phone?: string) => void;
}

export const SplashWelcome: React.FC<SplashWelcomeProps> = ({
  isOpen = true,
  onDismiss,
  onStart,
  onOpenAuth,
}) => {
  const [phoneNumber, setPhoneNumber] = useState('');

  if (!isOpen) return null;

  const handleClose = () => {
    if (onStart) onStart();
    else if (onDismiss) onDismiss();
  };

  const handleQuickLoginAndStart = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    audioService.playChime('welcome');
    const cleaned = phoneNumber.replace(/\D/g, '').slice(-10);
    if (cleaned.length === 10 && onOpenAuth) {
      onOpenAuth(cleaned);
    } else {
      handleClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950 flex flex-col justify-between items-center p-6 text-white select-none overflow-y-auto">
      {/* Top Corporate Brand Header */}
      <div className="w-full max-w-md pt-3 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-2xl shadow-md shadow-yellow-400/40 bg-gradient-to-r from-yellow-400 to-amber-400 text-slate-950 font-black font-sans flex items-center justify-center text-xl">
            RF
          </div>
          <div>
            <h1 className="font-black tracking-tight text-lg text-yellow-400 font-sans">
              RAFTAR MOBILITY <span className="text-sm text-yellow-300 font-hindi font-bold">(रफ़्तार)</span>
            </h1>
            <p className="text-[11px] text-slate-300 font-medium font-hindi">
              भारत की सबसे तेज़ सवारी   संस्थापक: {FOUNDER_NAME}
            </p>
          </div>
        </div>
        <div className="bg-yellow-400/10 border border-yellow-400/30 px-2.5 py-1 rounded-full text-[10px] font-bold text-yellow-300 flex items-center gap-1 shadow-sm">
          <ShieldCheck className="w-3.5 h-3.5 text-yellow-400" />
          <span>Delhi NCR & Haryana Live</span>
        </div>
      </div>

      {/* Center Presentation & Auth Card */}
      <div className="w-full max-w-md my-auto py-5 space-y-4">
        {/* Sleek High-Octane Brand Card */}
        <div className="bg-slate-900 border border-yellow-400/30 rounded-3xl p-6 shadow-2xl relative overflow-hidden">
          <div className="flex items-center gap-2 text-yellow-400 font-bold text-xs uppercase tracking-wider mb-2">
            <Zap className="w-4 h-4 text-yellow-400 fill-yellow-400" />
            <span>High-Octane Hyperlocal Mobility</span>
          </div>
          <h2 className="text-xl font-black text-white leading-snug font-hindi">
            ट्रैफिक चाहे जितना भारी, सबसे तेज़ रफ़्तार हमारी!
          </h2>
          <div className="mt-4 space-y-3 text-xs">
            <div className="flex items-start gap-2.5 text-slate-200">
              <CheckCircle2 className="w-4 h-4 text-yellow-400 flex-shrink-0 mt-0.5" />
              <span><strong>रफ़्तार प्रीमियम टैरिफ:</strong> भारी ट्रैफिक को चीरता सिर्फ ₹8/KM बाइक किराया!</span>
            </div>
            <div className="flex items-start gap-2.5 text-slate-200">
              <CheckCircle2 className="w-4 h-4 text-yellow-400 flex-shrink-0 mt-0.5" />
              <span><strong>कैप्टन फर्स्ट पॉलिसी:</strong> केवल 12% प्लेटफ़ॉर्म फीस, बाकी 88% तुरंत आपके UPI/वॉलेट में!</span>
            </div>
            <div className="flex items-start gap-2.5 text-slate-200">
              <CheckCircle2 className="w-4 h-4 text-yellow-400 flex-shrink-0 mt-0.5" />
              <span><strong>24/7 अभेद्य सुरक्षा:</strong> दिल्ली, गुरुग्राम, हरियाणा और राजस्थान में फाउंडर नफीस खान आपातकालीन कंट्रोल रूम और पुलिस 112 से रीयल-टाइम कनेक्शन।</span>
            </div>
          </div>
        </div>

        {/* Mobile Number Auth Card */}
        <form
          onSubmit={handleQuickLoginAndStart}
          className="bg-slate-900 border border-yellow-400/30 rounded-3xl p-5 shadow-xl space-y-3"
        >
          <div className="flex items-center justify-between text-xs">
            <span className="font-bold text-yellow-300 flex items-center gap-1.5 font-hindi text-sm">
              <Phone className="w-3.5 h-3.5 text-yellow-400" />
              <span>रफ़्तार ऐप में आपका स्वागत है</span>
            </span>
            <span className="text-[10px] text-yellow-400 font-mono font-bold">Fast2SMS DLT</span>
          </div>

          <div className="relative">
            <div className="absolute left-3.5 top-1/2 -translate-y-1/2 flex items-center gap-1.5 text-xs font-bold text-slate-400 border-r border-slate-700 pr-2 pointer-events-none">
              <span>🇮🇳</span>
              <span>+91</span>
            </div>
            <input
              type="tel"
              maxLength={10}
              value={phoneNumber}
              onChange={(e) => setPhoneNumber(e.target.value.replace(/\D/g, ''))}
              placeholder="10-अंकीय मोबाइल नंबर दर्ज करें"
              className="w-full bg-slate-950 border border-slate-700 rounded-2xl pl-20 pr-4 py-3.5 text-white font-mono font-bold text-sm tracking-wider focus:outline-none focus:border-yellow-400 transition-colors"
            />
          </div>

          <button
            type="submit"
            id="btn-get-started-ride"
            disabled={phoneNumber.length !== 10}
            className="w-full py-3.5 shadow-md shadow-yellow-400/40 bg-gradient-to-r from-yellow-400 to-amber-400 text-slate-950 font-black font-sans text-sm rounded-2xl flex items-center justify-center gap-2 active:scale-[0.99] transition-all hover:brightness-105 disabled:opacity-50"
          >
            <span>
              {phoneNumber.length === 10
                ? 'OTP प्राप्त करें (Get Fast2SMS OTP)'
                : '10-अंकीय मोबाइल नंबर दर्ज करें'}
            </span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        {/* Live Metrics Strip */}
        <div className="grid grid-cols-3 gap-2 text-center text-xs">
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-2.5">
            <div className="font-mono font-black text-yellow-400 text-base">₹20</div>
            <div className="text-[10px] text-slate-400 mt-0.5">Base Fare</div>
          </div>
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-2.5">
            <div className="font-mono font-black text-yellow-300 text-base">45 KM</div>
            <div className="text-[10px] text-slate-400 mt-0.5">NCR Coverage</div>
          </div>
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-2.5">
            <div className="font-mono font-black text-emerald-400 text-base">3.2 Min</div>
            <div className="text-[10px] text-slate-400 mt-0.5">Avg Pickup</div>
          </div>
        </div>
      </div>

      {/* Bottom Compliance & Founder Tagline */}
      <div className="w-full max-w-md pb-4 text-center space-y-1">
        <p className="text-xs font-bold text-yellow-400/90 tracking-wide font-hindi">
          {FOUNDER_TAGLINE}
        </p>
        <p className="text-[10px] text-slate-400">
          24/7 Helpline: <span className="text-yellow-400 font-mono">{FOUNDER_SOS_HOTLINE}</span>   Email:{' '}
          <a href={`mailto:${SUPPORT_EMAIL}`} className="text-yellow-400 underline">
            {SUPPORT_EMAIL}
          </a>
        </p>
      </div>
    </div>
  );
};
