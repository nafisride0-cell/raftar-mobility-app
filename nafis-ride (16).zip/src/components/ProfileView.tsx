import React, { useState } from 'react';
import {
  ShieldCheck,
  Smartphone,
  HardDrive,
  Wifi,
  Layers,
  Trash2,
  Check,
  CheckCircle2,
} from 'lucide-react';
import { rideStore } from '../services/store';

export const ProfileView: React.FC = () => {
  const [cacheCleared, setCacheCleared] = useState(false);
  const user = rideStore.getUserProfile();

  const handleClearCache = () => {
    localStorage.clear();
    setCacheCleared(true);
    setTimeout(() => setCacheCleared(false), 2500);
  };

  return (
    <div id="profile-view-container" className="space-y-5 pb-20">
      <div id="user-profile-card" className="p-4 bg-white rounded-2xl border border-slate-200 shadow-sm flex items-center gap-3">
        <div className="w-12 h-12 rounded-2xl bg-emerald-600 text-white flex items-center justify-center font-bold text-lg shadow-sm">
          {user?.name?.[0] || 'NR'}
        </div>
        <div>
          <h3 className="text-sm font-bold text-slate-900">{user?.name || 'Verified Rider'}</h3>
          <p className="text-xs text-slate-500">{user?.email || 'rider@nafisride.in'}</p>
          <span className="inline-flex items-center gap-1 text-[10px] text-emerald-700 font-semibold bg-emerald-50 px-2 py-0.5 rounded-full mt-1">
            <ShieldCheck className="w-3 h-3 text-emerald-600" />
            Capacitor 8 Mobile Verified
          </span>
        </div>
      </div>

      <div id="runtime-health-card" className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm space-y-3">
        <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wide">Mobile Storage & Asset Resolver</h4>
        <div className="space-y-2.5 text-xs">
          <div className="flex justify-between items-center py-1 border-b border-slate-100">
            <span className="text-slate-600 flex items-center gap-2">
              <HardDrive className="w-3.5 h-3.5 text-slate-400" />
              Target Storage
            </span>
            <span className="font-mono text-slate-800 font-medium">file:///android_asset/</span>
          </div>
          <div className="flex justify-between items-center py-1 border-b border-slate-100">
            <span className="text-slate-600 flex items-center gap-2">
              <Layers className="w-3.5 h-3.5 text-slate-400" />
              Asset Link Style
            </span>
            <span className="font-mono text-emerald-600 font-medium font-bold">Relative (./assets)</span>
          </div>
          <div className="flex justify-between items-center py-1 border-b border-slate-100">
            <span className="text-slate-600 flex items-center gap-2">
              <Smartphone className="w-3.5 h-3.5 text-slate-400" />
              Target Engine
            </span>
            <span className="text-slate-800 font-medium">Android System WebView</span>
          </div>
          <div className="flex justify-between items-center py-1">
            <span className="text-slate-600 flex items-center gap-2">
              <Wifi className="w-3.5 h-3.5 text-slate-400" />
              Offline Ready
            </span>
            <span className="text-emerald-600 font-semibold flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" /> Active
            </span>
          </div>
        </div>
      </div>

      <div id="profile-actions" className="space-y-2">
        <button
          id="clear-cache-btn"
          type="button"
          onClick={handleClearCache}
          className="w-full p-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold flex items-center justify-center gap-2 transition"
        >
          {cacheCleared ? (
            <>
              <Check className="w-4 h-4 text-emerald-600" />
              Local Storage Cache Reset
            </>
          ) : (
            <>
              <Trash2 className="w-4 h-4 text-slate-500" />
              Clear Local App Storage
            </>
          )}
        </button>
      </div>
    </div>
  );
};
