import React, { useState } from 'react';
import {
  Compass,
  Radar,
  MapPin,
  ShieldCheck,
  AlertTriangle,
  Layers,
  Crosshair,
} from 'lucide-react';
import { OPERATIONAL_ZONES, OPERATIONAL_CITIES, ALWAR_CENTER_COORDS } from '../../data/constants';
import { calculateDistanceKm } from '../../services/store';

export const AdminGeofenceRadar: React.FC = () => {
  const [selectedCityId, setSelectedCityId] = useState<string>('alwar');
  const activeCity = OPERATIONAL_CITIES.find((c) => c.id === selectedCityId) || OPERATIONAL_CITIES[0];

  const cityZones = OPERATIONAL_ZONES.filter(
    (z) => z.cityId === selectedCityId || (!z.cityId && selectedCityId === 'alwar')
  );

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 text-white space-y-4 shadow-xl">
      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
        <div>
          <div className="flex items-center gap-2">
            <Radar className="w-5 h-5 text-amber-400 animate-spin" />
            <h3 className="font-extrabold text-amber-400 text-sm">
              मल्टी-स्टेट जियोफ़ेंस एवं लैंडमार्क रडार (Multi-State Geofence Radar)
            </h3>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            राजस्थान (अलवर, जयपुर, जोधपुर, कोटा) एवं कर्नाटक (बेंगलुरु, मैसूर) परिचालन हब
          </p>
        </div>
        <select
          value={selectedCityId}
          onChange={(e) => setSelectedCityId(e.target.value)}
          className="bg-slate-950 border border-amber-500/50 rounded-xl px-3 py-1.5 text-xs text-amber-400 font-bold focus:outline-none"
        >
          {OPERATIONAL_CITIES.map((c) => (
            <option key={c.id} value={c.id}>
              {c.state}: {c.hindiName.split(' (')[0]} ({c.name})
            </option>
          ))}
        </select>
      </div>

      {/* City Hub Metrics Banner */}
      <div className="grid grid-cols-3 gap-2 text-center text-xs">
        <div className="bg-slate-950 p-2.5 rounded-2xl border border-slate-800">
          <span className="text-[10px] text-slate-400 block">परिचालन त्रिज्या (Radius)</span>
          <span className="text-base font-black text-amber-400 font-mono mt-0.5 block">
            {activeCity.radiusKm} KM
          </span>
        </div>
        <div className="bg-slate-950 p-2.5 rounded-2xl border border-slate-800">
          <span className="text-[10px] text-slate-400 block">प्रमुख लैंडमार्क (Pois)</span>
          <span className="text-base font-black text-emerald-400 font-mono mt-0.5 block">
            {cityZones.length} Zones
          </span>
        </div>
        <div className="bg-slate-950 p-2.5 rounded-2xl border border-slate-800">
          <span className="text-[10px] text-slate-400 block">जीपीएस केंद्र (HQ Lat/Lng)</span>
          <span className="text-[11px] font-bold text-cyan-400 font-mono mt-1 block">
            {activeCity.center.lat.toFixed(4)}, {activeCity.center.lng.toFixed(4)}
          </span>
        </div>
      </div>

      {/* Landmarks list in city */}
      <div className="space-y-2">
        <div className="flex items-center justify-between text-xs text-slate-400">
          <span className="font-semibold text-slate-300">
            {activeCity.name} के सक्रिय पिकअप एवं ड्रॉप लैंडमार्क:
          </span>
          <span className="font-mono text-[10px]">Active Polygon Bounds</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {cityZones.map((zone) => {
            const distFromCenter = calculateDistanceKm(
              zone.lat,
              zone.lng,
              activeCity.center.lat,
              activeCity.center.lng
            );
            return (
              <div
                key={zone.id}
                className="bg-slate-950 border border-slate-800 p-3 rounded-2xl flex items-center justify-between text-xs hover:border-slate-700 transition"
              >
                <div className="space-y-0.5">
                  <div className="font-bold text-white flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-amber-400 flex-shrink-0" />
                    <span>{zone.name}</span>
                  </div>
                  <div className="text-[10px] text-slate-400 font-mono">
                    Lat: {zone.lat.toFixed(4)}, Lng: {zone.lng.toFixed(4)}
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-emerald-400 font-mono font-bold text-xs">
                    {distFromCenter} KM
                  </span>
                  <span className="text-[9px] text-slate-500 block">from Center</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
        <div className="flex items-center gap-1.5">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span>Active Geofence Enforcement Layer</span>
        </div>
        <span className="text-amber-400 font-mono">{activeCity.tagline}</span>
      </div>
    </div>
  );
};
