import React, { useState } from 'react';
import {
  X,
  Radio,
  Send,
  User,
  MapPin,
  CheckCircle2,
  AlertTriangle,
  Zap,
} from 'lucide-react';
import { Captain, Ride } from '../../types';
import { rideStore } from '../../services/store';
import { audioService } from '../../services/audioService';

interface UrgentDispatchModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeRide: Ride | null;
  captains: Captain[];
}

export const UrgentDispatchModal: React.FC<UrgentDispatchModalProps> = ({
  isOpen,
  onClose,
  activeRide,
  captains,
}) => {
  const [selectedCaptainId, setSelectedCaptainId] = useState<string>(
    captains[0]?.id || 'cpt_01'
  );
  const [isDispatching, setIsDispatching] = useState<boolean>(false);
  const [success, setSuccess] = useState<boolean>(false);

  if (!isOpen) return null;

  const handleDispatch = () => {
    if (!activeRide) return;
    setIsDispatching(true);
    setTimeout(() => {
      rideStore.manualOverrideDispatch(selectedCaptainId, activeRide.id);
      setIsDispatching(false);
      setSuccess(true);
      audioService.playChime('booked');
      setTimeout(() => {
        setSuccess(false);
        onClose();
      }, 1500);
    }, 600);
  };

  const selectedCaptain = captains.find((c) => c.id === selectedCaptainId);

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-amber-500/50 rounded-3xl max-w-md w-full p-5 text-white shadow-2xl relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full bg-slate-800 text-slate-400 hover:text-white"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="flex items-center gap-2.5 mb-4">
          <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/50 flex items-center justify-center text-amber-400">
            <Radio className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <h3 className="text-base font-extrabold text-amber-400">
              तत्काल मैनुअल प्रेषण (Urgent Manual Dispatch)
            </h3>
            <p className="text-xs text-slate-400">
              संस्थापक सुपर-एडमिन राइड असाइनमेंट
            </p>
          </div>
        </div>

        {activeRide ? (
          <div className="space-y-4 text-xs">
            <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800 space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-400">सवारी आईडी:</span>
                <span className="font-mono font-bold text-amber-400">{activeRide.id}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">यात्री:</span>
                <span className="font-bold text-white">{activeRide.riderName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">किराया / दूरी:</span>
                <span className="font-bold text-emerald-400">₹{activeRide.fare} ({activeRide.distanceKm} KM)</span>
              </div>
            </div>

            <div>
              <label className="block text-slate-300 font-bold mb-1.5">
                चालक का चयन करें (Assign Captain):
              </label>
              <select
                value={selectedCaptainId}
                onChange={(e) => setSelectedCaptainId(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-white font-medium focus:outline-none focus:border-amber-400"
              >
                {captains.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name} ({c.vehicleModel} - {c.vehiclePlate}) • {c.isOnline ? 'ONLINE' : 'OFFLINE'}
                  </option>
                ))}
              </select>
            </div>

            {selectedCaptain && (
              <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800 flex items-center gap-3">
                <img
                  src={selectedCaptain.photoUrl}
                  alt={selectedCaptain.name}
                  className="w-10 h-10 rounded-xl object-cover border border-amber-500"
                />
                <div>
                  <div className="font-bold text-white">{selectedCaptain.name}</div>
                  <div className="text-[11px] text-slate-400 font-mono">
                    {selectedCaptain.vehicleModel} • {selectedCaptain.phone}
                  </div>
                </div>
              </div>
            )}

            {success ? (
              <div className="p-3 bg-emerald-950/70 border border-emerald-500 rounded-2xl text-emerald-300 flex items-center justify-center gap-2 font-bold">
                <CheckCircle2 className="w-4 h-4" />
                <span>सवारी सफलतापूर्वक चालक को सौंपी गई!</span>
              </div>
            ) : (
              <button
                type="button"
                onClick={handleDispatch}
                disabled={isDispatching}
                className="w-full py-3.5 bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 text-slate-950 font-black rounded-xl text-xs shadow-lg flex items-center justify-center gap-2 active:scale-95 disabled:opacity-50"
              >
                <Zap className="w-4 h-4" />
                <span>{isDispatching ? 'प्रेषित हो रहा है...' : 'तुरंत प्रेषित करें (Override Dispatch)'}</span>
              </button>
            )}
          </div>
        ) : (
          <div className="p-6 text-center text-xs text-slate-400 bg-slate-950 rounded-2xl border border-slate-800">
            कोई सक्रिय या लंबित सवारी उपलब्ध नहीं है।
          </div>
        )}
      </div>
    </div>
  );
};
