import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  TrendingUp,
  Users,
  Settings,
  AlertTriangle,
  Radio,
  CheckCircle2,
  Lock,
  RefreshCw,
  Phone,
  Power,
  Layers,
  Award,
  Compass,
  KeyRound,
  FileCheck,
  Send,
  Zap,
} from 'lucide-react';
import { Captain, Ride, SosAlert, AppSettings } from '../../types';
import { rideStore } from '../../services/store';
import { audioService } from '../../services/audioService';
import { FOUNDER_NAME, FOUNDER_SOS_HOTLINE } from '../../data/constants';
import { AdminAccessGate } from './AdminAccessGate';
import { CeoPerformanceGrid } from './CeoPerformanceGrid';
import { ExecutiveTeamManager } from './ExecutiveTeamManager';
import { AdminGeofenceRadar } from './AdminGeofenceRadar';
import { AdminOtpManager } from './AdminOtpManager';
import { UrgentDispatchModal } from './UrgentDispatchModal';

export const AdminDashboard: React.FC = () => {
  const [isUnlocked, setIsUnlocked] = useState<boolean>(() => {
    return Boolean(sessionStorage.getItem('nafis_admin_session_token'));
  });

  const [activeTab, setActiveTab] = useState<'overview' | 'captains' | 'settings' | 'alerts' | 'kpis' | 'team' | 'radar' | 'otp'>('overview');
  const [captains, setCaptains] = useState<Captain[]>(rideStore.getCaptains());
  const [activeRide, setActiveRide] = useState<Ride | null>(rideStore.getActiveRide());
  const [history, setHistory] = useState<Ride[]>(rideStore.getRideHistory());
  const [sosAlerts, setSosAlerts] = useState<SosAlert[]>(rideStore.getSosAlerts());
  const [settings, setSettings] = useState<AppSettings>(rideStore.getAppSettings());
  const [showDispatchModal, setShowDispatchModal] = useState<boolean>(false);

  // Settings form local state
  const [baseFare, setBaseFare] = useState(settings.baseFare);
  const [perKmRate, setPerKmRate] = useState(settings.perKmRate);
  const [commissionPercentage, setCommissionPercentage] = useState(settings.commissionPercentage);
  const [surgeMultiplier, setSurgeMultiplier] = useState(settings.surgeMultiplier);
  const [maxRideLimitKm, setMaxRideLimitKm] = useState(settings.maxRideLimitKm);
  const [settingsSaved, setSettingsSaved] = useState(false);

  useEffect(() => {
    const unsub = rideStore.subscribe(() => {
      setCaptains(rideStore.getCaptains());
      setActiveRide(rideStore.getActiveRide());
      setHistory(rideStore.getRideHistory());
      setSosAlerts(rideStore.getSosAlerts());
      setSettings(rideStore.getAppSettings());
    });
    return unsub;
  }, []);

  if (!isUnlocked) {
    return (
      <div className="py-6">
        <AdminAccessGate onUnlock={() => setIsUnlocked(true)} />
      </div>
    );
  }

  const handleLockDashboard = () => {
    sessionStorage.removeItem('nafis_admin_session_token');
    sessionStorage.removeItem('nafis_admin_verified_at');
    setIsUnlocked(false);
  };

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    rideStore.updateSettings({
      baseFare: Number(baseFare),
      perKmRate: Number(perKmRate),
      commissionPercentage: Number(commissionPercentage),
      surgeMultiplier: Number(surgeMultiplier),
      maxRideLimitKm: Number(maxRideLimitKm),
    });
    setSettingsSaved(true);
    audioService.playChime('completed');
    setTimeout(() => setSettingsSaved(false), 2000);
  };

  const handleApproveKyc = (captainId: string) => {
    rideStore.updateCaptainKycStatus(captainId, 'approved');
    audioService.playChime('completed');
  };

  const handleRejectKyc = (captainId: string) => {
    rideStore.updateCaptainKycStatus(captainId, 'rejected');
    audioService.playChime('sos');
  };

  const handleResolveSos = (alertId: string) => {
    rideStore.resolveSosAlert(alertId);
    audioService.playChime('completed');
  };

  // Financial Metrics with 12/88 Split
  const totalRevenue = history.reduce((sum, r) => sum + r.fare, 0) + (activeRide ? activeRide.fare : 0);
  const platformEarnings = Math.round(totalRevenue * ((settings.commissionPercentage || 12) / 100));
  const captainsPayout = totalRevenue - platformEarnings;
  const activeCaptainsCount = captains.filter((c) => c.isOnline).length;
  const pendingAlertsCount = sosAlerts.filter((a) => a.status === 'active').length;

  return (
    <div className="space-y-4 pb-16">
      {/* Top Admin Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 flex items-center justify-between shadow-xl">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-500/50 flex items-center justify-center text-amber-400 font-bold">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-black text-amber-400">
                संस्थापक कमान केंद्र (Founder Command Hub)
              </h2>
              <span className="text-[10px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 px-2 py-0.2 rounded font-mono font-bold">
                SECURE GATE VERIFIED
              </span>
            </div>
            <p className="text-xs text-slate-400">
              संस्थापक एवं मुख्य कार्यकारी अधिकारी: <strong className="text-slate-200">{FOUNDER_NAME}</strong>
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowDispatchModal(true)}
            id="btn-open-urgent-dispatch"
            className="px-3 py-2 bg-gradient-to-r from-amber-500 to-amber-400 text-slate-950 font-black rounded-xl text-xs flex items-center gap-1.5 shadow active:scale-95 transition-all"
          >
            <Zap className="w-3.5 h-3.5" />
            <span>तत्काल प्रेषण</span>
          </button>
          <button
            onClick={handleLockDashboard}
            id="btn-lock-admin"
            className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 active:scale-95 transition-all"
            title="Lock Admin Session"
          >
            <Lock className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Primary KPI Metrics Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center text-xs">
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3">
          <span className="text-[10px] text-slate-400 block font-medium">कुल सवारी राजस्व</span>
          <span className="text-lg font-black text-amber-400 font-mono mt-0.5 block">
            ₹{totalRevenue}
          </span>
          <span className="text-[9px] text-slate-500">{history.length} कुल यात्राएं</span>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3">
          <span className="text-[10px] text-slate-400 block font-medium">मंच कमीशन (12%)</span>
          <span className="text-lg font-black text-emerald-400 font-mono mt-0.5 block">
            ₹{platformEarnings}
          </span>
          <span className="text-[9px] text-slate-500">नेट कंपनी आय</span>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3">
          <span className="text-[10px] text-slate-400 block font-medium">चालक भुगतान (88%)</span>
          <span className="text-lg font-black text-cyan-400 font-mono mt-0.5 block">
            ₹{captainsPayout}
          </span>
          <span className="text-[9px] text-slate-500">सीधे बैंक/UPI</span>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3">
          <span className="text-[10px] text-slate-400 block font-medium">सक्रिय चालक (Online)</span>
          <span className="text-lg font-black text-white font-mono mt-0.5 block">
            {activeCaptainsCount} / {captains.length}
          </span>
          <span className="text-[9px] text-slate-500">अलवर व बेंगलुरु हब</span>
        </div>
      </div>

      {/* SOS Alert Warning Strip if any pending */}
      {pendingAlertsCount > 0 && (
        <div className="p-3.5 bg-red-950/80 border-2 border-red-500 rounded-2xl flex items-center justify-between text-xs text-white animate-pulse">
          <div className="flex items-center gap-2.5">
            <AlertTriangle className="w-5 h-5 text-red-400 flex-shrink-0" />
            <div>
              <span className="font-extrabold text-red-300">
                {pendingAlertsCount} आपातकालीन SOS अलर्ट सक्रिय हैं!
              </span>
              <span className="text-[10px] text-slate-300 block">
                त्वरित सहायता प्रेषित करें या सीधे कॉल करें।
              </span>
            </div>
          </div>
          <button
            onClick={() => setActiveTab('alerts')}
            className="px-3 py-1.5 bg-red-600 hover:bg-red-500 text-white font-black rounded-xl text-xs shadow"
          >
            अलर्ट देखें
          </button>
        </div>
      )}

      {/* Tab Switcher */}
      <div className="flex items-center gap-1 overflow-x-auto pb-1 scrollbar-none bg-slate-900 p-1.5 rounded-2xl border border-slate-800 text-xs">
        {[
          { id: 'overview', label: 'समीक्षा (Overview)' },
          { id: 'captains', label: `चालक (${captains.length})` },
          { id: 'alerts', label: `SOS अलर्ट (${pendingAlertsCount})` },
          { id: 'kpis', label: 'सीईओ KPI स्कोर' },
          { id: 'team', label: 'कार्यकारी दल' },
          { id: 'radar', label: 'जियोफ़ेंस रडार' },
          { id: 'otp', label: 'OTP वॉल्ट' },
          { id: 'settings', label: 'किराया नियंत्रण' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`whitespace-nowrap px-3 py-1.5 rounded-xl font-bold transition-all ${
              activeTab === tab.id
                ? 'bg-amber-500 text-slate-950 shadow-md font-black'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* TAB CONTENT */}
      {activeTab === 'overview' && (
        <div className="space-y-4">
          {/* Active Trip Banner if in progress */}
          {activeRide && (
            <div className="bg-slate-900 border border-amber-500/60 rounded-3xl p-4 text-xs space-y-2.5">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="text-amber-400 font-extrabold flex items-center gap-1.5">
                  <Radio className="w-4 h-4 animate-ping" />
                  <span>सक्रिय सवारी प्रेषण (Active Live Dispatch)</span>
                </span>
                <span className="font-mono text-white bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
                  {activeRide.id}
                </span>
              </div>
              <div className="grid grid-cols-2 gap-2 text-slate-300">
                <div>यात्री: <strong className="text-white">{activeRide.riderName}</strong></div>
                <div>किराया: <strong className="text-emerald-400">₹{activeRide.fare}</strong></div>
                <div>पिकअप: <span className="text-slate-400">{activeRide.pickupLocation.name}</span></div>
                <div>ड्रॉप: <span className="text-slate-400">{activeRide.dropLocation.name}</span></div>
              </div>
            </div>
          )}

          {/* Ceo Scorecard Compact */}
          <CeoPerformanceGrid />
          <AdminGeofenceRadar />
        </div>
      )}

      {activeTab === 'captains' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between text-xs text-slate-400 px-1">
            <span className="font-bold text-slate-300">पंजीकृत चालक रोस्टर:</span>
            <span className="font-mono">{captains.length} Total</span>
          </div>

          {captains.map((captain) => (
            <div
              key={captain.id}
              className="bg-slate-900 border border-slate-800 rounded-3xl p-4 text-xs text-white space-y-3 shadow-lg"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <img
                    src={captain.photoUrl}
                    alt={captain.name}
                    className="w-11 h-11 rounded-2xl object-cover border-2 border-amber-500"
                  />
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm text-white">{captain.name}</span>
                      <span
                        className={`text-[9px] px-1.5 py-0.2 rounded font-bold uppercase ${
                          captain.kycStatus === 'approved'
                            ? 'bg-emerald-500/20 text-emerald-400'
                            : 'bg-amber-500/20 text-amber-400'
                        }`}
                      >
                        {captain.kycStatus}
                      </span>
                    </div>
                    <div className="text-slate-400 text-[11px] font-mono">
                      {captain.vehicleModel} • {captain.vehiclePlate} ({captain.vehicleType})
                    </div>
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-emerald-400 font-mono font-bold text-sm">
                    ₹{captain.todayEarnings}
                  </div>
                  <span className="text-[10px] text-slate-500">आज की कमाई</span>
                </div>
              </div>

              {/* KYC and actions */}
              <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-[11px]">
                <div className="text-slate-400 font-mono">
                  DL: {captain.kycDocs?.drivingLicenseNumber || 'RJ-02-2021'} • UPI: {captain.upiId}
                </div>
                <div className="flex gap-1.5">
                  {captain.kycStatus !== 'approved' && (
                    <button
                      onClick={() => handleApproveKyc(captain.id)}
                      className="px-2.5 py-1 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-lg text-[10px]"
                    >
                      KYC स्वीकृत करें
                    </button>
                  )}
                  {captain.kycStatus === 'approved' && (
                    <button
                      onClick={() => handleRejectKyc(captain.id)}
                      className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-rose-400 rounded-lg text-[10px]"
                    >
                      सस्पेंड
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {activeTab === 'alerts' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between text-xs text-slate-400 px-1">
            <span className="font-bold text-slate-300">आपातकालीन SOS अलर्ट लॉग:</span>
            <span className="font-mono">{sosAlerts.length} Total</span>
          </div>

          {sosAlerts.length === 0 ? (
            <div className="p-8 text-center text-xs text-slate-500 bg-slate-900 rounded-3xl border border-slate-800">
              कोई सक्रिय आपातकालीन अलर्ट नहीं है। समस्त परिचालन सुरक्षित हैं।
            </div>
          ) : (
            sosAlerts.map((alert) => (
              <div
                key={alert.id}
                className={`p-4 rounded-3xl border text-xs space-y-2.5 shadow-lg ${
                  alert.status === 'active'
                    ? 'bg-red-950/60 border-red-500 text-white animate-pulse'
                    : 'bg-slate-900 border-slate-800 text-slate-300'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="font-black text-red-400 text-sm">{alert.id}</span>
                    <span className="text-[10px] uppercase font-bold bg-red-900/80 px-2 py-0.2 rounded text-red-200">
                      {alert.userRole} SOS
                    </span>
                  </div>
                  <span className="text-[10px] font-mono text-slate-400">{alert.timestamp}</span>
                </div>

                <div className="space-y-1">
                  <div>प्रेषक: <strong className="text-white">{alert.userName}</strong> ({alert.userPhone})</div>
                  <div>स्थान: <span className="text-amber-300">{alert.locationAddress}</span></div>
                </div>

                <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between">
                  <a
                    href={`tel:${alert.userPhone || FOUNDER_SOS_HOTLINE}`}
                    className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-amber-400 rounded-xl text-[11px] font-bold flex items-center gap-1"
                  >
                    <Phone className="w-3.5 h-3.5" />
                    <span>कॉल करें</span>
                  </a>
                  {alert.status === 'active' && (
                    <button
                      onClick={() => handleResolveSos(alert.id)}
                      className="px-4 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black rounded-xl text-xs"
                    >
                      समाधान दर्ज करें (Mark Resolved)
                    </button>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {activeTab === 'kpis' && <CeoPerformanceGrid />}
      {activeTab === 'team' && <ExecutiveTeamManager />}
      {activeTab === 'radar' && <AdminGeofenceRadar />}
      {activeTab === 'otp' && <AdminOtpManager />}

      {activeTab === 'settings' && (
        <form
          onSubmit={handleSaveSettings}
          className="bg-slate-900 border border-slate-800 rounded-3xl p-5 text-xs text-white space-y-4 shadow-xl"
        >
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h3 className="text-sm font-extrabold text-amber-400">
                किराया एवं परिचालन नीति नियंत्रण (Tariff Policy Engine)
              </h3>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Rapido-Competitive दरें एवं 12/88 कमीशन विन्यास
              </p>
            </div>
            {settingsSaved && (
              <span className="text-emerald-400 font-bold flex items-center gap-1 text-[11px]">
                <CheckCircle2 className="w-4 h-4" /> सहेजा गया
              </span>
            )}
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 font-bold mb-1">
                मूल किराया (Base Fare ₹):
              </label>
              <input
                type="number"
                value={baseFare}
                onChange={(e) => setBaseFare(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono"
              />
            </div>
            <div>
              <label className="block text-slate-300 font-bold mb-1">
                प्रति किमी दर (Per KM Rate ₹):
              </label>
              <input
                type="number"
                value={perKmRate}
                onChange={(e) => setPerKmRate(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono"
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block text-slate-300 font-bold mb-1">
                मंच कमीशन (%):
              </label>
              <input
                type="number"
                value={commissionPercentage}
                onChange={(e) => setCommissionPercentage(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono"
              />
              <span className="text-[10px] text-emerald-400 mt-0.5 block">
                चालक: {100 - commissionPercentage}%
              </span>
            </div>
            <div>
              <label className="block text-slate-300 font-bold mb-1">
                सर्ज गुणक (Surge Multiplier):
              </label>
              <input
                type="number"
                step="0.1"
                value={surgeMultiplier}
                onChange={(e) => setSurgeMultiplier(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono"
              />
            </div>
            <div>
              <label className="block text-slate-300 font-bold mb-1">
                अधिकतम त्रिज्या (Max KM):
              </label>
              <input
                type="number"
                value={maxRideLimitKm}
                onChange={(e) => setMaxRideLimitKm(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono"
              />
            </div>
          </div>

          <button
            type="submit"
            id="btn-save-admin-settings"
            className="w-full py-3.5 bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 text-slate-950 font-black rounded-xl text-xs shadow-lg active:scale-98 transition-all"
          >
            सेटिंग्स सुरक्षित करें (Save Tariff Policy)
          </button>
        </form>
      )}

      {showDispatchModal && (
        <UrgentDispatchModal
          isOpen={showDispatchModal}
          onClose={() => setShowDispatchModal(false)}
          activeRide={activeRide}
          captains={captains}
        />
      )}
    </div>
  );
};
