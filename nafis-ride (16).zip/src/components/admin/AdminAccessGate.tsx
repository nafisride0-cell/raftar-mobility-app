import React, { useState } from 'react';
import { Lock, AlertCircle, ArrowRight, Loader2, ShieldCheck, KeyRound } from 'lucide-react';
import { FOUNDER_NAME } from '../../data/constants';
import { audioService } from '../../services/audioService';

interface AdminAccessGateProps {
  onUnlock: () => void;
}

export const AdminAccessGate: React.FC<AdminAccessGateProps> = ({ onUnlock }) => {
  const [pin, setPin] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isVerifying, setIsVerifying] = useState<boolean>(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanPin = pin.trim();

    if (!cleanPin) {
      setError('कृपया सुरक्षा पिन दर्ज करें (Please enter security PIN)');
      return;
    }

    setIsVerifying(true);
    setError(null);

    try {
      // Dispatches asynchronous network POST directly to server verification gate
      const response = await fetch('/api/admin/verify-gate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ pin: cleanPin }),
      });

      const data = await response.json().catch(() => ({}));

      if (response.ok && data.success && data.verified) {
        // Store authenticated session token securely in sessionStorage
        if (data.token) {
          sessionStorage.setItem('nafis_admin_session_token', data.token);
          sessionStorage.setItem('nafis_admin_verified_at', data.timestamp || new Date().toISOString());
        }

        audioService.playChime('completed');
        onUnlock();
      } else {
        setError(data.error || 'अमान्य सुरक्षा पिन। प्रवेश अस्वीकृत (Access Denied)');
        audioService.playChime('sos');
        setPin('');
      }
    } catch (err: any) {
      setError(err?.message || 'सर्वर सत्यापन में त्रुटि। नेटवर्क कनेक्शन जांचें।');
      audioService.playChime('sos');
    } finally {
      setIsVerifying(false);
    }
  };

  return (
    <div className="max-w-md mx-auto p-6 bg-slate-900 border border-amber-500/40 rounded-3xl text-white shadow-2xl text-center space-y-4">
      <div className="w-14 h-14 mx-auto rounded-2xl bg-amber-500/20 border border-amber-500/50 flex items-center justify-center text-amber-400">
        <Lock className="w-7 h-7" />
      </div>

      <div>
        <h2 className="text-lg font-black text-amber-400">
          प्रशासनिक नियंत्रण कक्ष (Admin Control Room)
        </h2>
        <p className="text-xs text-slate-400 mt-1">
          संस्थापक एवं मुख्य कार्यकारी नियंत्रण — {FOUNDER_NAME}
        </p>
      </div>

      {error && (
        <div className="p-3 bg-red-950/80 border border-red-500 rounded-xl text-xs text-red-200 flex items-center justify-center gap-1.5">
          <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0" />
          <span>{error}</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-3 pt-2">
        <div>
          <label className="block text-xs font-semibold text-slate-300 mb-1.5">
            सर्वर प्रमाणीकरण पिन (Server Authenticated PIN):
          </label>
          <input
            type="password"
            maxLength={10}
            value={pin}
            onChange={(e) => setPin(e.target.value)}
            disabled={isVerifying}
            placeholder="••••"
            className="w-full bg-slate-950 border border-slate-700 focus:border-amber-400 rounded-2xl px-4 py-3.5 text-center text-white font-mono font-black text-2xl tracking-widest focus:outline-none disabled:opacity-50"
            autoFocus
          />
        </div>

        <button
          type="submit"
          id="btn-admin-submit-pin"
          disabled={isVerifying || !pin.trim()}
          className="w-full py-3.5 bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 text-slate-950 font-black text-sm rounded-2xl shadow-lg flex items-center justify-center gap-2 active:scale-95 transition-all disabled:opacity-50"
        >
          {isVerifying ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              <span>सत्यापित हो रहा है...</span>
            </>
          ) : (
            <>
              <span>डैशबोर्ड अनलॉक करें (Unlock Dashboard)</span>
              <ArrowRight className="w-4 h-4" />
            </>
          )}
        </button>
      </form>

      <div className="pt-3 border-t border-slate-800 text-[11px] text-slate-400 flex items-center justify-center gap-1.5">
        <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
        <span>Cryptographically verified via POST /api/admin/verify-gate</span>
      </div>
    </div>
  );
};
