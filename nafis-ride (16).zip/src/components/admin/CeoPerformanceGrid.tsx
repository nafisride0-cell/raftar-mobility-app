import React, { useState } from 'react';
import {
  TrendingUp,
  Award,
  Users,
  Calendar,
  CheckCircle2,
  Clock,
  Briefcase,
  Layers,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { CeoPerformanceMetric } from '../../types';
import { CEO_PERFORMANCE_SCORECARD, FOUNDER_NAME } from '../../data/constants';

export const CeoPerformanceGrid: React.FC = () => {
  const [metrics, setMetrics] = useState<CeoPerformanceMetric[]>(CEO_PERFORMANCE_SCORECARD);
  const [expandedId, setExpandedId] = useState<string | null>('kpi-3');

  const toggleExpand = (id: string) => {
    setExpandedId(expandedId === id ? null : id);
  };

  const completedCount = metrics.filter((m) => m.status === 'completed').length;
  const inProgressCount = metrics.filter((m) => m.status === 'in_progress').length;
  const avgCompletion = Math.round(
    metrics.reduce((acc, m) => acc + (m.completionPercentage || 0), 0) / metrics.length
  );

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 text-white space-y-4 shadow-xl">
      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
        <div>
          <div className="flex items-center gap-2">
            <Award className="w-5 h-5 text-amber-400" />
            <h3 className="font-extrabold text-amber-400 text-sm">
              सीईओ एवं संस्थापकीय प्रदर्शन ग्रिड (CEO Performance Grid)
            </h3>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            संस्थापक एवं मुख्य कार्यकारी नियंत्रण — {FOUNDER_NAME}
          </p>
        </div>
        <div className="text-right">
          <span className="text-xs font-mono font-black text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 px-2.5 py-1 rounded-xl">
            {avgCompletion}% समग्र प्रगति
          </span>
        </div>
      </div>

      {/* Snapshot metrics */}
      <div className="grid grid-cols-3 gap-2 text-center text-xs">
        <div className="bg-slate-950 p-2.5 rounded-2xl border border-slate-800">
          <span className="text-[10px] text-slate-400 block">सफल लक्ष्य (Completed)</span>
          <span className="text-base font-black text-emerald-400 font-mono mt-0.5 block">
            {completedCount} / {metrics.length}
          </span>
        </div>
        <div className="bg-slate-950 p-2.5 rounded-2xl border border-slate-800">
          <span className="text-[10px] text-slate-400 block">सक्रिय परियोजनाएं (Active)</span>
          <span className="text-base font-black text-amber-400 font-mono mt-0.5 block">
            {inProgressCount}
          </span>
        </div>
        <div className="bg-slate-950 p-2.5 rounded-2xl border border-slate-800">
          <span className="text-[10px] text-slate-400 block">त्रैमासिक चरण (Q2-Q3)</span>
          <span className="text-base font-black text-cyan-400 font-mono mt-0.5 block">
            ON TRACK
          </span>
        </div>
      </div>

      {/* Grid of KPIs */}
      <div className="space-y-2.5">
        {metrics.map((kpi) => {
          const isExpanded = expandedId === kpi.id;
          return (
            <div
              key={kpi.id}
              className="bg-slate-950 border border-slate-800 hover:border-slate-700 rounded-2xl p-3.5 transition-all text-xs"
            >
              <div
                className="flex items-center justify-between cursor-pointer select-none"
                onClick={() => toggleExpand(kpi.id)}
              >
                <div className="space-y-0.5">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-white text-xs">{kpi.title}</span>
                    <span
                      className={`text-[9px] px-1.5 py-0.2 rounded font-bold uppercase ${
                        kpi.status === 'completed'
                          ? 'bg-emerald-500/20 text-emerald-400'
                          : kpi.status === 'in_progress'
                          ? 'bg-amber-500/20 text-amber-400'
                          : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {kpi.status.replace('_', ' ')}
                    </span>
                  </div>
                  <div className="text-[10px] text-slate-400">
                    श्रेणी: <strong className="text-slate-300">{kpi.category}</strong> • लक्षित तिथि: {kpi.targetDate}
                  </div>
                </div>

                <div className="flex items-center gap-2.5">
                  <div className="text-right">
                    <span className="font-mono font-black text-amber-400 text-xs">
                      {kpi.completionPercentage}%
                    </span>
                  </div>
                  {isExpanded ? (
                    <ChevronUp className="w-4 h-4 text-slate-400" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-slate-400" />
                  )}
                </div>
              </div>

              {/* Progress bar */}
              <div className="w-full bg-slate-900 h-1.5 rounded-full overflow-hidden mt-2">
                <div
                  className="bg-gradient-to-r from-amber-500 to-emerald-400 h-full transition-all duration-500"
                  style={{ width: `${kpi.completionPercentage}%` }}
                />
              </div>

              {isExpanded && (
                <div className="mt-3 pt-2.5 border-t border-slate-900 space-y-2 text-slate-300 animate-in fade-in duration-150">
                  <p className="text-[11px] leading-relaxed">{kpi.description}</p>
                  <div className="bg-slate-900 p-2.5 rounded-xl border border-slate-800 font-mono text-[10px] space-y-1">
                    <div>
                      <span className="text-slate-500">Benchmark: </span>
                      <span className="text-emerald-400">{kpi.targetBenchmark || '100% Compliance'}</span>
                    </div>
                    <div>
                      <span className="text-slate-500">Executive Sponsor: </span>
                      <span className="text-amber-300">{FOUNDER_NAME}</span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
