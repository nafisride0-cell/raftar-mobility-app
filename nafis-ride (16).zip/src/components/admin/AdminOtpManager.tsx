import React, { useState, useEffect } from 'react';
import {
  KeyRound,
  CheckCircle2,
  Clock,
  RefreshCw,
  Search,
  ShieldCheck,
  Phone,
  AlertTriangle,
  Send,
  MessageSquare,
  Lock,
} from 'lucide-react';
import { otpService, OtpSession } from '../../services/otpService';
import { audioService } from '../../services/audioService';

interface DisplayOtpSession {
  id: string;
  phoneNumber: string;
  otp: string;
  gatewayStatus: string;
  expiresAt: number;
  attempts: number;
}

export const AdminOtpManager: React.FC = () => {
  const [sessions, setSessions] = useState<DisplayOtpSession[]>([]);
  const [filterPhone, setFilterPhone] = useState<string>('');
  const [quickPhone, setQuickPhone] = useState<string>('');
  const [generatedSession, setGeneratedSession] = useState<DisplayOtpSession | null>(null);

  const reloadSessions = () => {
    setSessions(otpService.getAllActiveSessions());
  };

  useEffect(() => {
    reloadSessions();
    const interval = setInterval(reloadSessions, 4000);
    return () => clearInterval(interval);
  }, []);

  const handleGenerateManualOtp = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanPhone = quickPhone.replace(/\D/g, '').slice(-10);
    if (cleanPhone.length !== 10) return;

    const session = otpService.generateOtp(cleanPhone);
    setGeneratedSession(session);
    setQuickPhone('');
    reloadSessions();
    audioService.playChime('booked');
  };

  const handlePurgeExpired = () => {
    otpService.purgeExpired();
    reloadSessions();
    audioService.playChime('completed');
  };

  const filtered = sessions.filter((s) =>
    filterPhone ? s.phoneNumber.includes(filterPhone) : true
  );

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 text-white space-y-4 shadow-xl">
      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
        <div>
          <div className="flex items-center gap-2">
            <KeyRound className="w-5 h-5 text-amber-400" />
            <h3 className="font-extrabold text-amber-400 text-sm">
              ओटीपी एवं प्रमाणीकरण प्रबंधन (Active OTP Vault & Telephony)
            </h3>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            सक्रिय Fast2SMS DLT तथा इन-मेमरी सत्र नियंत्रक
          </p>
        </div>
        <button
          onClick={handlePurgeExpired}
          className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-xl text-xs flex items-center gap-1.5"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>सत्र साफ़ करें</span>
        </button>
      </div>

      {/* Quick Generate Form */}
      <form
        onSubmit={handleGenerateManualOtp}
        className="bg-slate-950 border border-slate-800 rounded-2xl p-3.5 flex gap-2 text-xs"
      >
        <div className="relative flex-1">
          <input
            type="tel"
            maxLength={10}
            value={quickPhone}
            onChange={(e) => setQuickPhone(e.target.value.replace(/\D/g, ''))}
            placeholder="10-अंकीय मोबाइल नंबर (Quick Generate OTP)"
            className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono text-xs focus:outline-none focus:border-amber-400"
          />
        </div>
        <button
          type="submit"
          disabled={quickPhone.length !== 10}
          className="px-4 py-2 bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 text-slate-950 font-black rounded-xl text-xs flex items-center gap-1.5 disabled:opacity-50"
        >
          <Send className="w-3.5 h-3.5" />
          <span>OTP बनाएं</span>
        </button>
      </form>

      {generatedSession && (
        <div className="p-3 bg-emerald-950/60 border border-emerald-500/60 rounded-2xl flex items-center justify-between text-xs">
          <div>
            <span className="text-slate-300 block">सक्रिय OTP कोड:</span>
            <span className="font-mono text-xl font-black text-amber-400">
              {generatedSession.otp}
            </span>
            <span className="text-[10px] text-slate-400 block font-mono">
              फ़ोन: +91 {generatedSession.phoneNumber}
            </span>
          </div>
          <button
            onClick={() => setGeneratedSession(null)}
            className="text-[10px] text-slate-400 hover:text-white"
          >
            हटाएं
          </button>
        </div>
      )}

      {/* Filter and List */}
      <div className="space-y-2">
        <div className="flex items-center justify-between text-xs text-slate-400">
          <span>सक्रिय सत्र सूची ({filtered.length}):</span>
          <div className="relative w-44">
            <input
              type="text"
              placeholder="फ़ोन खोजें..."
              value={filterPhone}
              onChange={(e) => setFilterPhone(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-1 text-xs text-white"
            />
          </div>
        </div>

        {filtered.length === 0 ? (
          <div className="p-6 bg-slate-950 rounded-2xl border border-slate-800 text-center text-xs text-slate-500">
            कोई सक्रिय OTP सत्र नहीं मिला।
          </div>
        ) : (
          <div className="space-y-2">
            {filtered.map((s) => {
              const timeLeft = Math.max(0, Math.round((s.expiresAt - Date.now()) / 1000));
              const isExpired = timeLeft <= 0;
              return (
                <div
                  key={s.id}
                  className="bg-slate-950 border border-slate-800 p-3 rounded-2xl flex items-center justify-between text-xs font-mono"
                >
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-white text-sm">+91 {s.phoneNumber}</span>
                      <span className="text-[9px] bg-slate-900 border border-slate-700 text-slate-400 px-1.5 py-0.2 rounded font-sans">
                        {s.gatewayStatus}
                      </span>
                    </div>
                    <div className="text-[10px] text-slate-500 font-sans">
                      प्रयास: {s.attempts}/3 • शेष समय: {timeLeft}s
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="text-lg font-black text-amber-400">{s.otp}</div>
                    <span
                      className={`text-[9px] font-sans font-bold ${
                        isExpired ? 'text-rose-400' : 'text-emerald-400'
                      }`}
                    >
                      {isExpired ? 'EXPIRED' : 'ACTIVE'}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
