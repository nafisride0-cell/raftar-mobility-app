import React, { useState } from 'react';
import {
  Users,
  Award,
  Phone,
  Mail,
  ShieldCheck,
  PlusCircle,
  CheckCircle2,
  Trash2,
  ExternalLink,
} from 'lucide-react';
import { ExecutiveMember } from '../../types';
import { EXECUTIVE_TEAM, FOUNDER_NAME } from '../../data/constants';

export const ExecutiveTeamManager: React.FC = () => {
  const [team, setTeam] = useState<ExecutiveMember[]>(EXECUTIVE_TEAM);
  const [showAddForm, setShowAddForm] = useState<boolean>(false);
  const [newName, setNewName] = useState('');
  const [newRole, setNewRole] = useState('');
  const [newHindiRole, setNewHindiRole] = useState('');
  const [newPhone, setNewPhone] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newCity, setNewCity] = useState('Alwar, Rajasthan');

  const handleAddMember = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim() || !newRole.trim()) return;

    const newMember: ExecutiveMember = {
      id: `exec-${Date.now()}`,
      name: newName.trim(),
      role: newRole.trim(),
      hindiRole: newHindiRole.trim() || newRole.trim(),
      phone: newPhone.trim() || '+91 98295 12044',
      email: newEmail.trim() || 'team@nafisride.in',
      location: newCity.trim(),
      joinedDate: '2026-04',
      status: 'active',
      avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120',
      keyResponsibilities: ['Regional Operations Expansion', 'Field Support'],
    };

    setTeam([...team, newMember]);
    setNewName('');
    setNewRole('');
    setNewHindiRole('');
    setNewPhone('');
    setNewEmail('');
    setShowAddForm(false);
  };

  const handleRemoveMember = (id: string) => {
    if (id === 'exec-1') return; // protect Founder
    setTeam(team.filter((m) => m.id !== id));
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 text-white space-y-4 shadow-xl">
      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
        <div>
          <div className="flex items-center gap-2">
            <Users className="w-5 h-5 text-amber-400" />
            <h3 className="font-extrabold text-amber-400 text-sm">
              कार्यकारी एवं संचालन दल (Executive Leadership Board)
            </h3>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            राजस्थान एवं कर्नाटक क्षेत्रीय नेतृत्व रोस्टर
          </p>
        </div>
        <button
          onClick={() => setShowAddForm(!showAddForm)}
          className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-xl text-xs flex items-center gap-1.5 transition active:scale-95"
        >
          <PlusCircle className="w-4 h-4" />
          <span>अधिकारी जोड़ें</span>
        </button>
      </div>

      {showAddForm && (
        <form
          onSubmit={handleAddMember}
          className="bg-slate-950 border border-amber-500/40 rounded-2xl p-4 space-y-3 text-xs animate-in fade-in duration-200"
        >
          <h4 className="font-bold text-amber-400">नया नेतृत्व अधिकारी जोड़ें (Add Executive)</h4>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-[10px] text-slate-400 mb-1">नाम (Full Name):</label>
              <input
                type="text"
                required
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                placeholder="उदा. राहुल शर्मा"
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
              />
            </div>
            <div>
              <label className="block text-[10px] text-slate-400 mb-1">पद (Role / Title):</label>
              <input
                type="text"
                required
                value={newRole}
                onChange={(e) => setNewRole(e.target.value)}
                placeholder="उदा. Chief Technology Officer"
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-[10px] text-slate-400 mb-1">हिंदी पदनाम:</label>
              <input
                type="text"
                value={newHindiRole}
                onChange={(e) => setNewHindiRole(e.target.value)}
                placeholder="उदा. मुख्य तकनीकी अधिकारी"
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
              />
            </div>
            <div>
              <label className="block text-[10px] text-slate-400 mb-1">स्थान (City / Region):</label>
              <input
                type="text"
                value={newCity}
                onChange={(e) => setNewCity(e.target.value)}
                placeholder="उदा. Bengaluru, Karnataka"
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-[10px] text-slate-400 mb-1">फ़ोन (Phone):</label>
              <input
                type="tel"
                value={newPhone}
                onChange={(e) => setNewPhone(e.target.value)}
                placeholder="+91 98295 12044"
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono"
              />
            </div>
            <div>
              <label className="block text-[10px] text-slate-400 mb-1">ईमेल (Email):</label>
              <input
                type="email"
                value={newEmail}
                onChange={(e) => setNewEmail(e.target.value)}
                placeholder="officer@nafisride.in"
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
              />
            </div>
          </div>
          <div className="flex justify-end gap-2 pt-1">
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="px-4 py-2 bg-slate-800 text-slate-300 rounded-xl font-bold"
            >
              रद्द करें
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black rounded-xl shadow"
            >
              दर्ज करें (Save)
            </button>
          </div>
        </form>
      )}

      {/* Roster Grid */}
      <div className="space-y-3">
        {team.map((member) => {
          const isFounder = member.id === 'exec-1';
          return (
            <div
              key={member.id}
              className={`p-4 rounded-2xl border transition-all text-xs space-y-2.5 ${
                isFounder
                  ? 'bg-slate-950/90 border-amber-500/60 shadow-lg shadow-amber-500/10'
                  : 'bg-slate-950 border-slate-800'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <img
                    src={member.avatarUrl}
                    alt={member.name}
                    className={`w-11 h-11 rounded-2xl object-cover border-2 ${
                      isFounder ? 'border-amber-400' : 'border-slate-700'
                    }`}
                  />
                  <div>
                    <div className="flex items-center gap-1.5">
                      <h4 className="font-extrabold text-white text-sm">{member.name}</h4>
                      {isFounder && (
                        <span className="text-[9px] bg-amber-500 text-slate-950 font-black px-1.5 py-0.2 rounded">
                          FOUNDER & CEO
                        </span>
                      )}
                    </div>
                    <div className="text-amber-400 text-[11px] font-medium">
                      {member.hindiRole} • <span className="text-slate-400">{member.role}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-[10px] bg-slate-900 border border-slate-700 text-slate-300 px-2 py-0.5 rounded font-mono">
                    {member.location}
                  </span>
                  {!isFounder && (
                    <button
                      type="button"
                      onClick={() => handleRemoveMember(member.id)}
                      className="p-1.5 text-slate-500 hover:text-rose-400 rounded-lg"
                      title="Remove Member"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>

              {/* Contact and details */}
              <div className="pt-2 border-t border-slate-900 flex items-center justify-between text-[11px] text-slate-400">
                <div className="flex items-center gap-3">
                  <a
                    href={`tel:${member.phone}`}
                    className="flex items-center gap-1 hover:text-amber-300 font-mono"
                  >
                    <Phone className="w-3 h-3 text-amber-400" />
                    <span>{member.phone}</span>
                  </a>
                  <a
                    href={`mailto:${member.email}`}
                    className="flex items-center gap-1 hover:text-amber-300"
                  >
                    <Mail className="w-3 h-3 text-amber-400" />
                    <span>{member.email}</span>
                  </a>
                </div>
                <div className="text-emerald-400 font-mono text-[10px]">
                  Joined: {member.joinedDate}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
