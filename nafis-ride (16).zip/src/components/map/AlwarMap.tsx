import React, { useEffect, useRef } from 'react';
import L from 'leaflet';
import { LocationPoint, Captain, VehicleType, OperationalCity } from '../../types';
import { OPERATIONAL_ZONES, OPERATIONAL_CITIES, ALWAR_CENTER_COORDS } from '../../data/constants';

interface AlwarMapProps {
  pickupLocation: LocationPoint | null;
  dropLocation: LocationPoint | null;
  captains: Captain[];
  activeVehicleType?: VehicleType;
  selectedCity?: OperationalCity;
  onSelectLocation?: (location: LocationPoint, type: 'pickup' | 'drop') => void;
  selectionMode?: 'pickup' | 'drop' | null;
  show30KmRadius?: boolean;
  interactive?: boolean;
}

const INDIA_OPERATIONAL_BOUNDS: L.LatLngBoundsLiteral = [
  [6.5, 67.5],
  [36.5, 97.5],
];

export const AlwarMap: React.FC<AlwarMapProps> = ({
  pickupLocation,
  dropLocation,
  captains,
  selectedCity,
  onSelectLocation,
  selectionMode = null,
  show30KmRadius = true,
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markersLayerRef = useRef<L.LayerGroup | null>(null);
  const routeLayerGroupRef = useRef<L.LayerGroup | null>(null);
  const circleLayerRef = useRef<L.Circle | null>(null);
  const prevCityIdRef = useRef<string | null>(null);

  const currentCity = selectedCity || OPERATIONAL_CITIES[0];
  const activeCenter = currentCity.center;

  useEffect(() => {
    if (!mapContainerRef.current) return;
    if (!mapInstanceRef.current) {
      const map = L.map(mapContainerRef.current, {
        center: [activeCenter.lat, activeCenter.lng],
        zoom: currentCity.zoom || 13,
        minZoom: 5,
        maxZoom: 19,
        maxBounds: INDIA_OPERATIONAL_BOUNDS,
        maxBoundsViscosity: 0.8,
        zoomControl: false,
        attributionControl: false,
      });

      L.control.zoom({ position: 'topright' }).addTo(map);

      L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
        maxZoom: 20,
        subdomains: 'abcd',
        tileSize: 256,
        detectRetina: true,
      }).addTo(map);

      mapInstanceRef.current = map;
      markersLayerRef.current = L.layerGroup().addTo(map);
      routeLayerGroupRef.current = L.layerGroup().addTo(map);
      prevCityIdRef.current = currentCity.id;
    }
  }, []);

  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;
    if (prevCityIdRef.current !== currentCity.id) {
      prevCityIdRef.current = currentCity.id;
      if (!pickupLocation || !dropLocation) {
        map.flyTo([currentCity.center.lat, currentCity.center.lng], currentCity.zoom || 13, {
          duration: 1.2,
        });
      }
    }
  }, [currentCity, pickupLocation, dropLocation]);

  useEffect(() => {
    const map = mapInstanceRef.current;
    const markersLayer = markersLayerRef.current;
    const routeGroup = routeLayerGroupRef.current;
    if (!map || !markersLayer || !routeGroup) return;

    markersLayer.clearLayers();

    if (show30KmRadius) {
      if (circleLayerRef.current) {
        circleLayerRef.current.remove();
      }
      circleLayerRef.current = L.circle([currentCity.center.lat, currentCity.center.lng], {
        radius: (currentCity.radiusKm || 35) * 1000,
        color: '#f59e0b',
        fillColor: '#f59e0b',
        fillOpacity: 0.035,
        weight: 1.5,
        dashArray: '6, 8',
      }).addTo(map);
    }

    OPERATIONAL_ZONES.forEach((zone) => {
      const isCurrentCity = zone.cityId === currentCity.id || (!zone.cityId && currentCity.id === 'alwar');
      const isPickup = pickupLocation?.id === zone.id;
      const isDrop = dropLocation?.id === zone.id;

      if (!isCurrentCity && !isPickup && !isDrop) return;

      const isSpecialPoint = zone.id === 'kati_ghati' || zone.id === 'jodhpur_mehrangarh' || zone.id === 'blr_majestic' || zone.id === 'mys_palace';
      const iconHtml = `
        <div class="relative flex items-center justify-center cursor-pointer group">
          <div class="w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold shadow-lg transition-transform ${
            isPickup
              ? 'bg-emerald-500 text-slate-950 ring-4 ring-emerald-400/50 scale-125 z-30 font-black'
              : isDrop
              ? 'bg-red-500 text-white ring-4 ring-red-400/50 scale-125 z-30 font-black'
              : isSpecialPoint
              ? 'bg-amber-600 text-white ring-2 ring-amber-400 scale-110 z-20'
              : 'bg-slate-900/90 text-amber-400 border border-amber-500/70 hover:scale-110'
          }">
            ${isPickup ? 'P' : isDrop ? 'D' : isSpecialPoint ? '★' : '•'}
          </div>
          <div class="absolute -bottom-5 whitespace-nowrap bg-slate-950/90 text-slate-200 text-[10px] font-semibold px-1.5 py-0.5 rounded border border-slate-700 pointer-events-none shadow">
            ${(zone.kannadaName && currentCity.state === 'Karnataka') ? zone.kannadaName : zone.name.split(' (')[0]}
          </div>
        </div>
      `;

      const customIcon = L.divIcon({
        className: 'custom-pin-marker',
        html: iconHtml,
        iconSize: [28, 28],
        iconAnchor: [14, 14],
      });

      const marker = L.marker([zone.lat, zone.lng], { icon: customIcon });
      marker.on('click', () => {
        if (onSelectLocation && selectionMode) {
          onSelectLocation(zone, selectionMode);
        } else if (onSelectLocation) {
          onSelectLocation(zone, pickupLocation ? 'drop' : 'pickup');
        }
      });
      marker.addTo(markersLayer);
    });

    captains.forEach((cpt) => {
      if (!cpt.isOnline) return;
      const isCaptainInCity = cpt.cityId === currentCity.id || (!cpt.cityId && currentCity.id === 'alwar');
      if (!isCaptainInCity) return;

      const vehicleEmoji = cpt.vehicleType === 'bike' ? '🛵' : cpt.vehicleType === 'auto' ? '🛺' : '🔋';
      const vehicleColor = cpt.vehicleType === 'bike' ? 'bg-amber-500' : cpt.vehicleType === 'auto' ? 'bg-emerald-500' : 'bg-cyan-500';

      const captainHtml = `
        <div class="relative flex items-center justify-center cursor-pointer">
          <div class="w-8 h-8 rounded-full ${vehicleColor} text-slate-950 flex items-center justify-center text-sm font-bold shadow-xl border-2 border-slate-900 transform hover:scale-125 transition-transform">
            ${vehicleEmoji}
          </div>
          <div class="absolute -top-4 bg-slate-950/95 text-[9px] text-amber-300 font-mono font-bold px-1 rounded shadow border border-slate-800">
            ${cpt.name.split(' ')[0]}
          </div>
        </div>
      `;

      const cptIcon = L.divIcon({
        className: 'captain-marker',
        html: captainHtml,
        iconSize: [32, 32],
        iconAnchor: [16, 16],
      });

      L.marker([cpt.lat, cpt.lng], { icon: cptIcon })
        .bindPopup(`
          <div style="font-family: sans-serif; font-size: 12px; color: #0f172a; padding: 4px;">
            <b>${cpt.name}</b> (${cpt.vehicleModel})<br/>
            ⭐ ${cpt.rating} • ${cpt.totalTrips} rides<br/>
            Plate: <code>${cpt.vehiclePlate}</code>
          </div>
        `)
        .addTo(markersLayer);
    });

    routeGroup.clearLayers();
    if (pickupLocation && dropLocation) {
      const midLat = (pickupLocation.lat + dropLocation.lat) / 2;
      const midLng = (pickupLocation.lng + dropLocation.lng) / 2;
      const dLat = dropLocation.lat - pickupLocation.lat;
      const dLng = dropLocation.lng - pickupLocation.lng;

      const wp1: [number, number] = [
        pickupLocation.lat + dLat * 0.3 + 0.002,
        pickupLocation.lng + dLng * 0.3 - 0.0015,
      ];
      const wp2: [number, number] = [
        midLat + (dLng > 0 ? 0.003 : -0.003),
        midLng + (dLat > 0 ? -0.002 : 0.002),
      ];
      const wp3: [number, number] = [
        pickupLocation.lat + dLat * 0.7 - 0.0015,
        pickupLocation.lng + dLng * 0.7 + 0.002,
      ];

      const latlngs: [number, number][] = [
        [pickupLocation.lat, pickupLocation.lng],
        wp1,
        wp2,
        wp3,
        [dropLocation.lat, dropLocation.lng],
      ];

      L.polyline(latlngs, {
        color: '#f59e0b',
        weight: 8,
        opacity: 0.35,
        lineCap: 'round',
        lineJoin: 'round',
      }).addTo(routeGroup);

      L.polyline(latlngs, {
        color: '#d97706',
        weight: 4,
        opacity: 0.95,
        dashArray: '8, 6',
        lineCap: 'round',
        lineJoin: 'round',
      }).addTo(routeGroup);

      const bounds = L.latLngBounds(latlngs);
      map.flyToBounds(bounds, {
        padding: [50, 50],
        maxZoom: 15,
        duration: 0.75,
      });
    }
  }, [pickupLocation, dropLocation, captains, selectionMode, show30KmRadius, onSelectLocation, currentCity]);

  return (
    <div className="relative w-full h-full min-h-[300px] overflow-hidden rounded-2xl border border-slate-700/80 shadow-inner">
      <div ref={mapContainerRef} className="w-full h-full z-0" />
      <div className="absolute top-3 left-3 z-10 flex flex-col gap-1.5 pointer-events-none">
        <div className="bg-slate-900/95 border border-amber-500/50 backdrop-blur-md px-2.5 py-1 rounded-lg text-[11px] text-amber-300 font-bold shadow flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
          <span>{currentCity.state}: {currentCity.hindiName || currentCity.name}</span>
        </div>
        {show30KmRadius && (
          <div className="bg-slate-900/80 border border-slate-700 backdrop-blur-md px-2 py-0.5 rounded text-[10px] text-slate-300 font-medium">
            {currentCity.radiusKm} KM Operational Zone Active
          </div>
        )}
      </div>

      {selectionMode && (
        <div className="absolute bottom-3 left-1/2 -translate-x-1/2 z-10 bg-amber-500 text-slate-950 font-black text-xs px-3 py-1.5 rounded-full shadow-lg pointer-events-none animate-bounce">
          Tap any landmark to set {selectionMode.toUpperCase()} location
        </div>
      )}
    </div>
  );
};
