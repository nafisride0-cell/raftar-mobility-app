/**
 * Native Background Geolocation Service for Nafis Ride
 * Powered by @capacitor-community/background-geolocation and @capacitor/geolocation
 * Continuously tracks driver & passenger coordinates even when minimized.
 */
import { registerPlugin } from '@capacitor/core';
import { Geolocation } from '@capacitor/geolocation';

export interface BackgroundGeolocationPlugin {
  addWatcher(
    options: {
      backgroundMessage?: string;
      backgroundTitle?: string;
      requestPermissions?: boolean;
      stale?: boolean;
      distanceFilter?: number;
    },
    callback: (
      location?: {
        latitude: number;
        longitude: number;
        accuracy: number;
        altitude: number | null;
        simulated: boolean;
        speed: number | null;
        bearing: number | null;
        time: number | null;
      },
      error?: { code: string; message: string }
    ) => void
  ): Promise<string>;
  removeWatcher(options: { id: string }): Promise<void>;
  openSettings(): Promise<void>;
}

const BackgroundGeolocation = registerPlugin<BackgroundGeolocationPlugin>('BackgroundGeolocation');

export interface LocationCoordinates {
  latitude: number;
  longitude: number;
  accuracy: number;
  speed: number | null;
  timestamp: number;
  isBackground: boolean;
}

type LocationListener = (coords: LocationCoordinates) => void;

class NativeGeolocationService {
  private watcherId: string | null = null;
  private webWatchId: number | null = null;
  private listeners: Set<LocationListener> = new Set();
  private lastKnownLocation: LocationCoordinates = {
    latitude: 27.553,
    longitude: 76.6346,
    accuracy: 5,
    speed: 0,
    timestamp: Date.now(),
    isBackground: false,
  };
  private isTracking = false;

  public subscribe(listener: LocationListener): () => void {
    this.listeners.add(listener);
    listener(this.lastKnownLocation);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notify(coords: LocationCoordinates) {
    this.lastKnownLocation = coords;
    this.listeners.forEach((listener) => {
      try {
        listener(coords);
      } catch (err) {
        console.error('[Native Geolocation Service] Listener error:', err);
      }
    });
  }

  public async startBackgroundTracking(): Promise<boolean> {
    if (this.isTracking) return true;
    try {
      const perm = await Geolocation.requestPermissions();
      if (perm.location !== 'granted' && perm.location !== 'prompt') {
        console.warn('[Native Geolocation] Permission not granted:', perm);
      }
      this.watcherId = await BackgroundGeolocation.addWatcher(
        {
          backgroundTitle: 'Nafis Ride Live Dispatch Radar',
          backgroundMessage: 'अलवर एवं राजस्थान/कर्नाटक क्षेत्र में चालक एवं सवारी का रियल-टाइम जीपीएस ट्रैकिंग सक्रिय है।',
          requestPermissions: true,
          stale: false,
          distanceFilter: 5,
        },
        (location, error) => {
          if (error) {
            console.warn('[Background Geolocation Error]:', error.message);
            return;
          }
          if (location) {
            this.notify({
              latitude: location.latitude,
              longitude: location.longitude,
              accuracy: location.accuracy,
              speed: location.speed,
              timestamp: location.time || Date.now(),
              isBackground: true,
            });
          }
        }
      );
      this.isTracking = true;
      return true;
    } catch (nativeErr) {
      console.warn('[Native Geolocation] Background plugin fallback to web watch:', nativeErr);
      return this.startFallbackTracking();
    }
  }

  private startFallbackTracking(): boolean {
    if ('geolocation' in navigator) {
      this.webWatchId = navigator.geolocation.watchPosition(
        (pos) => {
          this.notify({
            latitude: pos.coords.latitude,
            longitude: pos.coords.longitude,
            accuracy: pos.coords.accuracy,
            speed: pos.coords.speed,
            timestamp: pos.timestamp,
            isBackground: false,
          });
        },
        (err) => {
          console.warn('[Web Geolocation Watch Error]:', err.message);
        },
        { enableHighAccuracy: true, maximumAge: 3000, timeout: 10000 }
      );
      this.isTracking = true;
      return true;
    }
    return false;
  }

  public async stopTracking(): Promise<void> {
    if (this.watcherId) {
      try {
        await BackgroundGeolocation.removeWatcher({ id: this.watcherId });
      } catch (err) {
        console.warn('[Native Geolocation] Error stopping background watcher:', err);
      }
      this.watcherId = null;
    }
    if (this.webWatchId !== null && 'geolocation' in navigator) {
      navigator.geolocation.clearWatch(this.webWatchId);
      this.webWatchId = null;
    }
    this.isTracking = false;
  }

  public async stopBackgroundTracking(): Promise<void> {
    return this.stopTracking();
  }

  public async initializeBackgroundTracking(
    onLocation?: (location: { lat: number; lng: number }) => void
  ): Promise<boolean> {
    if (onLocation) {
      this.subscribe((coords) => {
        onLocation({ lat: coords.latitude, lng: coords.longitude });
      });
    }
    return this.startBackgroundTracking();
  }

  public getLastKnownLocation(): LocationCoordinates {
    return this.lastKnownLocation;
  }

  public startTracking(callback?: (coords: LocationCoordinates) => void): () => void {
    if (callback) {
      this.subscribe(callback);
    }
    this.startBackgroundTracking();
    return () => {
      this.stopTracking();
    };
  }

  public isTrackingActive(): boolean {
    return this.isTracking;
  }
}

export const nativeGeolocationService = new NativeGeolocationService();
export const nativeGeolocation = nativeGeolocationService;
