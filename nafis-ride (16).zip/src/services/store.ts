import { io, Socket } from 'socket.io-client';
import {
  Ride,
  Captain,
  UserProfile,
  SosAlert,
  FareSettings,
  AppSettings,
  LocationPoint,
  VehicleType,
  PaymentDetails,
  OperationalCity,
} from '../types';
import {
  INITIAL_CAPTAINS,
  DEFAULT_FARE_SETTINGS,
  OPERATIONAL_ZONES,
  OPERATIONAL_CITIES,
} from '../data/constants';
import { pushNotificationService } from './pushNotificationService';
import { nativeGeolocationService } from './nativeGeolocationService';

/**
 * Haversine formula to compute great-circle distance between two GPS coordinates in Kilometers
 */
export function calculateDistanceKm(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  if (
    typeof lat1 !== 'number' ||
    typeof lon1 !== 'number' ||
    typeof lat2 !== 'number' ||
    typeof lon2 !== 'number'
  ) {
    return 0;
  }
  const R = 6371; // Earth's mean radius in km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const d = R * c;
  return Math.round(d * 10) / 10;
}

/**
 * Computes transparent road fare based on distance and vehicle category
 */
export function calculateFare(
  distanceKm: number,
  vehicleType: VehicleType,
  settings: FareSettings = DEFAULT_FARE_SETTINGS
): number {
  const rates = settings[vehicleType] || DEFAULT_FARE_SETTINGS[vehicleType];
  const safeDistance = Math.max(0, isNaN(distanceKm) ? 0 : distanceKm);
  const calculated = rates.baseFare + safeDistance * rates.perKm;
  return Math.max(rates.minFare, Math.round(calculated));
}

/**
 * Estimates journey duration in minutes with traffic buffer
 */
export function estimateDurationMinutes(
  distanceKm: number,
  vehicleType: VehicleType
): number {
  const speeds: Record<VehicleType, number> = {
    bike: 38,
    auto: 28,
    eriksha: 20,
  };
  const safeDistance = Math.max(0, isNaN(distanceKm) ? 0 : distanceKm);
  const hours = safeDistance / (speeds[vehicleType] || 25);
  const minutes = Math.round(hours * 60) + 3;
  return Math.max(4, minutes);
}

// Local cache keys for failover persistence
const CACHE_KEYS = {
  CAPTAINS: 'raftar_ride_cache_captains_v6',
  ACTIVE_RIDE: 'raftar_ride_cache_active_v6',
  RIDE_HISTORY: 'raftar_ride_cache_history_v6',
  USER_PROFILE: 'raftar_ride_cache_user_v6',
  CAPTAIN_PROFILE: 'raftar_ride_cache_captain_v6',
  SOS_ALERTS: 'raftar_ride_cache_sos_v6',
  SETTINGS: 'raftar_ride_cache_settings_v6',
  SELECTED_CITY: 'raftar_ride_cache_city_v6',
};

type Listener = () => void;

class RaftarRideStore {
  // In-memory state synchronized with backend ledger
  private captains: Captain[] = INITIAL_CAPTAINS;
  private activeRide: Ride | null = null;
  private rideHistory: Ride[] = [];
  private userProfile: UserProfile | null = null;
  private captainProfile: Captain | null = null;
  private sosAlerts: SosAlert[] = [];
  private settings: FareSettings = { ...DEFAULT_FARE_SETTINGS, commissionPercentage: 12 };
  private selectedCityId: string = 'delhi';
  private listeners: Set<Listener> = new Set();
  public isOnline: boolean = typeof navigator !== 'undefined' ? navigator.onLine : true;
  private pendingSyncQueue: Array<() => Promise<void>> = [];

  // Live WebSocket Connection
  private socket: Socket | null = null;
  private socketConnected: boolean = false;

  constructor() {
    this.hydrateFromLocalFailover();
    this.initSocketConnection();
    this.initNetworkLedgerSync();
  }

  /**
   * Initializes real-time bidirectional WebSocket connection to the server
   */
  private initSocketConnection() {
    if (typeof window === 'undefined') return;

    try {
      this.socket = io({
        transports: ['websocket', 'polling'],
        reconnection: true,
        reconnectionAttempts: 20,
        reconnectionDelay: 1000,
      });

      this.socket.on('connect', () => {
        this.socketConnected = true;

        // Register active city room
        this.socket?.emit('passenger:join_city', {
          cityId: this.selectedCityId,
          riderId: this.userProfile?.id,
        });

        // Register captain if currently in captain mode
        if (this.captainProfile) {
          this.socket?.emit('captain:register', {
            captainId: this.captainProfile.id,
            cityId: this.selectedCityId,
          });
        }
      });

      this.socket.on('disconnect', () => {
        this.socketConnected = false;
      });

      // Handle live captain movement from WebSocket broadcast
      this.socket.on(
        'fleet:captain_moved',
        (payload: {
          captainId: string;
          lat: number;
          lng: number;
          cityId?: string;
          vehicleType?: VehicleType;
          speed?: number;
          heading?: number;
        }) => {
          const { captainId, lat, lng, cityId } = payload;
          let changed = false;

          this.captains = this.captains.map((c) => {
            if (c.id === captainId) {
              changed = true;
              return {
                ...c,
                lat,
                lng,
                isOnline: true,
                ...(cityId ? { cityId } : {}),
              };
            }
            return c;
          });

          // If assigned captain is on active ride, update coordinates in active ride
          if (
            this.activeRide &&
            this.activeRide.captainId === captainId &&
            this.activeRide.status !== 'completed' &&
            this.activeRide.status !== 'cancelled'
          ) {
            // Live position updated smoothly
            changed = true;
          }

          if (changed) {
            this.notify();
          }
        }
      );

      // Handle full city snapshot from server upon connection
      this.socket.on('fleet:initial_snapshot', (payload: { cityId: string; captains: Captain[] }) => {
        if (Array.isArray(payload.captains) && payload.captains.length > 0) {
          const incomingIds = new Set(payload.captains.map((c) => c.id));
          const untouched = this.captains.filter((c) => !incomingIds.has(c.id));
          this.captains = [...untouched, ...payload.captains];
          this.notify();
        }
      });

      // Handle captain status toggle (online / offline)
      this.socket.on(
        'fleet:captain_status_changed',
        (payload: { captainId: string; isOnline: boolean; kycStatus?: string }) => {
          this.captains = this.captains.map((c) =>
            c.id === payload.captainId
              ? {
                  ...c,
                  isOnline: payload.isOnline,
                  ...(payload.kycStatus ? { kycStatus: payload.kycStatus as any } : {}),
                }
              : c
          );
          this.notify();
        }
      );

      // Handle ride assignment
      this.socket.on('ride:status_update', (payload: { rideId: string; status: string; ride?: Ride }) => {
        if (payload.ride && this.activeRide && this.activeRide.id === payload.rideId) {
          this.activeRide = payload.ride;
          this.persistLocalCache(CACHE_KEYS.ACTIVE_RIDE, this.activeRide);
          this.notify();
        }
      });

      // Handle payment verified webhook broadcast
      this.socket.on('payment:verified', (payload: any) => {
        if (this.activeRide && (this.activeRide.id === payload.rideId || !payload.rideId)) {
          this.activeRide.paymentStatus = 'paid';
          this.persistLocalCache(CACHE_KEYS.ACTIVE_RIDE, this.activeRide);
          this.notify();
        }
      });

      // Handle SOS broadcast
      this.socket.on('sos:emergency_broadcast', (alert: SosAlert) => {
        if (alert && !this.sosAlerts.some((a) => a.id === alert.id)) {
          this.sosAlerts.unshift(alert);
          this.persistLocalCache(CACHE_KEYS.SOS_ALERTS, this.sosAlerts);
          this.notify();
        }
      });
    } catch (err) {
      console.warn('[RaftarRideStore] WebSocket initialization notice:', err);
    }
  }

  /**
   * Failover Memory Layer: Restores state instantly from local storage primitives
   */
  private hydrateFromLocalFailover() {
    try {
      const savedCity = localStorage.getItem(CACHE_KEYS.SELECTED_CITY);
      if (savedCity && OPERATIONAL_CITIES.some((c) => c.id === savedCity)) {
        this.selectedCityId = savedCity;
      }

      const cachedCaptains = localStorage.getItem(CACHE_KEYS.CAPTAINS);
      if (cachedCaptains) {
        this.captains = JSON.parse(cachedCaptains);
      } else {
        this.captains = INITIAL_CAPTAINS;
      }

      const cachedSettings = localStorage.getItem(CACHE_KEYS.SETTINGS);
      if (cachedSettings) {
        this.settings = { ...DEFAULT_FARE_SETTINGS, ...JSON.parse(cachedSettings), commissionPercentage: 12 };
      }

      const cachedActiveRide = localStorage.getItem(CACHE_KEYS.ACTIVE_RIDE);
      if (cachedActiveRide) {
        this.activeRide = JSON.parse(cachedActiveRide);
      }

      const cachedHistory = localStorage.getItem(CACHE_KEYS.RIDE_HISTORY);
      if (cachedHistory) {
        this.rideHistory = JSON.parse(cachedHistory);
      }

      const cachedUser = localStorage.getItem(CACHE_KEYS.USER_PROFILE);
      if (cachedUser) {
        try {
          const parsed = JSON.parse(cachedUser);
          if (parsed && parsed.token && parsed.isVerified) {
            this.userProfile = parsed;
          } else {
            this.userProfile = null;
          }
        } catch {
          this.userProfile = null;
        }
      } else {
        this.userProfile = null;
      }

      const cachedCaptain = localStorage.getItem(CACHE_KEYS.CAPTAIN_PROFILE);
      if (cachedCaptain) {
        try {
          this.captainProfile = JSON.parse(cachedCaptain);
        } catch {
          this.captainProfile = null;
        }
      } else {
        this.captainProfile = null;
      }

      const cachedSos = localStorage.getItem(CACHE_KEYS.SOS_ALERTS);
      if (cachedSos) {
        this.sosAlerts = JSON.parse(cachedSos);
      }
    } catch (e) {
      console.warn('[RaftarRideStore] Failover hydration warning:', e);
    }
  }

  /**
   * Bootstraps asynchronous server ledger synchronization and carrier connectivity listeners.
   */
  private initNetworkLedgerSync() {
    if (typeof window !== 'undefined') {
      window.addEventListener('online', () => {
        this.isOnline = true;
        this.flushPendingSyncQueue();
        this.hydrateFromBackendServer();
      });
      window.addEventListener('offline', () => {
        this.isOnline = false;
      });
    }

    // Initial hydration from Express backend ledger
    this.hydrateFromBackendServer();

    // Register native geolocation coordinates streaming
    nativeGeolocationService.subscribe((coords) => {
      if (this.captainProfile && this.captainProfile.isOnline) {
        this.updateCaptainCurrentLocation(coords.latitude, coords.longitude);
      }
    });
  }

  private async flushPendingSyncQueue() {
    while (this.pendingSyncQueue.length > 0) {
      const task = this.pendingSyncQueue.shift();
      if (task) {
        try {
          await task();
        } catch {
          this.pendingSyncQueue.unshift(task);
          break;
        }
      }
    }
  }

  public async hydrateFromBackendServer(): Promise<void> {
    try {
      const [fleetRes, rideRes, historyRes, sosRes, settingsRes] = await Promise.allSettled([
        fetch('/api/fleet/captains').then((r) => r.json()),
        fetch('/api/rides/active').then((r) => r.json()),
        fetch('/api/rides/history').then((r) => r.json()),
        fetch('/api/sos/alerts').then((r) => r.json()),
        fetch('/api/settings/fares').then((r) => r.json()),
      ]);

      if (fleetRes.status === 'fulfilled' && fleetRes.value?.success && Array.isArray(fleetRes.value.captains)) {
        this.captains = fleetRes.value.captains;
        if (this.captainProfile) {
          const updatedCap = this.captains.find((c) => c.id === this.captainProfile?.id);
          if (updatedCap) this.captainProfile = updatedCap;
        }
        this.persistLocalCache(CACHE_KEYS.CAPTAINS, this.captains);
      }

      if (rideRes.status === 'fulfilled' && rideRes.value?.success) {
        this.activeRide = rideRes.value.activeRide ?? null;
        this.persistLocalCache(CACHE_KEYS.ACTIVE_RIDE, this.activeRide);
      }

      if (historyRes.status === 'fulfilled' && historyRes.value?.success && Array.isArray(historyRes.value.history)) {
        this.rideHistory = historyRes.value.history;
        this.persistLocalCache(CACHE_KEYS.RIDE_HISTORY, this.rideHistory);
      }

      if (sosRes.status === 'fulfilled' && sosRes.value?.success && Array.isArray(sosRes.value.alerts)) {
        this.sosAlerts = sosRes.value.alerts;
        this.persistLocalCache(CACHE_KEYS.SOS_ALERTS, this.sosAlerts);
      }

      if (settingsRes.status === 'fulfilled' && settingsRes.value?.success && settingsRes.value.settings) {
        this.settings = { ...this.settings, ...settingsRes.value.settings, commissionPercentage: 12 };
        this.persistLocalCache(CACHE_KEYS.SETTINGS, this.settings);
      }

      this.notify();
    } catch (err) {
      console.info('[RaftarRideStore] Operating on failover memory layer:', err);
    }
  }

  private persistLocalCache(key: string, data: any) {
    try {
      if (data === null || data === undefined) {
        localStorage.removeItem(key);
      } else {
        localStorage.setItem(key, JSON.stringify(data));
      }
    } catch {}
  }

  // Pub/Sub pattern for reactive React bindings
  public subscribe(listener: Listener): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private notify() {
    this.listeners.forEach((listener) => {
      try {
        listener();
      } catch (err) {
        console.error('[RaftarRideStore] Listener dispatch error:', err);
      }
    });
  }

  // State Getters
  public getCaptains(): Captain[] {
    return this.captains;
  }

  public getActiveRide(): Ride | null {
    return this.activeRide;
  }

  public getRideHistory(): Ride[] {
    return this.rideHistory;
  }

  public getUserProfile(): UserProfile | null {
    return this.userProfile;
  }

  public getCaptainProfile(): Captain | null {
    return this.captainProfile;
  }

  public getSosAlerts(): SosAlert[] {
    return this.sosAlerts;
  }

  public getSettings(): FareSettings {
    return this.settings;
  }

  public getSelectedCity(): OperationalCity {
    return (
      OPERATIONAL_CITIES.find((c) => c.id === this.selectedCityId) ||
      OPERATIONAL_CITIES.find((c) => c.id === 'delhi') ||
      OPERATIONAL_CITIES[0]
    );
  }

  public setSelectedCity(cityId: string) {
    const city = OPERATIONAL_CITIES.find((c) => c.id === cityId);
    if (city) {
      this.selectedCityId = city.id;
      this.persistLocalCache(CACHE_KEYS.SELECTED_CITY, city.id);

      // Join socket city room for live broadcast
      if (this.socket && this.socketConnected) {
        this.socket.emit('passenger:join_city', {
          cityId: city.id,
          riderId: this.userProfile?.id,
        });
      }

      this.notify();
    }
  }

  public getOperationalCities(): OperationalCity[] {
    return OPERATIONAL_CITIES;
  }

  public getZonesByCity(cityId?: string): LocationPoint[] {
    const targetCity = cityId || this.selectedCityId;
    return OPERATIONAL_ZONES.filter(
      (z) => z.cityId === targetCity || (!z.cityId && targetCity === 'delhi')
    );
  }

  public getAllOperationalZones(): LocationPoint[] {
    return OPERATIONAL_ZONES;
  }

  /**
   * Broadcasts operator coordinates in real-time over WebSocket and persists via REST
   */
  public async updateCaptainCurrentLocation(lat: number, lng: number, cityId?: string) {
    const captainId = this.captainProfile?.id || 'cpt_delhi_01';
    const effectiveCity = cityId || this.selectedCityId;

    // 1. Instant local memory update for smooth UI
    this.captains = this.captains.map((c) =>
      c.id === captainId ? { ...c, lat, lng, cityId: effectiveCity } : c
    );
    if (this.captainProfile && this.captainProfile.id === captainId) {
      this.captainProfile.lat = lat;
      this.captainProfile.lng = lng;
      this.captainProfile.cityId = effectiveCity;
      this.persistLocalCache(CACHE_KEYS.CAPTAIN_PROFILE, this.captainProfile);
    }
    this.persistLocalCache(CACHE_KEYS.CAPTAINS, this.captains);
    this.notify();

    // 2. Real-time WebSocket emission to all active passengers
    if (this.socket && this.socketConnected) {
      this.socket.emit('captain:share_location_live', {
        captainId,
        lat,
        lng,
        cityId: effectiveCity,
        vehicleType: this.captainProfile?.vehicleType || 'bike',
      });
    }

    // 3. Background REST persistence
    const syncLocation = async () => {
      await fetch('/api/fleet/captain-location', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ captainId, lat, lng, cityId: effectiveCity }),
      });
    };

    try {
      await syncLocation();
    } catch {
      this.pendingSyncQueue.push(syncLocation);
    }
  }

  /**
   * Geofence boundary verification across Delhi NCR, Haryana, Rajasthan & Karnataka.
   * Smoothly validates inter-state routes across Delhi NCR and Haryana without causing
   * unexpected bounds calculations or white-screen UI deadlocks.
   */
  public validateRideBooking(
    pickup: LocationPoint,
    drop: LocationPoint
  ): { valid: boolean; distanceKm: number; message?: string } {
    if (!pickup || !drop || typeof pickup.lat !== 'number' || typeof drop.lat !== 'number') {
      return {
        valid: false,
        distanceKm: 0,
        message: 'कृपया वैध पिकअप और ड्रॉप स्थान चुनें।',
      };
    }

    const distance = calculateDistanceKm(pickup.lat, pickup.lng, drop.lat, drop.lng);
    const maxLimit = Math.max(this.settings.maxRideLimitKm || 75, 75);

    if (isNaN(distance) || distance < 0) {
      return {
        valid: false,
        distanceKm: 0,
        message: 'अमान्य दूरी गणना। कृपया पुनः स्थान चुनें।',
      };
    }

    if (distance > maxLimit) {
      return {
        valid: false,
        distanceKm: distance,
        message: `सवारी दूरी (${distance} KM) अधिकतम अनुमत सीमा (${maxLimit} KM) से अधिक है।`,
      };
    }

    // Inter-state NCR cluster detection (Delhi, Gurugram, Faridabad, Manesar, Haryana Sub-Hubs)
    const ncrCityIds = ['delhi', 'gurugram', 'haryana_subhubs'];
    const isPickupNcr =
      ncrCityIds.includes(pickup.cityId || '') ||
      pickup.state === 'Delhi' ||
      pickup.state === 'Haryana' ||
      OPERATIONAL_CITIES.filter((c) => ncrCityIds.includes(c.id)).some(
        (c) => calculateDistanceKm(pickup.lat, pickup.lng, c.center.lat, c.center.lng) <= c.radiusKm + 25
      );

    const isDropNcr =
      ncrCityIds.includes(drop.cityId || '') ||
      drop.state === 'Delhi' ||
      drop.state === 'Haryana' ||
      OPERATIONAL_CITIES.filter((c) => ncrCityIds.includes(c.id)).some(
        (c) => calculateDistanceKm(drop.lat, drop.lng, c.center.lat, c.center.lng) <= c.radiusKm + 25
      );

    // Contiguous Delhi-Gurugram-Haryana corridor gets seamless inter-state approval
    if (isPickupNcr && isDropNcr) {
      return { valid: true, distanceKm: distance };
    }

    // Standard city radius validation for Rajasthan (Alwar, Jodhpur) and Karnataka (Bengaluru, Mysuru)
    const isPickupInCity = OPERATIONAL_CITIES.some(
      (c) => calculateDistanceKm(pickup.lat, pickup.lng, c.center.lat, c.center.lng) <= c.radiusKm + 20
    );
    const isDropInCity = OPERATIONAL_CITIES.some(
      (c) => calculateDistanceKm(drop.lat, drop.lng, c.center.lat, c.center.lng) <= c.radiusKm + 20
    );
    const isKnownPickup = OPERATIONAL_ZONES.some((z) => z.id === pickup.id) || isPickupInCity;
    const isKnownDrop = OPERATIONAL_ZONES.some((z) => z.id === drop.id) || isDropInCity;

    if (!isKnownPickup || !isKnownDrop) {
      return {
        valid: false,
        distanceKm: distance,
        message: 'पिकअप अथवा ड्रॉप स्थान हमारे सक्रिय संचालन क्षेत्र (Delhi NCR, Haryana, Rajasthan, Karnataka) से बाहर है।',
      };
    }

    return { valid: true, distanceKm: distance };
  }

  /**
   * Creates a new ride request and registers it via WebSockets & REST ledger
   */
  public createRideRequest(
    pickup: LocationPoint,
    drop: LocationPoint,
    vehicleType: VehicleType
  ): { success: boolean; ride?: Ride; error?: string } {
    const validation = this.validateRideBooking(pickup, drop);
    if (!validation.valid) {
      return { success: false, error: validation.message };
    }

    const distanceKm = validation.distanceKm;
    const fare = calculateFare(distanceKm, vehicleType, this.settings);
    const estimatedMinutes = estimateDurationMinutes(distanceKm, vehicleType);
    const otp = Math.floor(1000 + Math.random() * 9000).toString();

    const newRide: Ride = {
      id: 'RF-' + Math.floor(100000 + Math.random() * 900000),
      riderId: this.userProfile?.id || 'usr_guest',
      riderName: this.userProfile?.name || 'सवारी (Passenger)',
      riderPhone: this.userProfile?.phone || '+91 98110 00000',
      vehicleType,
      pickupLocation: pickup,
      dropLocation: drop,
      distanceKm,
      fare,
      estimatedMinutes,
      otp,
      status: 'searching',
      paymentMethod: 'upi_qr',
      paymentStatus: 'pending',
      createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    this.activeRide = newRide;
    this.persistLocalCache(CACHE_KEYS.ACTIVE_RIDE, this.activeRide);
    this.notify();

    // 1. Emit live dispatch request over WebSockets to all nearby captains
    if (this.socket && this.socketConnected) {
      this.socket.emit('ride:request_dispatch', newRide);
    }

    // 2. Dispatch native push notifications to approved Captains within 75 KM
    pushNotificationService.notifyCaptainNewRide({
      title: 'रफ़्तार: नयी सवारी उपलब्ध!',
      body: `पिकअप: ${pickup.name.split(' (')[0]} -> ड्रॉप: ${drop.name.split(' (')[0]} | किराया: ₹${fare}`,
      rideId: newRide.id,
      fare,
      pickup: pickup.name,
      drop: drop.name,
      distanceKm,
    });

    // Dispatch to backend REST API
    fetch('/api/rides/sync', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ride: newRide, action: 'create' }),
    }).catch(() => {});

    return { success: true, ride: newRide };
  }

  private autoAssignCaptain(rideId: string) {
    if (!this.activeRide || this.activeRide.id !== rideId || this.activeRide.status !== 'searching') {
      return;
    }

    const pickupCity = this.activeRide.pickupLocation.cityId || this.selectedCityId;
    const eligibleCaptains = this.captains.filter(
      (c) => c.isOnline && c.kycStatus === 'approved' && (!c.currentRideId || c.currentRideId === rideId)
    );
    const cityEligible = eligibleCaptains.filter(
      (c) => c.cityId === pickupCity || (!c.cityId && pickupCity === 'delhi')
    );
    const candidatePool = cityEligible.length > 0 ? cityEligible : eligibleCaptains;
    const assigned =
      candidatePool.find((c) => c.vehicleType === this.activeRide?.vehicleType) ||
      candidatePool[0] ||
      eligibleCaptains[0] ||
      this.captains[0];

    if (assigned) {
      this.activeRide = {
        ...this.activeRide,
        captainId: assigned.id,
        captainName: assigned.name,
        captainPhone: assigned.phone,
        captainPhoto: assigned.photoUrl,
        vehiclePlate: assigned.vehiclePlate,
        vehicleModel: assigned.vehicleModel,
        status: 'captain_assigned',
      };
      this.persistLocalCache(CACHE_KEYS.ACTIVE_RIDE, this.activeRide);
      this.notify();

      if (this.socket && this.socketConnected) {
        this.socket.emit('ride:captain_accept', { rideId, captainId: assigned.id });
      }

      fetch('/api/rides/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ride: this.activeRide, action: 'update' }),
      }).catch(() => {});

      setTimeout(() => {
        if (this.activeRide && this.activeRide.id === rideId && this.activeRide.status === 'captain_assigned') {
          this.activeRide.status = 'arrived';
          this.activeRide.arrivedAt = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
          this.persistLocalCache(CACHE_KEYS.ACTIVE_RIDE, this.activeRide);
          this.notify();

          if (this.socket && this.socketConnected) {
            this.socket.emit('ride:status_change', { rideId, status: 'arrived' });
          }

          fetch('/api/rides/sync', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ ride: this.activeRide, action: 'update' }),
          }).catch(() => {});
        }
      }, 5000);
    }
  }

  public manualOverrideDispatch(
    captainId: string,
    rideId?: string
  ): { success: boolean; ride?: Ride; error?: string } {
    const captain = this.captains.find((c) => c.id === captainId);
    if (!captain) {
      return { success: false, error: 'चालक नहीं मिला (Captain not found)' };
    }

    if (this.activeRide && (!rideId || this.activeRide.id === rideId)) {
      this.activeRide = {
        ...this.activeRide,
        captainId: captain.id,
        captainName: captain.name,
        captainPhone: captain.phone,
        captainPhoto: captain.photoUrl,
        vehiclePlate: captain.vehiclePlate,
        vehicleModel: captain.vehicleModel,
        vehicleType: captain.vehicleType,
        status: 'captain_assigned',
      };
      this.captains = this.captains.map((c) =>
        c.id === captain.id ? { ...c, isOnline: true, currentRideId: this.activeRide!.id } : c
      );
      this.persistLocalCache(CACHE_KEYS.CAPTAINS, this.captains);
      this.persistLocalCache(CACHE_KEYS.ACTIVE_RIDE, this.activeRide);
      this.notify();

      if (this.socket && this.socketConnected) {
        this.socket.emit('ride:captain_accept', { rideId: this.activeRide.id, captainId: captain.id });
      }

      return { success: true, ride: this.activeRide };
    }

    const currentCityZones = this.getZonesByCity();
    const pickupLoc = currentCityZones[0] || OPERATIONAL_ZONES[0];
    const dropLoc = currentCityZones[1] || OPERATIONAL_ZONES[1];
    const distanceKm = 4.8;
    const fare = calculateFare(distanceKm, captain.vehicleType, this.settings);
    const estimatedMinutes = estimateDurationMinutes(distanceKm, captain.vehicleType);
    const otp = Math.floor(1000 + Math.random() * 9000).toString();

    const emergencyRide: Ride = {
      id: 'RF-DISPATCH-' + Math.floor(100000 + Math.random() * 900000),
      riderId: 'usr_dispatch_ncr',
      riderName: 'सवारी (Urgent Dispatch)',
      riderPhone: '+91 98110 89190',
      vehicleType: captain.vehicleType,
      captainId: captain.id,
      captainName: captain.name,
      captainPhone: captain.phone,
      captainPhoto: captain.photoUrl,
      vehiclePlate: captain.vehiclePlate,
      vehicleModel: captain.vehicleModel,
      pickupLocation: pickupLoc,
      dropLocation: dropLoc,
      distanceKm,
      fare,
      estimatedMinutes,
      otp,
      status: 'captain_assigned',
      paymentMethod: 'cash',
      paymentStatus: 'pending',
      createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    this.activeRide = emergencyRide;
    this.captains = this.captains.map((c) =>
      c.id === captain.id ? { ...c, isOnline: true, currentRideId: emergencyRide.id } : c
    );
    this.persistLocalCache(CACHE_KEYS.CAPTAINS, this.captains);
    this.persistLocalCache(CACHE_KEYS.ACTIVE_RIDE, this.activeRide);
    this.notify();

    if (this.socket && this.socketConnected) {
      this.socket.emit('ride:captain_accept', { rideId: emergencyRide.id, captainId: captain.id });
    }

    return { success: true, ride: emergencyRide };
  }

  public createStrandedRideSimulation(
    pickupZoneId = 'delhi_cp',
    dropZoneId = 'ggn_cybercity',
    vehicleType: VehicleType = 'bike'
  ): Ride {
    const pickup = OPERATIONAL_ZONES.find((p) => p.id === pickupZoneId) || OPERATIONAL_ZONES[0];
    const drop = OPERATIONAL_ZONES.find((p) => p.id === dropZoneId) || OPERATIONAL_ZONES[4];
    const distanceKm = 24.5;
    const fare = calculateFare(distanceKm, vehicleType, this.settings);
    const estimatedMinutes = 35;
    const otp = Math.floor(1000 + Math.random() * 9000).toString();

    const strandedRide: Ride = {
      id: 'RF-STRANDED-' + Math.floor(100000 + Math.random() * 900000),
      riderId: 'usr_stranded_' + Date.now().toString().slice(-4),
      riderName: 'नागरिक (Citizen)',
      riderPhone: '+91 98110 ' + Math.floor(10000 + Math.random() * 90000),
      vehicleType,
      pickupLocation: pickup,
      dropLocation: drop,
      distanceKm,
      fare,
      estimatedMinutes,
      otp,
      status: 'searching',
      paymentMethod: 'cash',
      paymentStatus: 'pending',
      createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    this.activeRide = strandedRide;
    this.persistLocalCache(CACHE_KEYS.ACTIVE_RIDE, this.activeRide);
    this.notify();

    if (this.socket && this.socketConnected) {
      this.socket.emit('ride:request_dispatch', strandedRide);
    }

    return strandedRide;
  }

  public startTrip(inputOtp: string): { success: boolean; error?: string } {
    if (!this.activeRide) {
      return { success: false, error: 'कोई सक्रिय सवारी नहीं मिली' };
    }
    if (this.activeRide.otp !== inputOtp) {
      return { success: false, error: 'गलत OTP! कृपया सही OTP दर्ज करें' };
    }

    this.activeRide = {
      ...this.activeRide,
      status: 'in_trip',
      startedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };
    this.persistLocalCache(CACHE_KEYS.ACTIVE_RIDE, this.activeRide);
    this.notify();

    if (this.socket && this.socketConnected) {
      this.socket.emit('ride:status_change', { rideId: this.activeRide.id, status: 'in_trip' });
    }

    fetch('/api/rides/sync', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ride: this.activeRide, action: 'update' }),
    }).catch(() => {});

    return { success: true };
  }

  public completeTrip(): { success: boolean } {
    if (!this.activeRide) return { success: false };

    const completedRide: Ride = {
      ...this.activeRide,
      status: 'completed',
      paymentStatus: this.activeRide.paymentStatus || 'pending',
      completedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    // Financial settlement: 12% platform fee, 88% captain payout
    if (completedRide.paymentStatus === 'paid' && completedRide.captainId) {
      const commissionRate = (this.settings.commissionPercentage || 12) / 100;
      const captainCut = Math.round(completedRide.fare * (1 - commissionRate));

      this.captains = this.captains.map((c) => {
        if (c.id === completedRide.captainId) {
          return {
            ...c,
            todayEarnings: c.todayEarnings + captainCut,
            walletBalance: c.walletBalance + captainCut,
            totalTrips: c.totalTrips + 1,
            currentRideId: null,
          };
        }
        return c;
      });
      this.persistLocalCache(CACHE_KEYS.CAPTAINS, this.captains);

      if (this.captainProfile && this.captainProfile.id === completedRide.captainId) {
        this.captainProfile = this.captains.find((c) => c.id === completedRide.captainId) || this.captainProfile;
        this.persistLocalCache(CACHE_KEYS.CAPTAIN_PROFILE, this.captainProfile);
      }
    }

    this.rideHistory.unshift(completedRide);
    this.persistLocalCache(CACHE_KEYS.RIDE_HISTORY, this.rideHistory);

    this.activeRide = completedRide;
    this.persistLocalCache(CACHE_KEYS.ACTIVE_RIDE, this.activeRide);
    this.notify();

    if (this.socket && this.socketConnected) {
      this.socket.emit('ride:status_change', { rideId: completedRide.id, status: 'completed' });
    }

    fetch('/api/rides/sync', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ride: completedRide, action: 'update' }),
    }).catch(() => {});

    return { success: true };
  }

  public cancelRide(): { success: boolean } {
    if (!this.activeRide) return { success: false };
    const cancelledRide = { ...this.activeRide, status: 'cancelled' as const };
    this.rideHistory.unshift(cancelledRide);
    this.persistLocalCache(CACHE_KEYS.RIDE_HISTORY, this.rideHistory);

    const rideId = this.activeRide.id;
    this.activeRide = null;
    this.persistLocalCache(CACHE_KEYS.ACTIVE_RIDE, null);
    this.notify();

    if (this.socket && this.socketConnected) {
      this.socket.emit('ride:status_change', { rideId, status: 'cancelled' });
    }

    fetch('/api/rides/sync', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ride: null, action: 'clear' }),
    }).catch(() => {});

    return { success: true };
  }

  public dismissCompletedRide(): void {
    this.activeRide = null;
    this.persistLocalCache(CACHE_KEYS.ACTIVE_RIDE, null);
    this.notify();

    fetch('/api/rides/sync', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ride: null, action: 'clear' }),
    }).catch(() => {});
  }

  /**
   * Cashless settlement matrix: strictly enforces 12% platform fee and 88% captain payout settlement ledger
   */
  public payCashlessRide(
    rideId: string,
    method: 'upi_intent' | 'upi_qr' | 'cashless_wallet' | 'cash',
    details?: { appName?: string; payerName?: string; customUtr?: string }
  ): { success: boolean; error?: string; paymentDetails?: PaymentDetails } {
    let targetRide = this.activeRide?.id === rideId ? this.activeRide : this.rideHistory.find((r) => r.id === rideId);
    if (!targetRide && this.activeRide) {
      targetRide = this.activeRide;
    }
    if (!targetRide) {
      return { success: false, error: 'सवारी विवरण नहीं मिला (Ride not found)' };
    }

    const fare = targetRide.fare;

    // Deduct from wallet if cashless_wallet selected
    if (method === 'cashless_wallet') {
      const currentBalance = this.userProfile?.walletBalance ?? 750;
      if (currentBalance < fare) {
        return {
          success: false,
          error: `अपर्याप्त वॉलेट बैलेंस (₹${currentBalance})! कृपया वॉलेट रीचार्ज करें अथवा सीधे UPI द्वारा भुगतान करें।`,
        };
      }
      if (this.userProfile) {
        this.userProfile.walletBalance = Math.max(0, currentBalance - fare);
        this.persistLocalCache(CACHE_KEYS.USER_PROFILE, this.userProfile);
      }
    }

    const utrNumber =
      details?.customUtr ||
      `UPI/${Math.floor(100000000000 + Math.random() * 900000000000)}/RF`;

    // Strictly enforce 12% platform commission and 88% captain payout settlement ledger
    const commissionRate = (this.settings.commissionPercentage || 12) / 100;
    const captainCredit = Math.round(fare * (1 - commissionRate)); // 88%
    const platformCommission = Math.round(fare * commissionRate); // 12%

    const paymentDetails: PaymentDetails = {
      method,
      utrNumber,
      paidAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      amount: fare,
      captainCredit,
      platformCommission,
      appName:
        details?.appName ||
        (method === 'cashless_wallet'
          ? 'रफ़्तार वॉलेट (Raftar Wallet)'
          : method === 'upi_qr'
          ? 'क्यूआर कोड UPI'
          : 'UPI ऐप भुगतान'),
      payerName: details?.payerName || this.userProfile?.name || 'सत्यापित सवारी (Verified Rider)',
      receiptId: `RF-REC-${Date.now().toString().slice(-6)}`,
      webhookVerified: true,
      transactionId: `TXN-${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`,
    };

    targetRide.paymentStatus = 'paid';
    targetRide.paymentMethod = method;
    targetRide.paymentDetails = paymentDetails;

    // Credit Captain settlement ledger (88%)
    if (targetRide.captainId) {
      this.captains = this.captains.map((c) => {
        if (c.id === targetRide.captainId) {
          return {
            ...c,
            walletBalance: c.walletBalance + captainCredit,
            todayEarnings: c.todayEarnings + captainCredit,
            totalTrips: c.totalTrips + 1,
            currentRideId: null,
          };
        }
        return c;
      });
      this.persistLocalCache(CACHE_KEYS.CAPTAINS, this.captains);

      if (this.captainProfile && this.captainProfile.id === targetRide.captainId) {
        this.captainProfile = this.captains.find((c) => c.id === targetRide.captainId) || this.captainProfile;
        this.persistLocalCache(CACHE_KEYS.CAPTAIN_PROFILE, this.captainProfile);
      }
    }

    if (this.activeRide?.id === targetRide.id) {
      this.activeRide = { ...targetRide };
      this.persistLocalCache(CACHE_KEYS.ACTIVE_RIDE, this.activeRide);
    }

    this.rideHistory = this.rideHistory.map((r) => (r.id === targetRide.id ? { ...targetRide } : r));
    this.persistLocalCache(CACHE_KEYS.RIDE_HISTORY, this.rideHistory);
    this.notify();

    // Asynchronously dispatch payment verification webhook to server
    const syncPaymentWebhook = async () => {
      await fetch('/api/payments/verify-webhook', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          transactionId: paymentDetails.transactionId,
          rideId: targetRide.id,
          captainId: targetRide.captainId,
          amount: fare,
          captainCredit,
          platformCommission,
          utrNumber,
          status: 'SUCCESS',
        }),
      });
    };

    syncPaymentWebhook().catch(() => {
      this.pendingSyncQueue.push(syncPaymentWebhook);
    });

    return { success: true, paymentDetails };
  }

  public topUpUserWallet(amount: number): number {
    if (!this.userProfile) {
      this.userProfile = {
        id: 'usr_verified_' + Date.now().toString().slice(-6),
        name: 'रफ़्तार राइडर (Verified Rider)',
        phone: '+91 98110 55219',
        email: 'rider.delhi@raftarmobility.in',
        role: 'rider',
        token: 'jwt_raftar_session_' + Date.now(),
        walletBalance: 750,
        isVerified: true,
      };
    }
    const current = this.userProfile.walletBalance || 0;
    this.userProfile.walletBalance = current + amount;
    this.persistLocalCache(CACHE_KEYS.USER_PROFILE, this.userProfile);
    this.notify();
    return this.userProfile.walletBalance;
  }

  public toggleCaptainDuty(captainId?: string): boolean {
    const targetId = captainId || this.captainProfile?.id;
    if (!targetId) return false;

    let newState = false;
    this.captains = this.captains.map((c) => {
      if (c.id === targetId) {
        newState = !c.isOnline;
        return { ...c, isOnline: newState };
      }
      return c;
    });
    this.persistLocalCache(CACHE_KEYS.CAPTAINS, this.captains);

    if (this.captainProfile && this.captainProfile.id === targetId) {
      this.captainProfile.isOnline = newState;
      this.persistLocalCache(CACHE_KEYS.CAPTAIN_PROFILE, this.captainProfile);
    }

    if (newState) {
      nativeGeolocationService.startBackgroundTracking().catch(() => {});
    }

    if (this.socket && this.socketConnected) {
      this.socket.emit('fleet:captain_status_changed', { captainId: targetId, isOnline: newState });
    }

    const syncStatus = async () => {
      await fetch('/api/fleet/captain-status', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ captainId: targetId, isOnline: newState }),
      });
    };
    syncStatus().catch(() => {
      this.pendingSyncQueue.push(syncStatus);
    });

    this.notify();
    return newState;
  }

  /**
   * Safety Beacons: Dispatches emergency distress signal asynchronously to `/api/sos/alert` & WebSockets
   */
  public triggerSosEmergency(
    role: 'passenger' | 'captain',
    senderName: string,
    senderPhone: string,
    currentLocationText?: string,
    customCoords?: { lat: number; lng: number }
  ): SosAlert {
    const lat = customCoords?.lat || this.activeRide?.pickupLocation.lat || 28.6139;
    const lng = customCoords?.lng || this.activeRide?.pickupLocation.lng || 77.2090;
    const locationLink = `https://maps.google.com/?q=${lat},${lng}`;

    const alert: SosAlert = {
      id: 'SOS-' + Date.now().toString().slice(-6),
      rideId: this.activeRide?.id,
      senderName,
      senderPhone,
      role,
      coordinates: {
        lat,
        lng,
        address:
          currentLocationText ||
          this.activeRide?.pickupLocation.name ||
          'Delhi NCR / Haryana Live Operational Zone',
      },
      locationLink,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      status: 'active',
      notes: 'EMERGENCY DISTRESS BEACON: Live coordinates transmitted to Founder Nafis Khan dispatch control & local police helpline 112.',
    };

    this.sosAlerts.unshift(alert);
    this.persistLocalCache(CACHE_KEYS.SOS_ALERTS, this.sosAlerts);
    this.notify();

    if (this.socket && this.socketConnected) {
      this.socket.emit('sos:dispatch_beacon', alert);
    }

    const syncAlert = async () => {
      await fetch('/api/sos/alert', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(alert),
      });
    };
    syncAlert().catch(() => {
      this.pendingSyncQueue.push(syncAlert);
    });

    return alert;
  }

  public updateSosAlertSmsReceipt(
    alertId: string,
    smsInfo: {
      messageId: string;
      recipient: string;
      status: string;
      deliveredAt: string;
      alertType: string;
      locationLink: string;
    }
  ): void {
    this.sosAlerts = this.sosAlerts.map((a) => {
      if (a.id === alertId) {
        return {
          ...a,
          locationLink: smsInfo.locationLink,
          smsReceipt: {
            messageId: smsInfo.messageId,
            recipient: smsInfo.recipient,
            status: smsInfo.status,
            deliveredAt: smsInfo.deliveredAt,
            alertType: smsInfo.alertType,
          },
        };
      }
      return a;
    });
    this.persistLocalCache(CACHE_KEYS.SOS_ALERTS, this.sosAlerts);
    this.notify();
  }

  public resolveSosAlert(alertId: string, notes?: string): void {
    this.sosAlerts = this.sosAlerts.map((a) => {
      if (a.id === alertId) {
        return {
          ...a,
          status: 'resolved',
          resolvedBy: 'Founder Nafis Khan (Raftar Control Center)',
          resolvedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          notes: notes || 'Assistance dispatched and passenger/captain safety confirmed.',
        };
      }
      return a;
    });
    this.persistLocalCache(CACHE_KEYS.SOS_ALERTS, this.sosAlerts);
    this.notify();

    fetch('/api/sos/resolve', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ alertId, notes }),
    }).catch(() => {});
  }

  public approveCaptainKyc(captainId: string): void {
    const today = new Date().toISOString().split('T')[0];
    const expiry = new Date(Date.now() + 3 * 365 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];

    this.captains = this.captains.map((c) => {
      if (c.id === captainId) {
        return {
          ...c,
          kycStatus: 'approved',
          idCardIssuedDate: today,
          idCardExpiryDate: expiry,
        };
      }
      return c;
    });
    this.persistLocalCache(CACHE_KEYS.CAPTAINS, this.captains);

    if (this.captainProfile?.id === captainId) {
      this.captainProfile.kycStatus = 'approved';
      this.captainProfile.idCardIssuedDate = today;
      this.captainProfile.idCardExpiryDate = expiry;
      this.persistLocalCache(CACHE_KEYS.CAPTAIN_PROFILE, this.captainProfile);
    }

    fetch('/api/fleet/captain-status', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ captainId, kycStatus: 'approved' }),
    }).catch(() => {});

    this.notify();
  }

  public rejectCaptainKyc(captainId: string, reason?: string): void {
    this.captains = this.captains.map((c) => {
      if (c.id === captainId) {
        return {
          ...c,
          kycStatus: 'rejected',
          isOnline: false,
          kycDocs: c.kycDocs
            ? { ...c.kycDocs, verificationNotes: reason || 'दस्तावेज़ स्पष्ट नहीं हैं।' }
            : undefined,
        };
      }
      return c;
    });
    this.persistLocalCache(CACHE_KEYS.CAPTAINS, this.captains);

    if (this.captainProfile?.id === captainId) {
      this.captainProfile.kycStatus = 'rejected';
      this.captainProfile.isOnline = false;
      this.persistLocalCache(CACHE_KEYS.CAPTAIN_PROFILE, this.captainProfile);
    }

    fetch('/api/fleet/captain-status', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ captainId, kycStatus: 'rejected', isOnline: false }),
    }).catch(() => {});

    this.notify();
  }

  public submitCaptainKyc(
    captainData: Partial<Captain>,
    kycData: {
      aadhaarNumber: string;
      aadhaarPhotoUrl?: string;
      aadhaarBackPhotoUrl?: string;
      drivingLicenseNumber: string;
      dlPhotoUrl?: string;
      dlExpiryDate?: string;
      dlClass?: string;
      rcNumber?: string;
      rcPhotoUrl?: string;
      insuranceNumber?: string;
      insurancePhotoUrl?: string;
      pucCertificateNumber?: string;
      vehiclePlate: string;
      vehicleType: VehicleType;
      vehicleModel: string;
      bloodGroup?: string;
      emergencyContact?: string;
    }
  ): Captain {
    const id = this.captainProfile?.id || 'cpt_' + Date.now().toString().slice(-4);
    const updatedCaptain: Captain = {
      id,
      name: captainData.name || this.captainProfile?.name || 'New Raftar Captain',
      phone: captainData.phone || this.captainProfile?.phone || '+91 98110 00000',
      email: captainData.email || this.captainProfile?.email || 'captain@raftarmobility.in',
      vehicleType: kycData.vehicleType,
      vehicleModel: kycData.vehicleModel || 'Hero Splendor Plus (BS6)',
      vehiclePlate: kycData.vehiclePlate || 'DL-01-RF-2026',
      photoUrl:
        captainData.photoUrl ||
        this.captainProfile?.photoUrl ||
        'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=300&auto=format&fit=crop&q=80',
      rating: this.captainProfile?.rating || 5.0,
      totalTrips: this.captainProfile?.totalTrips || 0,
      isOnline: false,
      kycStatus: 'pending',
      bloodGroup: kycData.bloodGroup || this.captainProfile?.bloodGroup || 'B+',
      emergencyContact: kycData.emergencyContact || this.captainProfile?.emergencyContact || '+91 70236 08919',
      kycDocs: {
        aadhaarNumber: kycData.aadhaarNumber,
        aadhaarPhotoUrl:
          kycData.aadhaarPhotoUrl ||
          'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600&auto=format&fit=crop&q=80',
        aadhaarBackPhotoUrl:
          kycData.aadhaarBackPhotoUrl ||
          'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=600&auto=format&fit=crop&q=80',
        drivingLicenseNumber: kycData.drivingLicenseNumber,
        dlPhotoUrl:
          kycData.dlPhotoUrl ||
          'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=600&auto=format&fit=crop&q=80',
        dlExpiryDate: kycData.dlExpiryDate || '2031-09-20',
        dlClass: kycData.dlClass || (kycData.vehicleType === 'bike' ? 'MCWG / LMV' : '3W-CAB / LMV-TR'),
        rcNumber: kycData.rcNumber || kycData.vehiclePlate.replace(/[^A-Z0-9]/gi, ''),
        rcPhotoUrl:
          kycData.rcPhotoUrl ||
          'https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?w=600&auto=format&fit=crop&q=80',
        insuranceNumber: kycData.insuranceNumber || 'NIC-DEL-2026-9812',
        insurancePhotoUrl:
          kycData.insurancePhotoUrl ||
          'https://images.unsplash.com/photo-1450133064473-71024230f91b?w=600&auto=format&fit=crop&q=80',
        pucCertificateNumber: kycData.pucCertificateNumber || 'PUC-DEL-2026-OK',
        profilePhotoUrl:
          captainData.photoUrl ||
          this.captainProfile?.photoUrl ||
          'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=300&auto=format&fit=crop&q=80',
        vehicleRegistration: 'RC-' + kycData.vehiclePlate,
        submittedAt: new Date().toISOString().split('T')[0],
      },
      walletBalance: this.captainProfile?.walletBalance || 0,
      todayEarnings: this.captainProfile?.todayEarnings || 0,
      upiId:
        this.captainProfile?.upiId ||
        (captainData.name?.toLowerCase().replace(/\s+/g, '') || 'captain') + '@upi',
      lat: this.captainProfile?.lat || 28.6139,
      lng: this.captainProfile?.lng || 77.2090,
      cityId: captainData.cityId || this.selectedCityId,
      joinedDate: this.captainProfile?.joinedDate || 'Sep 2026',
    };

    const existingIdx = this.captains.findIndex((c) => c.id === id);
    if (existingIdx >= 0) {
      this.captains[existingIdx] = updatedCaptain;
    } else {
      this.captains.push(updatedCaptain);
    }
    this.captainProfile = updatedCaptain;
    this.persistLocalCache(CACHE_KEYS.CAPTAINS, this.captains);
    this.persistLocalCache(CACHE_KEYS.CAPTAIN_PROFILE, this.captainProfile);

    fetch('/api/fleet/captain-documents', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        captainId: id,
        kycDocs: updatedCaptain.kycDocs,
        vehiclePlate: updatedCaptain.vehiclePlate,
        vehicleModel: updatedCaptain.vehicleModel,
        vehicleType: updatedCaptain.vehicleType,
        cityId: updatedCaptain.cityId,
      }),
    }).catch(() => {});

    this.notify();
    return updatedCaptain;
  }

  public setUserProfile(user: UserProfile) {
    this.userProfile = user;
    this.persistLocalCache(CACHE_KEYS.USER_PROFILE, this.userProfile);
    this.notify();
  }

  public setCaptainProfile(captain: Captain) {
    this.captainProfile = captain;
    this.persistLocalCache(CACHE_KEYS.CAPTAIN_PROFILE, this.captainProfile);
    this.notify();
  }

  public updateCaptainKycStatus(captainId: string, status: 'approved' | 'rejected' | 'pending', reason?: string): void {
    if (status === 'approved') {
      this.approveCaptainKyc(captainId);
    } else if (status === 'rejected') {
      this.rejectCaptainKyc(captainId, reason);
    } else {
      this.captains = this.captains.map((c) => (c.id === captainId ? { ...c, kycStatus: 'pending' } : c));
      this.persistLocalCache(CACHE_KEYS.CAPTAINS, this.captains);
      this.notify();
    }
  }

  public updateFareSettings(newSettings: FareSettings): void {
    this.saveSettings(newSettings);
  }

  public saveSettings(newSettings: FareSettings) {
    this.settings = { ...newSettings, commissionPercentage: 12 };
    this.persistLocalCache(CACHE_KEYS.SETTINGS, this.settings);
    this.notify();

    fetch('/api/settings/fares', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(this.settings),
    }).catch(() => {});
  }

  public updateCaptainGps(captainId: string, lat: number, lng: number): void {
    this.updateCaptainCurrentLocation(lat, lng);
  }

  public getAppSettings(): AppSettings {
    return {
      baseFare: this.settings.bike?.baseFare || 20,
      perKmRate: this.settings.bike?.perKm || 8,
      commissionPercentage: this.settings.commissionPercentage || 12,
      surgeMultiplier: 1.0,
      maxRideLimitKm: this.settings.maxRideLimitKm || 75,
    };
  }

  public updateSettings(newSettings: Partial<AppSettings>): void {
    if (newSettings.baseFare !== undefined && this.settings.bike) {
      this.settings.bike.baseFare = newSettings.baseFare;
    }
    if (newSettings.perKmRate !== undefined && this.settings.bike) {
      this.settings.bike.perKm = newSettings.perKmRate;
    }
    if (newSettings.commissionPercentage !== undefined) {
      this.settings.commissionPercentage = newSettings.commissionPercentage;
    }
    if (newSettings.maxRideLimitKm !== undefined) {
      this.settings.maxRideLimitKm = newSettings.maxRideLimitKm;
    }
    this.saveSettings(this.settings);
  }

  public updateUserProfile(profile: Partial<UserProfile>): void {
    if (!this.userProfile) {
      this.userProfile = {
        id: 'usr_' + Date.now().toString().slice(-6),
        name: profile.name || 'रफ़्तार राइडर (Raftar Rider)',
        phone: profile.phone || '+91 98110 55219',
        email: profile.email || 'rider@raftarmobility.in',
        role: profile.role || 'rider',
        token: 'jwt_' + Date.now(),
        isVerified: profile.isVerified ?? true,
        walletBalance: 500,
      };
    } else {
      this.userProfile = { ...this.userProfile, ...profile };
    }
    this.persistLocalCache(CACHE_KEYS.USER_PROFILE, this.userProfile);
    this.notify();
  }

  public updateCaptainProfile(profile: Partial<Captain>): void {
    if (this.captainProfile) {
      this.captainProfile = { ...this.captainProfile, ...profile };
      this.persistLocalCache(CACHE_KEYS.CAPTAIN_PROFILE, this.captainProfile);
      this.notify();
    }
  }
}

export const rideStore = new RaftarRideStore();
export const raftarRideStore = rideStore;
