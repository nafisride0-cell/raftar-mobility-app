import { ADMIN_EMERGENCY_NUMBER, FOUNDER_NAME } from '../data/constants';

export interface SmsRequest {
  to?: string;
  senderName: string;
  senderPhone: string;
  role: 'passenger' | 'captain';
  alertType?: string;
  locationLink: string;
  coordinates: {
    lat: number;
    lng: number;
    address: string;
  };
  notes?: string;
}

export interface SmsReceipt {
  messageId: string;
  to: string;
  senderId: string;
  alertType: string;
  messageBody: string;
  locationLink: string;
  status: 'DELIVERED' | 'FAILED' | 'PENDING';
  deliveredAt: string;
  gateway: string;
  senderName: string;
  senderPhone: string;
  role: 'passenger' | 'captain';
  coordinates: {
    lat: number;
    lng: number;
    address: string;
  };
}

const SMS_LOGS_KEY = 'nafis_ride_sms_logs_v1';

class SmsApiService {
  private logs: SmsReceipt[] = [];

  constructor() {
    this.loadLogs();
  }

  private loadLogs() {
    try {
      const stored = localStorage.getItem(SMS_LOGS_KEY);
      if (stored) {
        this.logs = JSON.parse(stored);
      }
    } catch {
      this.logs = [];
    }
  }

  private saveLogs() {
    try {
      localStorage.setItem(SMS_LOGS_KEY, JSON.stringify(this.logs.slice(0, 50)));
    } catch {}
  }

  public async sendEmergencySms(request: SmsRequest): Promise<SmsReceipt> {
    const recipient = request.to || ADMIN_EMERGENCY_NUMBER;
    const alertLabel = request.alertType || 'Urgent Help Needed';
    const timestampStr = new Date().toLocaleTimeString('en-IN', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true,
    });

    const messageBody =
      `🚨 [${alertLabel.toUpperCase()}] NAFIS RIDE EMERGENCY ALERT\n` +
      `From: ${request.senderName} (${request.role.toUpperCase()})\n` +
      `Phone: ${request.senderPhone}\n` +
      `Location: ${request.coordinates.address}\n` +
      `Live Map GPS: ${request.locationLink}\n` +
      `Time: ${timestampStr}\n` +
      `Urgent Help Needed: Live dispatch notified. Founder: ${FOUNDER_NAME}`;

    const receipt: SmsReceipt = {
      messageId: `SMS-NF-${Date.now().toString().slice(-6)}-${Math.floor(100 + Math.random() * 900)}`,
      to: recipient,
      senderId: 'NFSRID',
      alertType: alertLabel,
      messageBody,
      locationLink: request.locationLink,
      status: 'DELIVERED',
      deliveredAt: `${new Date().toLocaleDateString('en-IN')} ${timestampStr}`,
      gateway: 'Fast2SMS Indian Telecom Route / DLT Priority 1',
      senderName: request.senderName,
      senderPhone: request.senderPhone,
      role: request.role,
      coordinates: request.coordinates,
    };

    this.logs.unshift(receipt);
    this.saveLogs();

    // Also sync to backend emergency ledger
    try {
      await fetch('/api/sos/sms-log', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(receipt),
      });
    } catch {}

    return receipt;
  }

  public getLogs(): SmsReceipt[] {
    return [...this.logs];
  }

  public clearLogs() {
    this.logs = [];
    this.saveLogs();
  }
}

export const mockSmsService = new SmsApiService();
