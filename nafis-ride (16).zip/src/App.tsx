import React, { useState, useEffect } from 'react';
import { Routes, Route, useNavigate, useLocation } from 'react-router-dom';
import { Navbar } from './components/Navbar';
import { PassengerHome } from './components/passenger/PassengerHome';
import { CaptainHome } from './components/captain/CaptainHome';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { DiagnosticView } from './components/DiagnosticView';
import { ProfileView } from './components/ProfileView';
import { BookingView } from './components/BookingView';
import { RidesView } from './components/RidesView';
import { SosEmergencyModal } from './components/common/SosEmergencyModal';
import { AuthModal } from './components/auth/AuthModal';
import { ErrorBoundary } from './components/common/ErrorBoundary';
import { nativeGeolocation } from './services/nativeGeolocationService';
import { pushNotificationService } from './services/pushNotificationService';
import { rideStore } from './services/store';
import { ShieldCheck, Lock, ShieldAlert } from 'lucide-react';
import {
  BRAND_NAME,
  BRAND_NAME_HINDI,
  BRAND_TAGLINE,
  FOUNDER_NAME,
  FOUNDER_SOS_HOTLINE,
} from './data/constants';

export const App: React.FC = () => {
  const [showSosModal, setShowSosModal] = useState<boolean>(false);
  const [showAuthModal, setShowAuthModal] = useState<boolean>(false);
  const [authInitialPhone, setAuthInitialPhone] = useState<string>('');
  const [authDefaultRole, setAuthDefaultRole] = useState<'passenger' | 'captain'>('passenger');
  const [userProfile, setUserProfile] = useState(rideStore.getUserProfile());

  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    // Initialize background native services for mobile runtime
    nativeGeolocation.startTracking(() => {});
    pushNotificationService.requestPermission();

    const unsub = rideStore.subscribe(() => {
      setUserProfile(rideStore.getUserProfile());
    });

    return () => {
      unsub();
      nativeGeolocation.stopTracking();
    };
  }, []);

  // Strict Rapido-grade Route Guard: Must have active verified session token
  const isUserAuthenticated = Boolean(
    userProfile &&
    userProfile.isVerified &&
    userProfile.token &&
    userProfile.token.trim() !== ''
  );

  const handleOpenAuth = (role: 'passenger' | 'captain' = 'passenger') => {
    setAuthDefaultRole(role);
    setShowAuthModal(true);
  };

  const handleLoginSuccess = (role: 'passenger' | 'captain') => {
    setShowAuthModal(false);
    if (role === 'captain') {
      navigate('/captain');
    } else {
      navigate('/');
    }
  };

  const isCaptainRoute = location.pathname.startsWith('/captain');

  // =========================================================================
  // COMPULSORY AUTHENTICATION ROUTE GUARD WALL (RAPIDO-GRADE LOCKDOWN)
  // If unverified or empty session token: completely block access to maps & homes
  // =========================================================================
  if (!isUserAuthenticated) {
    return (
      <ErrorBoundary>
        <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between font-sans selection:bg-yellow-400 selection:text-slate-950 relative overflow-hidden">
          {/* Ambient Glow */}
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-96 h-96 bg-yellow-400/10 rounded-full blur-3xl pointer-events-none" />

          {/* Top Brand Banner */}
          <header className="p-6 flex items-center justify-between border-b border-slate-900 z-10">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-yellow-400 text-slate-950 font-black flex items-center justify-center text-lg shadow-lg shadow-yellow-400/20">
                RF
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-base font-black text-white tracking-wide">
                    {BRAND_NAME}
                  </h1>
                  <span className="text-xs text-yellow-400 font-hindi font-bold">
                    ({BRAND_NAME_HINDI})
                  </span>
                </div>
                <p className="text-[10px] text-slate-400 font-medium">
                  संस्थापक: {FOUNDER_NAME} • Live Fast2SMS DLT Security
                </p>
              </div>
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1 bg-yellow-400/10 border border-yellow-400/30 rounded-full text-[11px] font-bold text-yellow-400">
              <Lock className="w-3.5 h-3.5" />
              <span>अनिवार्य प्रमाणीकरण</span>
            </div>
          </header>

          {/* Center Brand Identity & Fast2SMS DLT Wall */}
          <main className="flex-1 max-w-md w-full mx-auto p-4 flex flex-col justify-center items-center text-center z-10 space-y-4">
            <div className="p-4 bg-slate-900 border border-yellow-400/30 rounded-3xl w-full shadow-2xl space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-yellow-400/10 border border-yellow-400/40 mx-auto flex items-center justify-center text-yellow-400 shadow-md">
                <ShieldCheck className="w-7 h-7" />
              </div>
              <h2 className="text-lg font-black text-white">
                रफ़्तार सुरक्षित प्रवेश (Verified Access Only)
              </h2>
              <p className="text-xs text-slate-300 leading-relaxed">
                {BRAND_TAGLINE}
              </p>
              <div className="p-2.5 bg-slate-950/80 rounded-2xl border border-slate-800 text-[11px] text-slate-400">
                दिल्ली एनसीआर, गुरुग्राम व हरियाणा में वास्तविक समय जीपीएस ट्रैकिंग एवं सुरक्षित यात्रा हेतु मोबाइल ओटीपी सत्यापन अनिवार्य है।
              </div>
            </div>

            {/* Compulsory Fast2SMS DLT Auth Component (Unclosable, No guest bypass) */}
            <AuthModal
              isOpen={true}
              isCompulsory={true}
              initialPhone={authInitialPhone}
              defaultRole={authDefaultRole}
              onLoginSuccess={handleLoginSuccess}
            />
          </main>

          {/* Footer Security Watermark */}
          <footer className="p-4 border-t border-slate-900 text-center text-[10px] text-slate-500 z-10 space-y-1">
            <div className="flex items-center justify-center gap-2">
              <ShieldAlert className="w-3 h-3 text-yellow-400" />
              <span>24/7 आपातकालीन एसओएस हेल्पलाइन: {FOUNDER_SOS_HOTLINE}</span>
            </div>
            <p>© 2026 {BRAND_NAME}. All Rights Reserved. TRAI DLT Compliant.</p>
          </footer>
        </div>
      </ErrorBoundary>
    );
  }

  // =========================================================================
  // AUTHENTICATED PRODUCTION SYSTEM (PASSENGER & CAPTAIN WORKSPACES)
  // =========================================================================
  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-yellow-400 selection:text-slate-950">
        {/* Global Navigation Header & Bottom Nav */}
        <Navbar
          onOpenSos={() => setShowSosModal(true)}
          onOpenAuth={() => handleOpenAuth('passenger')}
        />

        {/* Main Content Area */}
        <main className="flex-1 max-w-2xl w-full mx-auto p-3 sm:p-4 pb-24">
          <Routes>
            <Route
              path="/"
              element={
                <PassengerHome
                  onOpenSos={() => setShowSosModal(true)}
                  onOpenAuth={() => handleOpenAuth('passenger')}
                />
              }
            />
            <Route
              path="/captain"
              element={
                <CaptainHome
                  onOpenSos={() => setShowSosModal(true)}
                  onOpenAuth={() => handleOpenAuth('captain')}
                />
              }
            />
            <Route path="/admin" element={<AdminDashboard />} />
            <Route path="/status" element={<DiagnosticView />} />
            <Route path="/profile" element={<ProfileView />} />
            <Route
              path="/booking"
              element={
                <BookingView
                  onBookRide={() => {
                    navigate('/');
                  }}
                />
              }
            />
            <Route
              path="/rides"
              element={
                <RidesView
                  rides={rideStore.getRideHistory().map((r) => ({
                    id: r.id,
                    pickup: r.pickupLocation.name,
                    dropoff: r.dropLocation.name,
                    tier: r.vehicleType.toUpperCase(),
                    price: r.fare,
                    timestamp: r.createdAt,
                    status: r.status as any,
                    driverName: r.captainName,
                    driverVehicle: r.vehicleModel,
                    licensePlate: r.vehiclePlate,
                  }))}
                />
              }
            />
          </Routes>
        </main>

        {/* SOS Emergency Modal */}
        <SosEmergencyModal
          isOpen={showSosModal}
          onClose={() => setShowSosModal(false)}
          role={isCaptainRoute ? 'captain' : 'passenger'}
          userName={userProfile?.name || 'Raftar User'}
          userPhone={userProfile?.phone || '+91 70236 08919'}
        />

        {/* Additional Auth Modal if triggered inside authenticated workspace (e.g. role switch) */}
        {showAuthModal && (
          <AuthModal
            isOpen={showAuthModal}
            onClose={() => setShowAuthModal(false)}
            initialPhone={authInitialPhone}
            defaultRole={authDefaultRole}
            onLoginSuccess={handleLoginSuccess}
          />
        )}
      </div>
    </ErrorBoundary>
  );
};

export default App;
