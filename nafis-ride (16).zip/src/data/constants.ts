import {
  LocationPoint,
  VehicleOption,
  FareSettings,
  Captain,
  OperationalCity,
  CeoPerformanceMetric,
  ExecutiveMember,
} from '../types';

// =========================================================================
// SECTION 1: CORE BRAND TOKENS & SUPREME GOVERNANCE IDENTITY
// =========================================================================
export const BRAND_NAME = 'Raftar Mobility';
export const BRAND_NAME_EN = 'Raftar Mobility';
export const BRAND_NAME_HINDI = 'रफ़्तार';
export const CORPORATE_NAME = 'Raftar Mobility';
export const APP_NAME = 'Raftar Mobility';

export const FOUNDER_NAME = 'Nafis Khan';
export const FOUNDER_NAME_HINDI = 'नफ़ीस खान';
export const MASTER_ADMIN_NAME = 'Nafis Khan';
export const MASTER_ADMIN_NAME_HINDI = 'नफ़ीस खान';
export const SUPER_ADMIN_NAME = 'Nafis Khan (Founder & CEO)';
export const FOUNDER_TITLE = 'Chief Executive Officer (CEO), Founder & Master Admin';
export const SUPER_ADMIN_EMAIL = 'nafiskhan.dsep9e@detedu.org';
export const SUPPORT_EMAIL = 'nafiskhan.dsep9e@detedu.org';
export const ADMIN_DIRECT_EMAIL = 'nafiskhan.dsep9e@detedu.org';

export const FOUNDER_PHONE = '+91 70236 08919';
export const FOUNDER_PHONE_RAW = '7023608919';
export const FOUNDER_SOS_HOTLINE = '+91 70236 08919';
export const ADMIN_EMERGENCY_NUMBER = '+91 70236 08919';

export const BRAND_TAGLINE = 'ट्रैफिक चाहे जितना भारी, सबसे तेज़ रफ़्तार हमारी! — Raftar Mobility';
export const FOUNDER_TAGLINE = 'ट्रैफिक चाहे जितना भारी, सबसे तेज़ रफ़्तार हमारी! — Raftar Mobility';

export const MAX_RIDE_LIMIT_KM = 75;
export const PLATFORM_COMMISSION_PERCENTAGE = 12;
export const CAPTAIN_PAYOUT_PERCENTAGE = 88;

// =========================================================================
// SECTION 2: SPORTY BLACK & NEON YELLOW UI DESIGN TOKENS
// =========================================================================
export const SPORTY_THEME = {
  primary: '#FACC15', // High-octane Neon Yellow
  primaryGlow: 'rgba(250, 204, 21, 0.4)',
  primaryDark: '#EAB308',
  bgDark: '#020617', // Pitch Dark Slate 950
  bgSurface: '#0F172A', // Slate 900
  bgCard: '#1E293B', // Slate 800
  accentCyan: '#06B6D4',
  accentGreen: '#10B981',
  dangerRed: '#EF4444',
  textLight: '#F8FAFC',
  textMuted: '#94A3B8',
};

// =========================================================================
// SECTION 3: OPERATIONAL CITIES (DELHI NCR, GURUGRAM, HARYANA & RAJASTHAN)
// =========================================================================
export const OPERATIONAL_CITIES: OperationalCity[] = [
  {
    id: 'delhi',
    name: 'Delhi (NCR Capital)',
    hindiName: 'दिल्ली (एनसीआर राजधानी)',
    state: 'Delhi',
    stateHindi: 'दिल्ली एनसीआर',
    center: { lat: 28.6139, lng: 77.2090 },
    zoom: 12,
    radiusKm: 45,
    tagline: 'Connaught Place, India Gate & Transit Corridors',
    isPopular: true,
  },
  {
    id: 'gurugram',
    name: 'Gurugram (Millennium City)',
    hindiName: 'गुरुग्राम (मिलेनियम सिटी)',
    state: 'Haryana',
    stateHindi: 'हरियाणा',
    center: { lat: 28.4595, lng: 77.0266 },
    zoom: 13,
    radiusKm: 35,
    tagline: 'Cyber City, Golf Course Road & NH-48',
    isPopular: true,
  },
  {
    id: 'haryana_subhubs',
    name: 'Haryana Sub-Hubs (Faridabad/Manesar)',
    hindiName: 'हरियाणा सब-हब्स (फरीदाबाद/मानेसर)',
    state: 'Haryana',
    stateHindi: 'हरियाणा',
    center: { lat: 28.4089, lng: 77.3178 },
    zoom: 13,
    radiusKm: 35,
    tagline: 'Faridabad, Ballabhgarh, Manesar & Industrial Expressways',
    isPopular: true,
  },
  {
    id: 'alwar',
    name: 'Alwar (HQ)',
    hindiName: 'अलवर (मुख्यालय)',
    state: 'Rajasthan',
    stateHindi: 'राजस्थान',
    center: { lat: 27.5530, lng: 76.6346 },
    zoom: 13,
    radiusKm: 35,
    tagline: 'अलवर जिला मुख्यालय, होप सर्कस, कटी घाटी एवं मेवात क्षेत्र',
    isPopular: true,
  },
  {
    id: 'jodhpur',
    name: 'Jodhpur (Sun City)',
    hindiName: 'जोधपुर (सूर्य नगरी)',
    state: 'Rajasthan',
    stateHindi: 'राजस्थान',
    center: { lat: 26.2389, lng: 73.0243 },
    zoom: 13,
    radiusKm: 40,
    tagline: 'मेहरानगढ़ दुर्ग, घंटाघर, शास्त्री नगर एवं एम्स कॉरिडोर',
    isPopular: true,
  },
  {
    id: 'bengaluru',
    name: 'Bengaluru (Karnataka)',
    hindiName: 'बेंगलुरु (सिलिकॉन वैली)',
    kannadaName: 'ಬೆಂಗಳೂರು',
    state: 'Karnataka',
    stateHindi: 'कर्नाटक',
    stateKannada: 'ಕರ್ನಾಟಕ',
    center: { lat: 12.9716, lng: 77.5946 },
    zoom: 12,
    radiusKm: 50,
    tagline: 'Majestic, Koramangala, Indiranagar, IT Parks & Airport',
    isPopular: true,
  },
  {
    id: 'mysuru',
    name: 'Mysuru (Heritage City)',
    hindiName: 'मैसूरु (सांस्कृतिक राजधानी)',
    kannadaName: 'ಮೈಸೂರು',
    state: 'Karnataka',
    stateHindi: 'ಕರ್नाटक',
    stateKannada: 'ಕರ್ನಾಟಕ',
    center: { lat: 12.2958, lng: 76.6394 },
    zoom: 13,
    radiusKm: 35,
    tagline: 'Mysuru Palace, Chamundi Hill & Junction',
    isPopular: true,
  },
  {
    id: 'hubballi',
    name: 'Hubballi-Dharwad',
    hindiName: 'हुबली-धारवाड़',
    kannadaName: 'ಹುಬ್ಬಳ್ಳಿ-ಧಾರವಾಡ',
    state: 'Karnataka',
    stateHindi: 'कर्नाटक',
    stateKannada: 'ಕರ್ನಾಟಕ',
    center: { lat: 15.3647, lng: 75.1240 },
    zoom: 13,
    radiusKm: 35,
    tagline: 'Chennamma Circle & Commercial Hub',
  },
  {
    id: 'mangaluru',
    name: 'Mangaluru (Coastal Hub)',
    hindiName: 'मंगलुरु',
    kannadaName: 'ಮಂಗಳೂರು',
    state: 'Karnataka',
    stateHindi: 'कर्नाटक',
    stateKannada: 'ಕರ್ನಾಟಕ',
    center: { lat: 12.9141, lng: 74.8560 },
    zoom: 13,
    radiusKm: 35,
    tagline: 'Panambur, Central Station & Airport',
  },
];

export const ALWAR_CENTER_COORDS = { lat: 27.5530, lng: 76.6346 };

// =========================================================================
// SECTION 4: HIGH-DENSITY OPERATIONAL ZONES
// =========================================================================
export const OPERATIONAL_ZONES: LocationPoint[] = [
  // --- DELHI NCR CORE REGION ---
  {
    id: 'delhi_cp',
    name: 'Connaught Place (Delhi Core)',
    hindiName: 'कनॉट प्लेस (राजीव चौक दिल्ली)',
    lat: 28.6304,
    lng: 77.2177,
    landmark: 'Rajiv Chowk Metro Inner Circle',
    isOfficialZone: true,
    cityId: 'delhi',
    state: 'Delhi',
  },
  {
    id: 'delhi_ndls',
    name: 'New Delhi Railway Station',
    hindiName: 'नई दिल्ली रेलवे स्टेशन (NDLS)',
    lat: 28.6415,
    lng: 77.2208,
    landmark: 'Pahar Ganj Exit Gate & Ajmeri Gate',
    isOfficialZone: true,
    cityId: 'delhi',
    state: 'Delhi',
  },
  {
    id: 'delhi_india_gate',
    name: 'India Gate & Kartavya Path',
    hindiName: 'इंडिया गेट एवं कर्तव्य पथ',
    lat: 28.6129,
    lng: 77.2295,
    landmark: 'National War Memorial & C-Hexagon',
    isOfficialZone: true,
    cityId: 'delhi',
    state: 'Delhi',
  },
  {
    id: 'delhi_aerocity',
    name: 'IGI Airport T3 & Aerocity',
    hindiName: 'आईजीआई एयरपोर्ट T3/T1 व एरोसिटी',
    lat: 28.5562,
    lng: 77.1000,
    landmark: 'Aerocity Metro & Airport Express Link',
    isOfficialZone: true,
    cityId: 'delhi',
    state: 'Delhi',
  },
  {
    id: 'delhi_hauz_khas',
    name: 'Hauz Khas Village & IIT Corridor',
    hindiName: 'हौज़ खास विलेज एवं आईआईटी कॉरिडोर',
    lat: 28.5494,
    lng: 77.2001,
    landmark: 'Deer Park & Outer Ring Road',
    isOfficialZone: true,
    cityId: 'delhi',
    state: 'Delhi',
  },
  {
    id: 'delhi_lajpat_nagar',
    name: 'Lajpat Nagar Central Market',
    hindiName: 'लाजपत नगर सेंट्रल मार्केट',
    lat: 28.5677,
    lng: 77.2433,
    landmark: 'Ring Road & Metro Interchange',
    isOfficialZone: true,
    cityId: 'delhi',
    state: 'Delhi',
  },

  // --- GURUGRAM (GURGAON) & HARYANA CORRIDORS ---
  {
    id: 'ggn_cybercity',
    name: 'DLF Cyber City (Gurugram)',
    hindiName: 'डीएलएफ साइबर सिटी (गुरुग्राम)',
    lat: 28.4951,
    lng: 77.0894,
    landmark: 'Tech Corridor Metro & Cyber Hub',
    isOfficialZone: true,
    cityId: 'gurugram',
    state: 'Haryana',
  },
  {
    id: 'ggn_iffco',
    name: 'IFFCO Chowk Metro Station',
    hindiName: 'इफको चौक मेट्रो स्टेशन (NH-48)',
    lat: 28.4714,
    lng: 77.0722,
    landmark: 'NH-48 Intersection & MG Road Junction',
    isOfficialZone: true,
    cityId: 'gurugram',
    state: 'Haryana',
  },
  {
    id: 'ggn_golf_course',
    name: 'Golf Course Road (One Horizon)',
    hindiName: 'गोल्फ कोर्स रोड (वन होराइजन सेंटर)',
    lat: 28.4789,
    lng: 77.1025,
    landmark: 'Sector 42-43 Metro & Commercial Belt',
    isOfficialZone: true,
    cityId: 'gurugram',
    state: 'Haryana',
  },
  {
    id: 'ggn_sohna_road',
    name: 'Subhash Chowk & Sohna Road',
    hindiName: 'सुभाष चौक एवं सोहना रोड',
    lat: 28.4289,
    lng: 77.0422,
    landmark: 'Rajiv Chowk Underpass Link',
    isOfficialZone: true,
    cityId: 'gurugram',
    state: 'Haryana',
  },
  {
    id: 'hry_faridabad_bata',
    name: 'Bata Chowk Metro & Industrial Belt',
    hindiName: 'बाटा चौक मेट्रो स्टेशन (फरीदाबाद)',
    lat: 28.4089,
    lng: 77.3178,
    landmark: 'Faridabad Industrial Hub & Mathura Road',
    isOfficialZone: true,
    cityId: 'haryana_subhubs',
    state: 'Haryana',
  },
  {
    id: 'hry_manesar_imt',
    name: 'IMT Manesar Industrial Expressway',
    hindiName: 'आईएमटी मानेसर इंडस्ट्रियल एक्सप्रेसवे',
    lat: 28.3587,
    lng: 76.9382,
    landmark: 'Automobile Manufacturing Belt & NH-48',
    isOfficialZone: true,
    cityId: 'haryana_subhubs',
    state: 'Haryana',
  },

  // --- ALWAR REGION (ORIGINAL RAJASTHAN HQ) ---
  {
    id: 'alwar_core',
    name: 'Alwar Junction (Hope Circus)',
    hindiName: 'अलवर जंक्शन (होप सर्कस)',
    lat: 27.5530,
    lng: 76.6346,
    landmark: 'Hope Circus, Company Bagh, Alwar Junction',
    isOfficialZone: true,
    cityId: 'alwar',
    state: 'Rajasthan',
  },
  {
    id: 'kati_ghati',
    name: 'Kati Ghati Pass',
    hindiName: 'कटी घाटी दर्रा',
    lat: 27.5685,
    lng: 76.5912,
    landmark: 'Historic Mountain Pass & Siliserh Road Link',
    isOfficialZone: true,
    cityId: 'alwar',
    state: 'Rajasthan',
  },
  {
    id: 'alwar_station',
    name: 'Alwar Railway Station',
    hindiName: 'अलवर रेलवे स्टेशन',
    lat: 27.5645,
    lng: 76.6123,
    landmark: 'Railway Station Road & Bus Terminal',
    isOfficialZone: true,
    cityId: 'alwar',
    state: 'Rajasthan',
  },
  {
    id: 'alwar_shanti_kunj',
    name: 'Shanti Kunj & Company Bagh',
    hindiName: 'शांति कुंज एवं कंपनी बाग',
    lat: 27.5578,
    lng: 76.6089,
    landmark: 'Company Garden, Secretariat Road',
    isOfficialZone: true,
    cityId: 'alwar',
    state: 'Rajasthan',
  },
  {
    id: 'alwar_mia',
    name: 'Matsya Industrial Area (MIA)',
    hindiName: 'मत्स्य औद्योगिक क्षेत्र (MIA)',
    lat: 27.5921,
    lng: 76.6612,
    landmark: 'MIA Industrial Corridor & Factories',
    isOfficialZone: true,
    cityId: 'alwar',
    state: 'Rajasthan',
  },
  {
    id: 'kishangarh_bas',
    name: 'Kishangarh Bas Stand',
    hindiName: 'किशनगढ़ बास बस स्टैंड',
    lat: 27.8174,
    lng: 76.7214,
    landmark: 'Kishangarh Bus Stand & Sub-District Center',
    isOfficialZone: true,
    cityId: 'alwar',
    state: 'Rajasthan',
  },
  {
    id: 'mew_baroda',
    name: 'Baroda Meo Market',
    hindiName: 'बड़ौदा मेव बाजार',
    lat: 27.4891,
    lng: 76.8833,
    landmark: 'Baroda Meo Market & Highway Junction',
    isOfficialZone: true,
    cityId: 'alwar',
    state: 'Rajasthan',
  },
  {
    id: 'shital_kat',
    name: 'Shital Kat Pass',
    hindiName: 'शीतल कट दर्रा',
    lat: 27.5210,
    lng: 76.6710,
    landmark: 'Shital Kat Pass & Eastern Corridor',
    isOfficialZone: true,
    cityId: 'alwar',
    state: 'Rajasthan',
  },
  {
    id: 'nogawan',
    name: 'Nogawan Mandi',
    hindiName: 'नौगांवा मंडी',
    lat: 27.6834,
    lng: 76.8451,
    landmark: 'Naugaon Border Road & Grain Mandi',
    isOfficialZone: true,
    cityId: 'alwar',
    state: 'Rajasthan',
  },
  {
    id: 'jattyana_rto',
    name: 'Jattyana RTO Office',
    hindiName: 'जट्याना आरटीओ कार्यालय',
    lat: 27.5312,
    lng: 76.6521,
    landmark: 'District Transport Office & Commercial Area',
    isOfficialZone: true,
    cityId: 'alwar',
    state: 'Rajasthan',
  },
  {
    id: 'siliserh_link',
    name: 'Siliserh Lake Gateway',
    hindiName: 'सिलीसेढ़ झील मार्ग',
    lat: 27.5360,
    lng: 76.5410,
    landmark: 'Siliserh Lake Scenic Point',
    isOfficialZone: true,
    cityId: 'alwar',
    state: 'Rajasthan',
  },
  {
    id: 'moti_doongri',
    name: 'Moti Doongri Temple',
    hindiName: 'मोती डूंगरी मंदिर',
    lat: 27.5614,
    lng: 76.6219,
    landmark: 'Moti Doongri Ganesh Mandir & Palace',
    isOfficialZone: true,
    cityId: 'alwar',
    state: 'Rajasthan',
  },

  // --- JODHPUR REGION (RAJASTHAN SUN CITY) ---
  {
    id: 'jodh_clock_tower',
    name: 'Ghanta Ghar (Clock Tower)',
    hindiName: 'घंटाघर (क्लॉक टावर जोधपुर)',
    lat: 26.2954,
    lng: 73.0238,
    landmark: 'Sardar Market & Heritage Old City',
    isOfficialZone: true,
    cityId: 'jodhpur',
    state: 'Rajasthan',
  },
  {
    id: 'jodh_mehrangarh',
    name: 'Mehrangarh Fort Gate',
    hindiName: 'मेहरानगढ़ दुर्ग मुख्य द्वार',
    lat: 26.2980,
    lng: 73.0189,
    landmark: 'Fort Ramparts & Rao Jodha Desert Park',
    isOfficialZone: true,
    cityId: 'jodhpur',
    state: 'Rajasthan',
  },
  {
    id: 'jodh_shastri_nagar',
    name: 'Shastri Nagar Main Circle',
    hindiName: 'शास्त्री नगर मुख्य चौराहा',
    lat: 26.2731,
    lng: 73.0084,
    landmark: 'Medical Corridor & MDM Hospital Link',
    isOfficialZone: true,
    cityId: 'jodhpur',
    state: 'Rajasthan',
  },
  {
    id: 'jodh_aiims',
    name: 'AIIMS Jodhpur Medical Corridor',
    hindiName: 'एम्स जोधपुर हॉस्पिटल परिसर',
    lat: 26.2415,
    lng: 72.9868,
    landmark: 'Basni Industrial Area & AIIMS Main Gate',
    isOfficialZone: true,
    cityId: 'jodhpur',
    state: 'Rajasthan',
  },

  // --- BENGALURU REGION (KARNATAKA TECH HUB) ---
  {
    id: 'blr_majestic',
    name: 'Majestic KSRTC & City Railway',
    hindiName: 'मजेस्टिक बस स्टैंड व रेलवे स्टेशन',
    kannadaName: 'ಮೆಜೆಸ್ಟಿಕ್ ಬಸ್ ನಿಲ್ದಾಣ',
    lat: 12.9767,
    lng: 77.5713,
    landmark: 'Kempegowda Bus Station & Metro Interchange',
    isOfficialZone: true,
    cityId: 'bengaluru',
    state: 'Karnataka',
  },
  {
    id: 'blr_mg_road',
    name: 'MG Road & Brigade Road',
    hindiName: 'एमजी रोड एवं ब्रिगेड रोड',
    kannadaName: 'ಎಂ.ಜಿ. ರಸ್ತೆ',
    lat: 12.9754,
    lng: 77.6067,
    landmark: 'Central Business District, Metro Station & Commercial Hub',
    isOfficialZone: true,
    cityId: 'bengaluru',
    state: 'Karnataka',
  },
  {
    id: 'blr_koramangala',
    name: 'Koramangala 5th Block',
    hindiName: 'कोरमंगला 5th ब्लॉक',
    kannadaName: 'ಕೋರಮಂಗಲ',
    lat: 12.9352,
    lng: 77.6245,
    landmark: 'Startup Corridor, Forum Mall & Sony World Signal',
    isOfficialZone: true,
    cityId: 'bengaluru',
    state: 'Karnataka',
  },
  {
    id: 'blr_indiranagar',
    name: 'Indiranagar 100ft Road',
    hindiName: 'इंदिरानगर 100 फीट रोड',
    kannadaName: 'ಇಂದಿರಾನಗರ 100 ಅಡಿ ರಸ್ತೆ',
    lat: 12.9719,
    lng: 77.6412,
    landmark: '100ft Road Hub, CMH Road & Metro Station',
    isOfficialZone: true,
    cityId: 'bengaluru',
    state: 'Karnataka',
  },
  {
    id: 'blr_whitefield',
    name: 'Whitefield ITPL Tech Park',
    hindiName: 'व्हाइटफील्ड आईटीपीएल',
    kannadaName: 'ವೈಟ್‌ಫೀಲ್ಡ್ ಐಟಿಪಿಎಲ್',
    lat: 12.9859,
    lng: 77.7314,
    landmark: 'International Tech Park (ITPL) & EPIP Zone',
    isOfficialZone: true,
    cityId: 'bengaluru',
    state: 'Karnataka',
  },

  // --- MYSURU REGION (KARNATAKA HERITAGE CITY) ---
  {
    id: 'mys_palace',
    name: 'Mysuru Palace (Amba Vilas)',
    hindiName: 'मैसूरु पैलेस (अम्बा विलास)',
    kannadaName: 'ಮೈಸೂರು ಅರಮನೆ',
    lat: 12.3052,
    lng: 76.6552,
    landmark: 'World Famous Mysuru Palace Heritage Center',
    isOfficialZone: true,
    cityId: 'mysuru',
    state: 'Karnataka',
  },
  {
    id: 'mys_junction',
    name: 'Mysuru Junction Railway Station',
    hindiName: 'मैसूरु जंक्शन रेलवे स्टेशन',
    kannadaName: 'ಮೈಸೂರು ರೈಲ್ವೆ ನಿಲ್ದಾಣ',
    lat: 12.3164,
    lng: 76.6445,
    landmark: 'Central Railway Station & Suburb Bus Stand',
    isOfficialZone: true,
    cityId: 'mysuru',
    state: 'Karnataka',
  },
];

// =========================================================================
// SECTION 5: VEHICLE CATEGORIES & SPORTY TARIFF TOKENS
// =========================================================================
export const VEHICLE_OPTIONS: VehicleOption[] = [
  {
    type: 'bike',
    name: 'Raftar Bike',
    hindiName: 'रफ़्तार बाइक',
    tagline: 'भारी ट्रैफिक को चीरता सबसे तेज़ • 1 सवारी',
    icon: '🛵',
    capacity: 1,
    baseFare: 20,
    perKmRate: 8,
    minFare: 25,
    speedKmH: 38,
  },
  {
    type: 'auto',
    name: 'Raftar Auto',
    hindiName: 'रफ़्तार ऑटो',
    tagline: 'आरामदेह और हवादार सफर • 3 सवारियां',
    icon: '🛺',
    capacity: 3,
    baseFare: 30,
    perKmRate: 12,
    minFare: 35,
    speedKmH: 28,
  },
  {
    type: 'eriksha',
    name: 'Raftar E-Riksha',
    hindiName: 'रफ़्तार ई-रिक्शा',
    tagline: 'इको-फ्रेंडली व सबसे किफायती • 4 सवारियां',
    icon: '🔋',
    capacity: 4,
    baseFare: 15,
    perKmRate: 7,
    minFare: 20,
    speedKmH: 20,
  },
];

export const VEHICLES_INFO = VEHICLE_OPTIONS;

// =========================================================================
// SECTION 6: FARE SETTINGS (12% PLATFORM FEE / 88% CAPTAIN SETTLEMENT)
// =========================================================================
export const DEFAULT_FARE_SETTINGS: FareSettings = {
  bike: { baseFare: 20, perKm: 8, minFare: 25 },
  auto: { baseFare: 30, perKm: 12, minFare: 35 },
  eriksha: { baseFare: 15, perKm: 7, minFare: 20 },
  maxRideLimitKm: 75,
  commissionPercentage: 12, // Strict 12% platform fee matrix
  founderName: FOUNDER_NAME,
  supportEmail: SUPPORT_EMAIL,
  sosHelpline: FOUNDER_SOS_HOTLINE,
};

// =========================================================================
// SECTION 7: PRODUCTION FLEET CAPTAINS LEDGER (EMPTY FOR PRODUCTION)
// =========================================================================
// Blank production ledger - only genuinely registered & approved drivers occupy fleet map
export const INITIAL_CAPTAINS: Captain[] = [];

// =========================================================================
// SECTION 8: EXECUTIVE COMMAND BOARD & GOVERNANCE STRUCTURE
// =========================================================================
export const OFFICIAL_EXECUTIVE_TEAM: ExecutiveMember[] = [
  {
    id: 'exec_ceo_nafis',
    employeeCode: 'RF-CEO-001',
    name: 'Nafis Khan',
    hindiName: 'नफ़ीस खान',
    designation: 'Founder & Chief Executive Officer (CEO)',
    hindiDesignation: 'संस्थापक एवं मुख्य कार्यकारी अधिकारी (CEO)',
    roleCategory: 'ceo',
    department: 'Apex Executive Board & Corporate Strategy',
    phone: '+91 70236 08919',
    email: 'nafiskhan.dsep9e@detedu.org',
    bloodGroup: 'O+ Positive',
    joiningDate: '01-Jan-2024',
    validUpto: 'Permanent / Lifetime Director',
    badgeLevel: 'Executive Platinum',
    authorityLevel: 'Level-5 Apex (Supreme Master Authority)',
    isCeo: true,
    emergencyContact: '+91 70236 08919',
    idNumber: 'RF-ALW-EXEC-70236',
  },
  {
    id: 'exec_md_operations',
    employeeCode: 'RF-MD-002',
    name: 'Managing Director (MD)',
    hindiName: 'प्रबंध निदेशक (MD)',
    designation: 'Managing Director - Corporate Operations & Mobility',
    hindiDesignation: 'प्रबंध निदेशक - कॉर्पोरेट संचालन',
    roleCategory: 'md',
    department: 'Strategic Expansion & Fleet Management (Delhi NCR / Haryana)',
    phone: '+91 70236 08919',
    email: 'md.operations@raftarmobility.in',
    bloodGroup: 'B+ Positive',
    joiningDate: '15-Mar-2024',
    validUpto: '31-Dec-2028',
    badgeLevel: 'Director Gold',
    authorityLevel: 'Level-4 Executive Command',
    isCeo: false,
    emergencyContact: '+91 70236 08919',
    idNumber: 'RF-NCR-DIR-002',
  },
  {
    id: 'exec_gm_fleet',
    employeeCode: 'RF-GM-003',
    name: 'General Manager (GM)',
    hindiName: 'महाप्रबंधक (GM)',
    designation: 'General Manager - Captain Onboarding & KYC Control',
    hindiDesignation: 'महाप्रबंधक - चालक ऑनबोर्डिंग एवं सत्यापन',
    roleCategory: 'gm',
    department: 'Captain Relations, Verification & Disciplinary Board',
    phone: '+91 70236 08919',
    email: 'gm.fleet@raftarmobility.in',
    bloodGroup: 'A+ Positive',
    joiningDate: '01-Apr-2024',
    validUpto: '31-Dec-2027',
    badgeLevel: 'Operations Silver',
    authorityLevel: 'Level-3 Operations Command',
    isCeo: false,
    emergencyContact: '+91 70236 08919',
    idNumber: 'RF-RAJ-GM-003',
  },
  {
    id: 'exec_mgr_geofence',
    employeeCode: 'RF-MGR-004',
    name: 'Regional Operations Manager',
    hindiName: 'क्षेत्रीय संचालन प्रबंधक',
    designation: 'Operations Manager - Delhi NCR & Haryana Corridors',
    hindiDesignation: 'संचालन प्रबंधक - दिल्ली एनसीआर एवं हरियाणा कॉरिडोर',
    roleCategory: 'manager',
    department: 'Geofence Patrol, NH-48 Radar & Traffic Coordination',
    phone: '+91 70236 08919',
    email: 'ops.ncr@raftarmobility.in',
    bloodGroup: 'AB+ Positive',
    joiningDate: '10-May-2024',
    validUpto: '31-Dec-2027',
    badgeLevel: 'Operations Silver',
    authorityLevel: 'Level-3 Field Command',
    isCeo: false,
    emergencyContact: '+91 70236 08919',
    idNumber: 'RF-GGN-MGR-004',
  },
  {
    id: 'exec_cso_safety',
    employeeCode: 'RF-CSO-005',
    name: 'Chief Safety Officer (CSO)',
    hindiName: 'मुख्य सुरक्षा अधिकारी (CSO)',
    designation: 'Chief Safety & Emergency Response Officer',
    hindiDesignation: 'मुख्य सुरक्षा अधिकारी - 24/7 आपातकालीन नियंत्रण कक्ष',
    roleCategory: 'safety',
    department: 'Emergency SOS Command, Police 112 & Women Passenger Safety',
    phone: '+91 70236 08919',
    email: 'safety.sos@raftarmobility.in',
    bloodGroup: 'O+ Positive',
    joiningDate: '01-Jun-2024',
    validUpto: '31-Dec-2028',
    badgeLevel: 'Director Gold',
    authorityLevel: 'Level-4 Rapid Emergency Dispatch',
    isCeo: false,
    emergencyContact: '+91 70236 08919',
    idNumber: 'RF-SAFE-005',
  },
];

export const DEFAULT_EXECUTIVE_TEAM = OFFICIAL_EXECUTIVE_TEAM;

export const EXECUTIVE_TEAM: ExecutiveMember[] = OFFICIAL_EXECUTIVE_TEAM.map((m) => ({
  ...m,
  role: m.designation,
  hindiRole: m.hindiDesignation,
  location: m.id.includes('ncr') || m.id.includes('mgr') ? 'Delhi NCR & Haryana' : 'Rajasthan HQ',
  joinedDate: m.joiningDate,
  status: 'active',
  keyResponsibilities: m.department ? [m.department] : ['Fleet & Operations Management'],
}));

// =========================================================================
// SECTION 9: CEO PERFORMANCE SCORECARD
// =========================================================================
export const CEO_PERFORMANCE_METRICS: CeoPerformanceMetric[] = [
  {
    id: 'kpi-1',
    title: 'दिल्ली एनसीआर, गुरुग्राम व राजस्थान में 100% हाइपरलोकल उपलब्धता',
    description: 'अलवर, जोधपुर, दिल्ली, गुरुग्राम एवं हरियाणा औद्योगिक कॉरिडोर में 3.5 मिनट से कम औसत पिकअप समय।',
    category: 'Hyperlocal Fleet Coverage',
    targetDate: 'Q1 2026',
    completionPercentage: 98,
    status: 'in_progress',
    targetBenchmark: '< 3.5 Min Fast Dispatch',
  },
  {
    id: 'kpi-2',
    title: '12% पारदर्शी मंच शुल्क एवं 88% त्वरित कैप्टन भुगतान',
    description: 'रैपिडो व ओला से अधिक प्रतिस्पर्धी 12% कंपनी मार्जिन तथा सीधे बैंक/UPI में 88% चालक क्रेडिट।',
    category: 'Fair Economics',
    targetDate: 'Q1 2026',
    completionPercentage: 100,
    status: 'completed',
    targetBenchmark: '12% Platform Fee / 88% Captain Split',
  },
  {
    id: 'kpi-3',
    title: 'कैपेसिटर 8 नेटिव बैकग्राउंड जीपीएस व फास्ट2एसएमएस सुरक्षा',
    description: 'एंड्रॉइड 14+ अनुकूलित बैकग्राउंड जिओलोकेशन एवं ट्राई-अनुमोदित Fast2SMS DLT ऑटो-एसओएस आपातकालीन प्रणाली।',
    category: 'Native Architecture',
    targetDate: 'Q2 2026',
    completionPercentage: 100,
    status: 'completed',
    targetBenchmark: 'Zero White-Screen & <3s SOS Dispatch',
  },
  {
    id: 'kpi-4',
    title: 'संस्थापक 24/7 हेल्पलाइन एवं आपातकालीन प्रेषण केंद्र',
    description: 'संस्थापक नफ़ीस खान द्वारा प्रत्यक्ष निगरानी वाला व्यक्तिगत एसओएस एवं कॉल-डिस्पैच कमांड कंसोल।',
    category: 'Safety Governance',
    targetDate: 'Q1 2026',
    completionPercentage: 100,
    status: 'completed',
    targetBenchmark: '100% Direct Escalation SLA',
  },
];

export const CEO_PERFORMANCE_SCORECARD = CEO_PERFORMANCE_METRICS;
